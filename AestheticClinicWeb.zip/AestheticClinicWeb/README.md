# AestheticFlow Website — M4 build

ASP.NET Web Forms (.NET Framework 4.7.2, C#), sharing the **GroupWst6** SQL Server database with the
Front-End System (FES, `aesthetic_clinic_system_1`). No NuGet packages — opens and runs in Visual Studio 2022.

## 1. Run it (10 minutes)

1. **Connection string** — `AestheticClinicWeb\connections.config` is already filled in with the same
   server, database, login and password as the FES `App.config`, so it runs immediately.
   It contains the real password: keep the repo private, and if you change the DB password, update both files.
   (`connections.config.example` is the shareable template without the password.)
2. **Database scripts** — run in SSMS, in order (`AestheticClinicWeb\Database\`):
   | Script | What it does | Required |
   |---|---|---|
   | `01_Add_Patient_Login_Columns.sql` | adds `Password`, `Is_First_Login`, `Is_Account_Active`, `Security_Question`, `Security_Answer` to **Patient**; moves Joseph Frost's old web account onto his Patient row; lists duplicate emails | **yes** |
   | `02_Fix_Patient_ID_Numbers.sql` | replaces invalid SA ID numbers (preview first, then `@Apply = 1`) | recommended |
   | `03_Create_Logins_For_Existing_Patients.sql` | temporary password + first-login flag for every existing patient; outputs the list to email (preview first, then `@Apply = 1`) | **yes** |
   | `04_Optional_Seed_Demo_Data.sql` | demo receptionist + 2 demo patients | optional |
   | `05_Optional_ContactEnquiry.sql` | saves Contact-page messages | optional |
3. Open `AestheticClinicWeb.sln` in VS 2022 → **F5**.

### Patient login flow
1. Patient is captured in the FES → `Is_First_Login = 1` (default), FES sets a temporary `Password` and emails it.
2. Website login: Staff table first; otherwise the **Patient** table by email. No patient row with a password → rejected.
3. `Is_First_Login = 1` and the temporary password matches → patient is sent to **Create your password**
   (strong password + security question). Every other page redirects there until it's done.
4. Only after the new password is saved: `Password` = new password (PBKDF2 hash) and `Is_First_Login = 0`.
5. `Is_First_Login = 0` → normal check against the stored (hashed) password.
6. `Is_Account_Active = 0` → login refused. Managers switch this in **Manage Accounts → Patient online accounts**
   (Activate / Deactivate / Create login / Reset password, with a ready-to-send email link).

## 2. Demo logins

| Who | Email | Password | Lands on |
|---|---|---|---|
| Doctor (manager rights) | `doc@gmail.com` | `123` (existing FES login) | Staff Portal + Admin menu |
| Receptionist | `reception.demo@aestheticflow.co.za` | `Recept@123` | Staff Portal |
| Any existing patient | their email | temporary password from script 03 | **Create your password** page, then My Account |
| Joseph Frost | `Josephfrost2030@gmail.com` | his old password | blocked until a manager clicks **Activate** |
| Demo patient (script 04) | `thandeka.demo@gmail.com` | `Patient@123` | My Account (history, metrics, receipts) |
| Demo patient (script 04) | `rowan.demo@gmail.com` | `Patient@123` | blocked — account deactivated |

Security answers: Thandeka `durban`, Rowan `cape town`, receptionist `bicycle`.

## 3. Site map

**Public:** Home · Treatments (live prices from `Service`) · About · Contact · Help/FAQ · Register · Log in · Forgot password
**Patient (`/Patient`, role Patient):** Dashboard · Book (free slots only) · My Appointments (cancel ≥24h) · Invoices & Receipts · Progress & Results · Profile
**Staff (`/Portal`, role Staff):** Dashboard · Patients (+history) · Appointments · Clinical Metrics · Treatment Results · Payments & Invoices · BI Reports
**Manager only:** Treatments & Prices · Manage Accounts
**Everywhere:** Help chatbot (bottom-right). **Printable:** appointment confirmation, receipt, every report.

## 4. Verified against the FES source code

| Rule | FES evidence | Website |
|---|---|---|
| Appointment statuses | `book_appointment.cs` writes `Scheduled`; `search_appointment` offers `Completed`, `Cancelled`, `No Show` | same values (`Web.config` → `Status:*`) |
| One appointment at a time (no overlaps) | `book_appointment.cs` clash check | same rule, enforced in a serializable transaction |
| Staff login | `Staff.GetValidCredentials`: plain text, case-sensitive, `Is_Active = 1` | same; `HashPasswords=false` keeps FES logins working |
| First login | `Is_First_Login` → `NewLoginForm` | forced password change, then flag cleared |
| Security answers | stored lower-case; compared lower-case with spaces removed | identical rule |
| Roles | `Doctor`, `Receptionist` | Doctor = manager rights (configurable) |
| `UserAccount` | FES uses it for doctor sign-up requests (`AddDoctor`) | **not used for patients**. Patient logins live on the `Patient` table (script 01). |
| Gender | `char(1)` (`M`/`F`) | `M`/`F`, derived from the SA ID number |
| Payments | insert `Payment` + set `Appointment.Is_Paid = 1` | same, in one transaction |

## 4b. FES change: temporary password + email when a patient is added

1. In `DS_Clinic.xsd`, on the **Patient** TableAdapter → *Add Query* → *UPDATE* → name it `SetTempPassword`:
   ```sql
   UPDATE Patient SET Password = @Password, Is_First_Login = 1, Is_Account_Active = 1 WHERE ID_Number = @ID_Number
   ```
2. In `addPatients.cs`, right after `taPatient.InsertNewPatient(...)`:
   ```csharp
   string tempPassword = GenerateTempPassword();
   taPatient.SetTempPassword(tempPassword, idNumber);
   try
   {
       SendTempPasswordEmail(email, firstName, tempPassword);
       MessageBox.Show("Patient added. Their temporary website password was emailed to " + email + ".");
   }
   catch (Exception ex)   // email failed: give the password to the patient another way
   {
       MessageBox.Show("Patient added, but the email could not be sent (" + ex.Message + ").\n\nTemporary password: " + tempPassword);
   }
   ```
3. Add these methods to `addPatients.cs` (`using System.Net; using System.Net.Mail; using System.Configuration;`):
   ```csharp
   private static string GenerateTempPassword()
   {
       const string up = "ABCDEFGHJKLMNPQRSTUVWXYZ", low = "abcdefghijkmnpqrstuvwxyz", dig = "23456789", sym = "!@#$%*";
       var b = new byte[8];
       using (var rng = System.Security.Cryptography.RandomNumberGenerator.Create()) rng.GetBytes(b);
       return "" + up[b[0] % up.Length] + low[b[1] % low.Length] + low[b[2] % low.Length] + low[b[3] % low.Length]
                 + dig[b[4] % dig.Length] + dig[b[5] % dig.Length] + sym[b[6] % sym.Length] + up[b[7] % up.Length];
   }

   private static void SendTempPasswordEmail(string to, string firstName, string tempPassword)
   {
       string from = ConfigurationManager.AppSettings["SmtpUser"];        // e.g. aestheticclinicssa@gmail.com
       string appPw = ConfigurationManager.AppSettings["SmtpAppPassword"]; // Gmail "App password", NOT the normal password
       using (var msg = new MailMessage(from, to))
       using (var smtp = new SmtpClient("smtp.gmail.com", 587) { EnableSsl = true, Credentials = new NetworkCredential(from, appPw) })
       {
           msg.Subject = "Your AestheticFlow online account";
           msg.Body = "Hello " + firstName + ",\n\nYour online account is ready.\n\nLogin email: " + to +
                      "\nTemporary password: " + tempPassword +
                      "\n\nLog in on our website - you will be asked to create your own password.\n\nAestheticFlow";
           smtp.Send(msg);
       }
   }
   ```
4. In the FES `App.config` add (and add a reference to `System.Configuration` if needed):
   ```xml
   <appSettings>
     <add key="SmtpUser" value="aestheticclinicssa@gmail.com" />
     <add key="SmtpAppPassword" value="xxxx xxxx xxxx xxxx" />
   </appSettings>
   ```
   Gmail requires 2-step verification + an **App password** (Google Account → Security → App passwords).

No other FES change is needed: existing queries list their columns, and the new columns have defaults.
If the FES change isn't ready, managers can create the login on the website instead
(**Manage Accounts → Create login**, which also opens a pre-filled email).

## 5. Issues found in the FES (for your PFR / to fix before M4)

| Level | Issue | Suggested fix |
|---|---|---|
| 3 | `frmPayments` (reportsForm.cs) uses **hard-coded prices** (1800/2800/600/1500), so a price changed on the website isn't used by the FES payment screen. | Read the price: `SELECT Price FROM Service WHERE Service_Name = @name` via a TableAdapter query instead of the if-chain. |
| 3 | `SQLQuery1.sql` is out of date: the live `Appointment` table also has a `notes` column (used by `UpdateNotes`). | Re-script the DB from SSMS for the PFR so the documented schema matches. |
| 4 | Repo contains a stale duplicate of the FES in the root folder; the `.sln` builds `aesthetic_clinic_system_1\`. | Delete the root copy to avoid editing the wrong files. |
| — | `App.config` (with the DB password) is committed to the repo. | Keep the repo private; never paste it into the PFR. |

## 6. Live data review (GroupWst6, 23 Oct 2026)

Checked the real Patient, UserAccount, Appointment and Payment rows against the website's rules.

**Website fixes made because of the live data**

| Found in data | Risk to website | Fix |
|---|---|---|
| 14 of 15 patients have ID numbers that fail the SA checksum / date / gender-digit rules | staff couldn't save edits; editing would have **changed stored gender** (e.g. Clark Kent M to F) | unchanged ID keeps stored DOB + gender; only new/changed IDs are validated |
| 3 phone numbers don't start with 0 (patients 1002, 1003, 2008) | edits blocked | unchanged phone is accepted; new/changed phones validated |
| FES-captured patients with checksum-failing IDs | couldn't register on the website | registration links to the existing record by ID (email or phone must still match) |
| Appointment times have seconds (`14:00:02-14:30:02`, from `DateTime.Now`) | 2-second tails hid free slots (11:30, 14:30, 15:30 on 2026-06-11) | overlap checks ignore seconds |
| Blood Results bookings are 20 min in the FES | website booked 30 min | website uses the exact service duration |

Already compatible: `M`/`F` gender, `Completed`/`Scheduled` statuses, `Payment.Service_Description` = service name,
`UserAccount` roles in mixed case (`doctor`, `Doctor`, `patient`) are matched case-insensitively,
`Security_Question = 'Not Set'` is treated as "no question" (forgot-password tells the user to contact the clinic).

**FES data-quality issues for the PFR (SQA findings)**

| Level | Finding | Follow-up |
|---|---|---|
| 3 | FES accepts invalid SA ID numbers and IDs whose gender digits contradict the Gender field | add Luhn + DOB/gender check to `addPatients` (website already does this) |
| 3 | Future / impossible dates of birth (Sarah Jones 2026-05-29, John Samuel 2026-02-23) | validate DOB <= today in `addPatients` |
| 4 | Contact numbers not starting with 0 (`4536782309`, `1234567890`) | validate `^0\d{9}$` in `addPatients` |
| 4 | Appointment times saved with seconds | strip seconds when building `Start_Time` in `book_appointment` |
| 3 | Passwords stored and visible as plain text in `Staff` and `UserAccount` | known limitation (FES compares plain text); website supports PBKDF2 via `Accounts:HashPasswords` once the FES is updated |

**Demo using your real data**
1. As a Doctor, open **Manage Accounts → Patient online accounts**. Joseph Frost shows *Deactivated*: click **Activate**.
2. Log in as a patient with a temporary password from script 03 → the **Create your password** page appears → set a password
   and security question → their dashboard. Show `Is_First_Login` flipped to 0 and the hashed password in SSMS.
3. Back as staff: **Deactivate** that patient → their login is refused → **Activate** again.
4. BI Reports, "This year": revenue June-October, treatment mix, no-shows, top patients.

## 7. Testing done so far

* All C# compiles with no errors or warnings.
* Every public page was rendered in an ASP.NET host: all return 200; protected pages
  (`/Portal`, `/Patient`, manager pages, image handler) redirect anonymous users to the login page.
* Database deliberately unreachable: pages show friendly messages, nothing crashes, homepage falls back to static content, chatbot still answers.
* Live data rules checked from screenshots (section 6); slot logic re-checked against real 2026-06-11 bookings.
* **Not yet tested:** running against the live GroupWst6 database (logged-in pages), and Azure deployment. Do these in Visual Studio first.
