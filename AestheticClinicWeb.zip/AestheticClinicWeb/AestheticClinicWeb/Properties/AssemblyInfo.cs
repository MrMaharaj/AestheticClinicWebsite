using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("AestheticClinicWeb")]
[assembly: AssemblyDescription("Aesthetic Clinic Web Application")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("AestheticClinicWeb")]
[assembly: AssemblyCopyright("Copyright ©  2026")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("9561726a-db30-41b2-982a-710320af8a50")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
