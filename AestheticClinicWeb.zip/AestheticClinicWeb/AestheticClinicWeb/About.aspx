<%@ Page Title="About" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="About.aspx.cs" Inherits="AestheticClinicWeb.About" %>

<asp:Content ID="c1" ContentPlaceHolderID="MainContent" runat="server">

    <section class="hero" style="padding:60px 0;">
        <div class="container">
            <h1>About AestheticFlow</h1>
            <p>A modern aesthetic clinic built on medical expertise, honesty and genuine care.</p>
        </div>
    </section>

    <section>
        <div class="container">
            <div class="grid grid-2" style="align-items:center;">
                <div>
                    <div class="eyebrow" style="color:var(--gold);font-weight:700;letter-spacing:3px;">OUR STORY</div>
                    <h2 style="color:var(--plum);">Aesthetics, done responsibly</h2>
                    <p>AestheticFlow was founded on a simple belief: aesthetic treatments
                       should enhance who you are, never mask it. Our doctors combine clinical
                       precision with an artistic eye to deliver results that look and feel natural.</p>
                    <p>From your first consultation to your final aftercare check, we take the time
                       to understand your goals and explain every option honestly &mdash; including
                       when a treatment isn&rsquo;t right for you.</p>
                </div>
                <div class="card">
                    <h3>Our Promise</h3>
                    <ul>
                        <li>Registered medical practitioners on every treatment</li>
                        <li>Transparent, upfront pricing</li>
                        <li>Sterile, private, comfortable facilities</li>
                        <li>Aftercare and follow-up as standard</li>
                        <li>No pressure, ever</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <section class="tint">
        <div class="container">
            <div class="section-head">
                <div class="eyebrow">The Team</div>
                <h2>Meet our specialists</h2>
            </div>
            <div class="grid grid-4">
                <div class="card"><div class="icon-badge">&#128104;&#8205;&#9877;&#65039;</div><h3>Dr. Leeyen Singh</h3><p>Medical Director &amp; Aesthetic Physician</p></div>
                <div class="card"><div class="icon-badge">&#128105;&#8205;&#9877;&#65039;</div><h3>Dr. L. Fourie</h3><p>Dermatology &amp; Skin Health</p></div>
                <div class="card"><div class="icon-badge">&#128105;&#8205;&#9877;&#65039;</div><h3>Sr. N. Dlamini</h3><p>Aesthetic Nurse &amp; Laser Therapist</p></div>
                <div class="card"><div class="icon-badge">&#128104;&#8205;&#9877;&#65039;</div><h3>Dr. R. Patel</h3><p>Injectables &amp; Contouring</p></div>
            </div>
        </div>
    </section>

</asp:Content>
