<%@ Page Title="Register" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="Register.aspx.cs" Inherits="AestheticClinicWeb.Account.Register" %>

<asp:Content ID="c1" ContentPlaceHolderID="MainContent" runat="server">
    <section style="padding-top:48px;">
        <div class="container">
            <div class="form-wrap wide">
                <div class="section-head" style="margin-bottom:22px;">
                    <div class="eyebrow">Patient Registration</div>
                    <h2>Create your patient account</h2>
                    <p>Book treatments online, view your results and print receipts. Fields marked * are required.</p>
                </div>

                <asp:Panel ID="pnlForm" runat="server" CssClass="form-card" DefaultButton="btnRegister">
                    <asp:Label ID="lblMessage" runat="server" Visible="false" />
                    <asp:ValidationSummary ID="vs" runat="server" CssClass="msg msg-err" ValidationGroup="reg" HeaderText="Please correct the following:" />

                    <fieldset>
                        <legend>Personal details (as on your ID)</legend>
                        <div class="grid grid-2">
                            <div class="field">
                                <label for="<%= txtFirstName.ClientID %>">First name *</label>
                                <asp:TextBox ID="txtFirstName" runat="server" MaxLength="50" autocomplete="given-name" />
                                <asp:RequiredFieldValidator ID="rfvF" runat="server" ControlToValidate="txtFirstName" ErrorMessage="First name is required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="reg" />
                            </div>
                            <div class="field">
                                <label for="<%= txtLastName.ClientID %>">Last name *</label>
                                <asp:TextBox ID="txtLastName" runat="server" MaxLength="50" autocomplete="family-name" />
                                <asp:RequiredFieldValidator ID="rfvL" runat="server" ControlToValidate="txtLastName" ErrorMessage="Last name is required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="reg" />
                            </div>
                            <div class="field">
                                <label for="<%= txtIdNumber.ClientID %>">SA ID number *</label>
                                <asp:TextBox ID="txtIdNumber" runat="server" MaxLength="13" inputmode="numeric" />
                                <div class="hint">Your date of birth and gender are read from your ID number.</div>
                                <asp:RequiredFieldValidator ID="rfvId" runat="server" ControlToValidate="txtIdNumber" ErrorMessage="ID number is required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="reg" />
                                <asp:RegularExpressionValidator ID="revId" runat="server" ControlToValidate="txtIdNumber" ValidationExpression="^\d{13}$" ErrorMessage="ID number must be exactly 13 digits." Text="13 digits" Display="Dynamic" CssClass="val" ValidationGroup="reg" />
                            </div>
                            <div class="field">
                                <label for="<%= txtPhone.ClientID %>">Cell number *</label>
                                <asp:TextBox ID="txtPhone" runat="server" MaxLength="10" inputmode="tel" placeholder="0821234567" autocomplete="tel" />
                                <asp:RequiredFieldValidator ID="rfvP" runat="server" ControlToValidate="txtPhone" ErrorMessage="Cell number is required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="reg" />
                                <asp:RegularExpressionValidator ID="revP" runat="server" ControlToValidate="txtPhone" ValidationExpression="^\d{10}$" ErrorMessage="Cell number must be 10 digits." Text="Must be 10 digits" Display="Dynamic" CssClass="val" ValidationGroup="reg" />
                            </div>
                        </div>
                        <div class="field">
                            <label for="<%= txtAddress.ClientID %>">Address *</label>
                            <asp:TextBox ID="txtAddress" runat="server" MaxLength="100" autocomplete="street-address" />
                            <asp:RequiredFieldValidator ID="rfvA" runat="server" ControlToValidate="txtAddress" ErrorMessage="Address is required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="reg" />
                        </div>
                        <div class="field">
                            <label for="<%= txtAllergies.ClientID %>">Allergies (optional)</label>
                            <asp:TextBox ID="txtAllergies" runat="server" MaxLength="300" placeholder="e.g. Penicillin, latex - leave blank if none" />
                        </div>
                    </fieldset>

                    <fieldset>
                        <legend>Login details</legend>
                        <div class="field">
                            <label for="<%= txtEmail.ClientID %>">Email address *</label>
                            <asp:TextBox ID="txtEmail" runat="server" TextMode="Email" MaxLength="50" autocomplete="email" />
                            <asp:RequiredFieldValidator ID="rfvE" runat="server" ControlToValidate="txtEmail" ErrorMessage="Email is required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="reg" />
                            <asp:RegularExpressionValidator ID="revE" runat="server" ControlToValidate="txtEmail" ValidationExpression="^[^@\s]+@[^@\s]+\.[^@\s]{2,}$" ErrorMessage="Enter a valid email address." Text="Invalid email" Display="Dynamic" CssClass="val" ValidationGroup="reg" />
                        </div>
                        <div class="grid grid-2">
                            <div class="field">
                                <label for="<%= txtPassword.ClientID %>">Password *</label>
                                <asp:TextBox ID="txtPassword" runat="server" TextMode="Password" MaxLength="100" autocomplete="new-password" />
                                <div class="hint">8+ characters with an uppercase letter, a number and a special character.</div>
                                <asp:RequiredFieldValidator ID="rfvPw" runat="server" ControlToValidate="txtPassword" ErrorMessage="Password is required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="reg" />
                                <asp:RegularExpressionValidator ID="revPw" runat="server" ControlToValidate="txtPassword" ValidationExpression="^(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$" ErrorMessage="Password must be 8+ characters with an uppercase letter, a number and a special character." Text="Too weak" Display="Dynamic" CssClass="val" ValidationGroup="reg" />
                            </div>
                            <div class="field">
                                <label for="<%= txtConfirm.ClientID %>">Confirm password *</label>
                                <asp:TextBox ID="txtConfirm" runat="server" TextMode="Password" MaxLength="100" autocomplete="new-password" />
                                <asp:CompareValidator ID="cvPw" runat="server" ControlToValidate="txtConfirm" ControlToCompare="txtPassword" ErrorMessage="Passwords do not match." Text="Passwords do not match" Display="Dynamic" CssClass="val" ValidationGroup="reg" />
                            </div>
                        </div>
                        <div class="grid grid-2">
                            <div class="field">
                                <label for="<%= ddlQuestion.ClientID %>">Security question *</label>
                                <asp:DropDownList ID="ddlQuestion" runat="server">
                                    <asp:ListItem>What was the first thing you bought with your own money?</asp:ListItem>
                                    <asp:ListItem>What was the first song you remember learning all the words to?</asp:ListItem>
                                    <asp:ListItem>What was the first thing you remember regretting buying?</asp:ListItem>
                                    <asp:ListItem>What was the first thing you remember losing that you really wanted back?</asp:ListItem>
                                    <asp:ListItem>What was the first thing you remember throwing away and later regretting?</asp:ListItem>
                                    <asp:ListItem>What was the first thing you remember making from scratch?</asp:ListItem>
                                </asp:DropDownList>
                            </div>
                            <div class="field">
                                <label for="<%= txtAnswer.ClientID %>">Answer *</label>
                                <asp:TextBox ID="txtAnswer" runat="server" MaxLength="100" autocomplete="off" />
                                <asp:RequiredFieldValidator ID="rfvAns" runat="server" ControlToValidate="txtAnswer" ErrorMessage="Security answer is required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="reg" />
                            </div>
                        </div>
                        <div class="field check">
                            <asp:CheckBox ID="chkConsent" runat="server" Text=" I consent to AestheticFlow storing my personal and medical information to provide treatment (POPIA)." />
                        </div>
                    </fieldset>

                    <asp:Button ID="btnRegister" runat="server" CssClass="btn btn-primary btn-block" Text="Create Account" OnClick="btnRegister_Click" ValidationGroup="reg" />
                    <p class="hint" style="margin-top:16px;">Already have an account? <a href="<%= ResolveUrl("~/Account/Login.aspx") %>">Log in</a></p>
                </asp:Panel>

                <asp:Panel ID="pnlDone" runat="server" Visible="false" CssClass="form-card done">
                    <div class="icon-badge" style="margin:0 auto 10px;">&#10004;</div>
                    <h3 style="text-align:center;">Registration received</h3>
                    <asp:Literal ID="litDone" runat="server" />
                    <a class="btn btn-primary btn-block" href="<%= ResolveUrl("~/Account/Login.aspx") %>">Go to login</a>
                </asp:Panel>
            </div>
        </div>
    </section>
</asp:Content>
