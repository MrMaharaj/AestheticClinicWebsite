using System;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;
using AestheticClinicWeb.Security;

namespace AestheticClinicWeb.Account
{
    public partial class Login : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            if (Request.QueryString["logout"] == "1")
            {
                Auth.SignOut();
                Response.Redirect("~/Account/Login.aspx?bye=1", false);
                Context.ApplicationInstance.CompleteRequest();
                return;
            }
            if (Request.QueryString["bye"] == "1") Ok(lblInfo, "You have been logged out securely.");
            else if (Request.QueryString["reset"] == "1") Ok(lblInfo, "Your password has been changed. Please log in with the new password.");
            else if (Request.IsAuthenticated && !string.IsNullOrEmpty(Request.QueryString["ReturnUrl"]))
                Fail(lblInfo, "Your account does not have access to that page. Log in with a different account if needed.");
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            Page.Validate("login");
            if (!Page.IsValid) return;
            string email = txtEmail.Text.Trim();

            if (Auth.IsLockedOut(email))
            {
                ShowError("Too many failed attempts. For your security this account is locked for 5 minutes.");
                return;
            }

            AccountRepository.LoginResult result = null;
            if (!Safe(lblError, () => result = AccountRepository.Login(email, txtPassword.Text))) return;

            if (result.Identity == null)
            {
                Auth.RegisterFailure(email);
                ShowError(result.Error);
                return;
            }

            Auth.ClearFailures(email);
            Auth.SignIn(result.Identity);
            Session["Role"] = result.Identity.DbRole;
            Session["FullName"] = result.Identity.FullName;

            if (result.Identity.MustChangePassword) { Go("~/Account/ChangePassword.aspx?first=1"); return; }

            string home = result.Identity.Kind == AccountKind.Patient ? "~/Patient/Dashboard.aspx" : "~/Portal/Dashboard.aspx";
            string returnUrl = Request.QueryString["ReturnUrl"];
            // Only follow local return URLs that belong to this user's area (prevents open redirects and role confusion).
            if (!string.IsNullOrEmpty(returnUrl) && returnUrl.StartsWith("/") && !returnUrl.StartsWith("//"))
            {
                string lower = returnUrl.ToLowerInvariant();
                bool allowed = result.Identity.Kind == AccountKind.Patient ? !lower.Contains("/portal/") : !lower.Contains("/patient/");
                if (allowed) { Go(returnUrl); return; }
            }
            Go(home);
        }

        void Go(string url)
        {
            Response.Redirect(url, false);
            Context.ApplicationInstance.CompleteRequest();
        }

        private void ShowError(string message)
        {
            lblError.Text = Server.HtmlEncode(message);
            lblError.Visible = true;
        }
    }
}
