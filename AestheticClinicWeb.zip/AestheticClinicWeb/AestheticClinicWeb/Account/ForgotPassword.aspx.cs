using System;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;
using AestheticClinicWeb.Security;

namespace AestheticClinicWeb.Account
{
    public partial class ForgotPassword : BasePage
    {
        // State is kept in ViewState (tamper-proof via the ASP.NET MAC) between the three steps.
        protected int Step { get { return (int?)ViewState["step"] ?? 1; } set { ViewState["step"] = value; } }
        AccountKind Kind { get { return (AccountKind)(ViewState["kind"] ?? AccountKind.Staff); } set { ViewState["kind"] = value; } }
        int AccId { get { return (int?)ViewState["id"] ?? 0; } set { ViewState["id"] = value; } }
        bool Verified { get { return (bool?)ViewState["ok"] ?? false; } set { ViewState["ok"] = value; } }

        protected void Page_Load(object sender, EventArgs e) { }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            Page.Validate("s1"); if (!Page.IsValid) return;
            string email = txtEmail.Text.Trim();
            if (Auth.IsLockedOut("reset:" + email)) { Fail(lblMsg, "Too many attempts. Please wait 5 minutes and try again."); return; }

            string q = null; AccountKind kind = AccountKind.Staff; int id = 0;
            if (!Safe(lblMsg, () => q = AccountRepository.GetSecurityQuestion(email, out kind, out id))) return;

            if (q == null) { Fail(lblMsg, "We couldn't find an active account with that email address."); return; }
            if (q == "") { Fail(lblMsg, "No security question has been set for this account. Please ask the clinic administrator to reset your password."); return; }

            Kind = kind; AccId = id; Step = 2;
            litQuestion.Text = Server.HtmlEncode(q);
            pnlEmail.Visible = false; pnlQuestion.Visible = true; lblMsg.Visible = false;
        }

        protected void btnCheck_Click(object sender, EventArgs e)
        {
            Page.Validate("s2"); if (!Page.IsValid || AccId == 0) return;
            string key = "reset:" + txtEmail.Text.Trim();
            if (Auth.IsLockedOut(key)) { Fail(lblMsg, "Too many incorrect answers. Please wait 5 minutes and try again."); return; }

            bool ok = false;
            if (!Safe(lblMsg, () => ok = AccountRepository.CheckSecurityAnswer(Kind, AccId, txtAnswer.Text))) return;
            if (!ok) { Auth.RegisterFailure(key); Fail(lblMsg, "That answer is incorrect."); return; }

            Auth.ClearFailures(key);
            Verified = true; Step = 3;
            pnlQuestion.Visible = false; pnlReset.Visible = true; lblMsg.Visible = false;
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            Page.Validate("s3"); if (!Page.IsValid) return;
            if (!Verified || AccId == 0) { Fail(lblMsg, "Please start again."); return; }
            if (!PasswordHasher.IsStrong(txtNew.Text)) { Fail(lblMsg, PasswordHasher.StrengthMessage); return; }
            if (txtNew.Text != txtConfirm.Text) { Fail(lblMsg, "Passwords do not match."); return; }

            if (Safe(lblMsg, () => AccountRepository.SetPassword(Kind, AccId, txtNew.Text)))
                Response.Redirect("~/Account/Login.aspx?reset=1");
        }
    }
}
