<%@ Page Title="Change Password" Language="C#" MasterPageFile="~/App.Master" AutoEventWireup="true" CodeBehind="ChangePassword.aspx.cs" Inherits="AestheticClinicWeb.Account.ChangePassword" %>

<asp:Content ID="c1" ContentPlaceHolderID="WorkContent" runat="server">
    <h1>Account Security</h1>
    <div class="crumb">My account &rsaquo; Change password</div>
    <asp:Label ID="lblMsg" runat="server" Visible="false" />
    <asp:PlaceHolder ID="phFirst" runat="server" Visible="false">
        <div class="msg msg-info"><strong>Welcome! This is your first login.</strong> For your security, create your own strong password
            and choose a security question (used if you ever forget your password). You can use the site once this is done.</div>
    </asp:PlaceHolder>

    <div class="grid grid-2">
        <asp:Panel ID="pnlPw" runat="server" CssClass="panel" DefaultButton="btnChange">
            <h3><%= FirstLogin ? "Create your password" : "Change password" %></h3>
            <div class="field">
                <label for="<%= txtCurrent.ClientID %>"><%= FirstLogin ? "Temporary password (from your email)" : "Current password" %></label>
                <asp:TextBox ID="txtCurrent" runat="server" TextMode="Password" MaxLength="100" autocomplete="current-password" />
                <asp:RequiredFieldValidator ID="rfvC" runat="server" ControlToValidate="txtCurrent" Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="pw" />
            </div>
            <div class="field">
                <label for="<%= txtNew.ClientID %>">New password</label>
                <asp:TextBox ID="txtNew" runat="server" TextMode="Password" MaxLength="100" autocomplete="new-password" />
                <div class="hint">8+ characters with an uppercase letter, a number and a special character.</div>
                <asp:RequiredFieldValidator ID="rfvN" runat="server" ControlToValidate="txtNew" Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="pw" />
                <asp:RegularExpressionValidator ID="revN" runat="server" ControlToValidate="txtNew" ValidationExpression="^(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$" Text="Password is too weak." Display="Dynamic" CssClass="val" ValidationGroup="pw" />
            </div>
            <div class="field">
                <label for="<%= txtConfirm.ClientID %>">Confirm new password</label>
                <asp:TextBox ID="txtConfirm" runat="server" TextMode="Password" MaxLength="100" autocomplete="new-password" />
                <asp:CompareValidator ID="cv" runat="server" ControlToValidate="txtConfirm" ControlToCompare="txtNew" Text="Passwords do not match." Display="Dynamic" CssClass="val" ValidationGroup="pw" />
            </div>
            <asp:PlaceHolder ID="phFirstQ" runat="server" Visible="false">
                <div class="field">
                    <label for="<%= ddlFirstQ.ClientID %>">Security question</label>
                    <asp:DropDownList ID="ddlFirstQ" runat="server">
                        <asp:ListItem>What is the name of your first pet?</asp:ListItem>
                        <asp:ListItem>What city were you born in?</asp:ListItem>
                        <asp:ListItem>What is your mother's maiden name?</asp:ListItem>
                        <asp:ListItem>What was the name of your primary school?</asp:ListItem>
                        <asp:ListItem>What is your favourite food?</asp:ListItem>
                        <asp:ListItem>What was the first thing you bought with your own money?</asp:ListItem>
                    </asp:DropDownList>
                </div>
                <div class="field">
                    <label for="<%= txtFirstA.ClientID %>">Answer</label>
                    <asp:TextBox ID="txtFirstA" runat="server" MaxLength="100" autocomplete="off" />
                    <asp:RequiredFieldValidator ID="rfvFirstA" runat="server" ControlToValidate="txtFirstA" Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="pw" />
                </div>
            </asp:PlaceHolder>
            <asp:Button ID="btnChange" runat="server" Text="Update password" CssClass="btn-sm" OnClick="btnChange_Click" ValidationGroup="pw" />
        </asp:Panel>

        <asp:Panel ID="pnlQ" runat="server" CssClass="panel" DefaultButton="btnQ">
            <h3>Security question</h3>
            <p class="hint">Used to reset your password if you forget it.</p>
            <div class="field">
                <label for="<%= ddlQuestion.ClientID %>">Question</label>
                <asp:DropDownList ID="ddlQuestion" runat="server">
                                    <asp:ListItem>What was the first thing you bought with your own money?</asp:ListItem>
                                    <asp:ListItem>What was the first song you remember learning all the words to?</asp:ListItem>
                                    <asp:ListItem>What was the first thing you remember regretting buying?</asp:ListItem>
                                    <asp:ListItem>What was the first thing you remember losing that you really wanted back?</asp:ListItem>
                                    <asp:ListItem>What was the first thing you remember throwing away and later regretting?</asp:ListItem>
                                    <asp:ListItem>What was the first thing you remember making from scratch?</asp:ListItem>
                                </asp:DropDownList>
            </div>
            <div class="field">
                <label for="<%= txtAnswer.ClientID %>">Answer</label>
                <asp:TextBox ID="txtAnswer" runat="server" MaxLength="100" autocomplete="off" />
                <asp:RequiredFieldValidator ID="rfvA" runat="server" ControlToValidate="txtAnswer" Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="q" />
            </div>
            <div class="field">
                <label for="<%= txtQPassword.ClientID %>">Confirm with your password</label>
                <asp:TextBox ID="txtQPassword" runat="server" TextMode="Password" MaxLength="100" />
                <asp:RequiredFieldValidator ID="rfvQP" runat="server" ControlToValidate="txtQPassword" Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="q" />
            </div>
            <asp:Button ID="btnQ" runat="server" Text="Save security question" CssClass="btn-sm alt" OnClick="btnQ_Click" ValidationGroup="q" />
        </asp:Panel>
    </div>
</asp:Content>
