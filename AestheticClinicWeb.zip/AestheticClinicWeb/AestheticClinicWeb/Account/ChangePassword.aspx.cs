using System;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;
using AestheticClinicWeb.Security;

namespace AestheticClinicWeb.Account
{
    public partial class ChangePassword : BasePage
    {
        protected bool FirstLogin { get { var c = Auth.Current; return c != null && c.MustChangePassword; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            var id = Auth.Current;
            if (id == null) { Response.Redirect("~/Account/Login.aspx"); return; }
            // First login (temporary password): password + security question in one step; other sections hidden.
            phFirst.Visible = phFirstQ.Visible = id.MustChangePassword;
            rfvFirstA.Enabled = id.MustChangePassword;
            pnlQ.Visible = !id.MustChangePassword;
            btnChange.Text = id.MustChangePassword ? "Create password" : "Update password";
        }

        protected void btnChange_Click(object sender, EventArgs e)
        {
            Page.Validate("pw"); if (!Page.IsValid) return;
            var id = Auth.Current;
            if (!PasswordHasher.IsStrong(txtNew.Text)) { Fail(lblMsg, PasswordHasher.StrengthMessage); return; }
            if (txtNew.Text != txtConfirm.Text) { Fail(lblMsg, "Passwords do not match."); return; }
            if (txtNew.Text == txtCurrent.Text) { Fail(lblMsg, "The new password must be different from the current one."); return; }
            bool wasFirst = id.MustChangePassword;
            if (wasFirst && txtFirstA.Text.Trim().Length == 0) { Fail(lblMsg, "Please answer a security question."); return; }

            bool ok = false;
            if (!Safe(lblMsg, () => ok = AccountRepository.VerifyCurrentPassword(id.Kind, id.AccountId, txtCurrent.Text))) return;
            if (!ok) { Fail(lblMsg, wasFirst ? "The temporary password is incorrect. Check the email from the clinic." : "Your current password is incorrect."); return; }

            // Password first: Is_First_Login is cleared only inside SetPassword, i.e. only after the new password is saved.
            if (!Safe(lblMsg, () =>
            {
                AccountRepository.SetPassword(id.Kind, id.AccountId, txtNew.Text);
                if (wasFirst) AccountRepository.SetSecurityQuestion(id.Kind, id.AccountId, ddlFirstQ.SelectedValue, txtFirstA.Text);
            })) return;

            id.MustChangePassword = false;
            Auth.SignIn(id);   // refresh the login ticket so the forced-change flag is cleared
            if (wasFirst)
            {
                Response.Redirect(id.Kind == AccountKind.Patient ? "~/Patient/Dashboard.aspx?welcome=1" : "~/Portal/Dashboard.aspx?welcome=1", false);
                Context.ApplicationInstance.CompleteRequest();
                return;
            }
            Ok(lblMsg, "Your password has been updated successfully.");
        }

        protected void btnQ_Click(object sender, EventArgs e)
        {
            Page.Validate("q"); if (!Page.IsValid) return;
            var id = Auth.Current;
            bool ok = false;
            if (!Safe(lblMsg, () => ok = AccountRepository.VerifyCurrentPassword(id.Kind, id.AccountId, txtQPassword.Text))) return;
            if (!ok) { Fail(lblMsg, "Password incorrect - security question not changed."); return; }
            if (Safe(lblMsg, () => AccountRepository.SetSecurityQuestion(id.Kind, id.AccountId, ddlQuestion.SelectedValue, txtAnswer.Text)))
            {
                txtAnswer.Text = "";
                Ok(lblMsg, "Your security question has been saved.");
            }
        }
    }
}
