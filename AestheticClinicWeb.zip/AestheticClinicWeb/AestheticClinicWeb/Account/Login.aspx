<%@ Page Title="Log in" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="Login.aspx.cs" Inherits="AestheticClinicWeb.Account.Login" %>

<asp:Content ID="c1" ContentPlaceHolderID="MainContent" runat="server">
    <section style="padding-top:56px;">
        <div class="container">
            <div class="form-wrap">
                <div class="section-head" style="margin-bottom:26px;">
                    <div class="eyebrow">Secure Access</div>
                    <h2>Log in</h2>
                    <p>Patients and clinic staff use the same login. You'll be taken to the right area automatically.</p>
                    <p class="hint"><strong>First time?</strong> Use the temporary password the clinic emailed you &mdash; you'll then create your own password.</p>
                </div>

                <asp:Panel ID="pnlLogin" runat="server" CssClass="form-card" DefaultButton="btnLogin">
                    <asp:Label ID="lblInfo" runat="server" Visible="false" />
                    <asp:Label ID="lblError" runat="server" Visible="false" CssClass="msg msg-err" />

                    <div class="field">
                        <label for="<%= txtEmail.ClientID %>">Email address</label>
                        <asp:TextBox ID="txtEmail" runat="server" TextMode="Email" MaxLength="100" autocomplete="username" />
                        <asp:RequiredFieldValidator ID="rfvEmail" runat="server" ControlToValidate="txtEmail" Display="Dynamic" CssClass="val" Text="Please enter your email." ValidationGroup="login" />
                    </div>
                    <div class="field">
                        <label for="<%= txtPassword.ClientID %>">Password</label>
                        <asp:TextBox ID="txtPassword" runat="server" TextMode="Password" MaxLength="100" autocomplete="current-password" />
                        <asp:RequiredFieldValidator ID="rfvPw" runat="server" ControlToValidate="txtPassword" Display="Dynamic" CssClass="val" Text="Please enter your password." ValidationGroup="login" />
                    </div>
                    <asp:Button ID="btnLogin" runat="server" CssClass="btn btn-primary btn-block" Text="Log In" OnClick="btnLogin_Click" ValidationGroup="login" />

                    <p class="hint" style="margin-top:16px;display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px;">
                        <a href="<%= ResolveUrl("~/Account/ForgotPassword.aspx") %>">Forgot password?</a>
                        <span>New patient? <a href="<%= ResolveUrl("~/Account/Register.aspx") %>">Register here</a></span>
                    </p>
                </asp:Panel>
            </div>
        </div>
    </section>
</asp:Content>
