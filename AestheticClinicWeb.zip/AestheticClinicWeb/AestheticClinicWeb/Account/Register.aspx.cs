using System;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;
using AestheticClinicWeb.Security;

namespace AestheticClinicWeb.Account
{
    public partial class Register : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack && Request.IsAuthenticated)
                Response.Redirect(Auth.IsPatient ? "~/Patient/Dashboard.aspx" : "~/Portal/Dashboard.aspx");
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            Page.Validate("reg");
            if (!Page.IsValid) return;

            // Server-side re-validation (never trust the browser)
            DateTime dob; char gender; string idError;
            string idNo = txtIdNumber.Text.Trim();
            PatientRecord onFile = null;
            if (!Safe(lblMessage, () => onFile = PatientRepository.GetByIdNumber(idNo))) return;
            if (onFile != null)
            {
                // Existing clinic record: use its stored details (some FES-captured IDs fail the checksum).
                dob = onFile.Dob; gender = onFile.Gender;
            }
            else
            {
                if (!Check.SaId(idNo, out dob, out gender, out idError)) { Fail(lblMessage, idError); return; }
                if (dob > DateTime.Today.AddYears(-16)) { Fail(lblMessage, "Patients must be 16 or older to register online. Please contact the clinic."); return; }
            }
            if (!Check.Email(txtEmail.Text)) { Fail(lblMessage, "Please enter a valid email address (max 50 characters)."); return; }
            if (onFile == null && !Check.Phone(txtPhone.Text)) { Fail(lblMessage, "Cell number must be 10 digits starting with 0."); return; }
            if (onFile != null && !System.Text.RegularExpressions.Regex.IsMatch(txtPhone.Text.Trim(), @"^\d{10}$")) { Fail(lblMessage, "Cell number must be 10 digits."); return; }
            if (!PasswordHasher.IsStrong(txtPassword.Text)) { Fail(lblMessage, PasswordHasher.StrengthMessage); return; }
            if (txtPassword.Text != txtConfirm.Text) { Fail(lblMessage, "Passwords do not match."); return; }
            if (!chkConsent.Checked) { Fail(lblMessage, "Please tick the consent box to continue."); return; }

            string email = txtEmail.Text.Trim();
            bool inUse = false;
            if (!Safe(lblMessage, () => inUse = AccountRepository.EmailInUse(email, null, onFile == null ? (int?)null : onFile.PatientId))) return;
            if (inUse) { Fail(lblMessage, "This email is already registered. Use 'Forgot password' on the login page if you can't log in."); return; }

            var reg = new AccountRepository.Registration
            {
                FirstName = Check.Trunc(txtFirstName.Text, 50), LastName = Check.Trunc(txtLastName.Text, 50),
                IdNumber = idNo, Gender = gender, Dob = dob, Address = Check.Trunc(txtAddress.Text, 100),
                Phone = txtPhone.Text.Trim(), Email = email, Allergies = txtAllergies.Text.Trim(),
                Password = txtPassword.Text, Question = ddlQuestion.SelectedValue, Answer = txtAnswer.Text
            };

            bool active = false, linked = false;
            if (!Safe(lblMessage, () => active = AccountRepository.RegisterPatient(reg, out linked))) return;

            pnlForm.Visible = false;
            pnlDone.Visible = true;
            litDone.Text = "<p>Thank you, " + Server.HtmlEncode(reg.FirstName) + ". " +
                (linked ? "We found your existing clinic record and added your online account to it. " : "Your patient record has been created. ") +
                (active
                    ? "Your account is active &mdash; you can log in now.</p>"
                    : "Your account is <strong>waiting to be activated</strong> by the clinic (usually within one working day). You can log in once it has been activated.</p>");
        }
    }
}
