<%@ Page Title="Forgot Password" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="ForgotPassword.aspx.cs" Inherits="AestheticClinicWeb.Account.ForgotPassword" %>

<asp:Content ID="c1" ContentPlaceHolderID="MainContent" runat="server">
    <section style="padding-top:56px;">
        <div class="container">
            <div class="form-wrap">
                <div class="section-head" style="margin-bottom:22px;">
                    <div class="eyebrow">Account Recovery</div>
                    <h2>Reset your password</h2>
                    <ol class="steps-inline">
                        <li class="<%= Step >= 1 ? "on" : "" %>">Email</li>
                        <li class="<%= Step >= 2 ? "on" : "" %>">Security question</li>
                        <li class="<%= Step >= 3 ? "on" : "" %>">New password</li>
                    </ol>
                </div>
                <div class="form-card">
                    <asp:Label ID="lblMsg" runat="server" Visible="false" />

                    <asp:Panel ID="pnlEmail" runat="server" DefaultButton="btnNext">
                        <div class="field">
                            <label for="<%= txtEmail.ClientID %>">Email address</label>
                            <asp:TextBox ID="txtEmail" runat="server" TextMode="Email" MaxLength="100" />
                            <asp:RequiredFieldValidator ID="rfvE" runat="server" ControlToValidate="txtEmail" Text="Please enter your email." Display="Dynamic" CssClass="val" ValidationGroup="s1" />
                        </div>
                        <asp:Button ID="btnNext" runat="server" Text="Continue" CssClass="btn btn-primary btn-block" OnClick="btnNext_Click" ValidationGroup="s1" />
                    </asp:Panel>

                    <asp:Panel ID="pnlQuestion" runat="server" Visible="false" DefaultButton="btnCheck">
                        <div class="field">
                            <label>Security question</label>
                            <div class="readonly"><asp:Literal ID="litQuestion" runat="server" /></div>
                        </div>
                        <div class="field">
                            <label for="<%= txtAnswer.ClientID %>">Your answer</label>
                            <asp:TextBox ID="txtAnswer" runat="server" MaxLength="100" autocomplete="off" />
                            <asp:RequiredFieldValidator ID="rfvA" runat="server" ControlToValidate="txtAnswer" Text="Please answer the question." Display="Dynamic" CssClass="val" ValidationGroup="s2" />
                        </div>
                        <asp:Button ID="btnCheck" runat="server" Text="Verify answer" CssClass="btn btn-primary btn-block" OnClick="btnCheck_Click" ValidationGroup="s2" />
                    </asp:Panel>

                    <asp:Panel ID="pnlReset" runat="server" Visible="false" DefaultButton="btnReset">
                        <div class="field">
                            <label for="<%= txtNew.ClientID %>">New password</label>
                            <asp:TextBox ID="txtNew" runat="server" TextMode="Password" MaxLength="100" autocomplete="new-password" />
                            <div class="hint">8+ characters with an uppercase letter, a number and a special character.</div>
                            <asp:RequiredFieldValidator ID="rfvN" runat="server" ControlToValidate="txtNew" Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="s3" />
                            <asp:RegularExpressionValidator ID="revN" runat="server" ControlToValidate="txtNew" ValidationExpression="^(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$" Text="Password is too weak." Display="Dynamic" CssClass="val" ValidationGroup="s3" />
                        </div>
                        <div class="field">
                            <label for="<%= txtConfirm.ClientID %>">Confirm new password</label>
                            <asp:TextBox ID="txtConfirm" runat="server" TextMode="Password" MaxLength="100" autocomplete="new-password" />
                            <asp:CompareValidator ID="cv" runat="server" ControlToValidate="txtConfirm" ControlToCompare="txtNew" Text="Passwords do not match." Display="Dynamic" CssClass="val" ValidationGroup="s3" />
                        </div>
                        <asp:Button ID="btnReset" runat="server" Text="Set new password" CssClass="btn btn-primary btn-block" OnClick="btnReset_Click" ValidationGroup="s3" />
                    </asp:Panel>

                    <p class="hint" style="margin-top:16px;"><a href="<%= ResolveUrl("~/Account/Login.aspx") %>">&larr; Back to login</a></p>
                </div>
            </div>
        </div>
    </section>
</asp:Content>
