<%@ Page Title="Treatments" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="Services.aspx.cs" Inherits="AestheticClinicWeb.Services" %>

<asp:Content ID="c1" ContentPlaceHolderID="MainContent" runat="server">
    <section class="hero" style="padding:60px 0;">
        <div class="container">
            <h1>Our Treatments</h1>
            <p>A full menu of doctor-led aesthetic services with current prices. Final treatment plans are confirmed at your consultation.</p>
        </div>
    </section>

    <section>
        <div class="container">
            <asp:Panel ID="pnlSearch" runat="server" CssClass="filterbar" DefaultButton="btnSearch">
                <div class="field">
                    <label for="<%= txtSearch.ClientID %>">Search treatments</label>
                    <asp:TextBox ID="txtSearch" runat="server" placeholder="e.g. weight loss, PRP, IV" MaxLength="50" />
                </div>
                <div class="field">
                    <label for="<%= ddlCategory.ClientID %>">Category</label>
                    <asp:DropDownList ID="ddlCategory" runat="server" AutoPostBack="true" OnSelectedIndexChanged="Filter_Changed" />
                </div>
                <div class="field field-btn">
                    <asp:Button ID="btnSearch" runat="server" Text="Search" CssClass="btn btn-primary" OnClick="Filter_Changed" />
                    <asp:Button ID="btnClear" runat="server" Text="Clear" CssClass="btn btn-outline" OnClick="btnClear_Click" CausesValidation="false" />
                </div>
            </asp:Panel>

            <asp:Label ID="lblMsg" runat="server" Visible="false" />
            <asp:Literal ID="litCount" runat="server" />

            <asp:Repeater ID="rptServices" runat="server">
                <HeaderTemplate><div class="grid grid-3"></HeaderTemplate>
                <ItemTemplate>
                    <div class="card service-card">
                        <div class="eyebrow-sm"><%#: Eval("Category") %></div>
                        <h3><%#: Eval("Service_Name") %></h3>
                        <p><%#: Eval("Description") %></p>
                        <div class="meta">&#9201; <%#: Eval("Duration") %> minutes</div>
                        <div class="price"><%#: Ui.Money(Eval("Price")) %></div>
                        <a class="btn-sm" href="<%# BookUrl(Eval("Service_ID")) %>">Book this treatment</a>
                    </div>
                </ItemTemplate>
                <FooterTemplate></div></FooterTemplate>
            </asp:Repeater>
            <asp:PlaceHolder ID="phEmpty" runat="server" Visible="false">
                <div class="empty">No treatments match your search. <a href="<%= ResolveUrl("~/Services.aspx") %>">Show all treatments</a></div>
            </asp:PlaceHolder>
        </div>
    </section>
</asp:Content>
