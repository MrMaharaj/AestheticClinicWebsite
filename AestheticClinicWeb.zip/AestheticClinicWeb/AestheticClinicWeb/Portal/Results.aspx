<%@ Page Title="Treatment Results" Language="C#" MasterPageFile="~/App.Master" AutoEventWireup="true" CodeBehind="Results.aspx.cs" Inherits="AestheticClinicWeb.Portal.Results" %>
<asp:Content ID="c1" ContentPlaceHolderID="WorkContent" runat="server">
    <h1>Treatment Results</h1>
    <div class="crumb">Staff Portal &rsaquo; Treatment results</div>
    <asp:Label ID="lblMsg" runat="server" Visible="false" />

    <div class="panel">
        <h3>Record a result</h3>
        <div class="grid grid-2">
            <div class="field"><label for="<%= ddlPatient.ClientID %>">Patient</label>
                <asp:DropDownList ID="ddlPatient" runat="server" AutoPostBack="true" OnSelectedIndexChanged="ddlPatient_Changed" /></div>
            <div class="field"><label for="<%= ddlAppt.ClientID %>">Appointment</label>
                <asp:DropDownList ID="ddlAppt" runat="server" />
                <asp:RequiredFieldValidator ID="rfvAp" runat="server" ControlToValidate="ddlAppt" InitialValue="" Text="Select an appointment" Display="Dynamic" CssClass="val" ValidationGroup="r" /></div>
            <div class="field"><label for="<%= txtDate.ClientID %>">Result date</label><asp:TextBox ID="txtDate" runat="server" TextMode="Date" />
                <asp:RequiredFieldValidator ID="rfvD" runat="server" ControlToValidate="txtDate" Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="r" /></div>
            <div class="field"><label for="<%= txtResult.ClientID %>">Result / outcome *</label><asp:TextBox ID="txtResult" runat="server" MaxLength="100" placeholder="e.g. Significant reduction in fine lines" />
                <asp:RequiredFieldValidator ID="rfvR" runat="server" ControlToValidate="txtResult" Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="r" /></div>
            <div class="field"><label for="<%= txtNotes.ClientID %>">Notes</label><asp:TextBox ID="txtNotes" runat="server" TextMode="MultiLine" Rows="2" MaxLength="250" /></div>
            <div class="field"><label>Photos (JPG/PNG, max 2 MB each)</label>
                <div class="inline"><span class="hint">Before</span> <asp:FileUpload ID="fuBefore" runat="server" accept="image/*" /></div>
                <div class="inline"><span class="hint">After</span> <asp:FileUpload ID="fuAfter" runat="server" accept="image/*" /></div></div>
        </div>
        <asp:Button ID="btnSave" runat="server" Text="Save result" CssClass="btn-sm" OnClick="btnSave_Click" ValidationGroup="r" />
    </div>

    <div class="panel">
        <h3>Results <asp:Literal ID="litFor" runat="server" /></h3>
        <div class="table-wrap">
        <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="data" GridLines="None" OnRowCommand="gv_RowCommand"
                      AllowPaging="true" PageSize="15" OnPageIndexChanging="gv_PageIndexChanging" EmptyDataText="No results recorded." PagerStyle-CssClass="pager">
            <Columns>
                <asp:TemplateField HeaderText="Date"><ItemTemplate><%# Ui.Date(Eval("Result_Date")) %></ItemTemplate></asp:TemplateField>
                <asp:BoundField DataField="PatientName" HeaderText="Patient" />
                <asp:BoundField DataField="Service" HeaderText="Treatment" />
                <asp:BoundField DataField="Result" HeaderText="Result" />
                <asp:BoundField DataField="Notes" HeaderText="Notes" />
                <asp:TemplateField HeaderText="Photos">
                    <ItemTemplate>
                        <%# Convert.ToInt32(Eval("HasBefore")) == 1 ? "<a class=\"thumb\" target=\"_blank\" href=\"" + ResolveUrl("~/Handlers/Image.ashx?type=before&id=" + Eval("Result_ID")) + "\"><img loading=\"lazy\" alt=\"Before\" src=\"" + ResolveUrl("~/Handlers/Image.ashx?type=before&id=" + Eval("Result_ID")) + "\" /></a>" : "" %>
                        <%# Convert.ToInt32(Eval("HasAfter")) == 1 ? "<a class=\"thumb\" target=\"_blank\" href=\"" + ResolveUrl("~/Handlers/Image.ashx?type=after&id=" + Eval("Result_ID")) + "\"><img loading=\"lazy\" alt=\"After\" src=\"" + ResolveUrl("~/Handlers/Image.ashx?type=after&id=" + Eval("Result_ID")) + "\" /></a>" : "" %>
                    </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField><ItemTemplate>
                    <asp:LinkButton ID="lbDel" runat="server" CommandName="Del" CommandArgument='<%# Eval("Result_ID") %>' CssClass="link danger" CausesValidation="false" OnClientClick="return confirm('Delete this result and its photos?');">Delete</asp:LinkButton>
                </ItemTemplate></asp:TemplateField>
            </Columns>
        </asp:GridView>
        </div>
    </div>
</asp:Content>
