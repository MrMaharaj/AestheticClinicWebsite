<%@ Page Title="Patients" Language="C#" MasterPageFile="~/App.Master" AutoEventWireup="true" CodeBehind="Patients.aspx.cs" Inherits="AestheticClinicWeb.Portal.Patients" %>
<asp:Content ID="c1" ContentPlaceHolderID="WorkContent" runat="server">
    <h1>Patients</h1>
    <div class="crumb">Staff Portal &rsaquo; Patients</div>
    <asp:Label ID="lblMsg" runat="server" Visible="false" />

    <asp:Panel ID="pnlSearch" runat="server" CssClass="toolbar" DefaultButton="btnSearch">
        <asp:TextBox ID="txtSearch" runat="server" placeholder="Search name, ID number, email, phone or patient #" CssClass="search" MaxLength="50" aria-label="Search patients" />
        <asp:Button ID="btnSearch" runat="server" Text="Search" CssClass="btn-sm" OnClick="btnSearch_Click" CausesValidation="false" />
        <asp:CheckBox ID="chkInactive" runat="server" Text=" Include inactive" AutoPostBack="true" OnCheckedChanged="btnSearch_Click" CssClass="inline-check" />
        <asp:Button ID="btnNew" runat="server" Text="+ Add patient" CssClass="btn-sm alt" OnClick="btnNew_Click" CausesValidation="false" />
    </asp:Panel>

    <div class="table-wrap">
    <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="data" GridLines="None" DataKeyNames="Patient_ID"
                  AllowPaging="true" PageSize="15" OnPageIndexChanging="gv_PageIndexChanging" OnRowCommand="gv_RowCommand"
                  EmptyDataText="No patients match your search." PagerStyle-CssClass="pager">
        <Columns>
            <asp:BoundField DataField="Patient_ID" HeaderText="#" />
            <asp:TemplateField HeaderText="Name"><ItemTemplate><a class="link" href="<%# ResolveUrl("~/Portal/PatientHistory.aspx?id=" + Eval("Patient_ID")) %>"><%#: Eval("First_Name") + " " + Eval("Last_Name") %></a></ItemTemplate></asp:TemplateField>
            <asp:BoundField DataField="ID_Number" HeaderText="ID number" />
            <asp:TemplateField HeaderText="Gender"><ItemTemplate><%#: Ui.Gender(Eval("Gender")) %></ItemTemplate></asp:TemplateField>
            <asp:BoundField DataField="Contact_No" HeaderText="Contact" />
            <asp:BoundField DataField="Email" HeaderText="Email" />
            <asp:BoundField DataField="Allergies" HeaderText="Allergies" />
            <asp:TemplateField HeaderText="Status"><ItemTemplate><%# Ui.StatusPill(Convert.ToBoolean(Eval("Is_Active")) ? "Active" : "Inactive") %></ItemTemplate></asp:TemplateField>
            <asp:TemplateField HeaderText="Actions">
                <ItemTemplate>
                    <asp:LinkButton ID="lbEdit" runat="server" CommandName="EditP" CommandArgument='<%# Eval("Patient_ID") %>' CssClass="link" CausesValidation="false">Edit</asp:LinkButton>
                    <a class="link" href="<%# ResolveUrl("~/Portal/PatientHistory.aspx?id=" + Eval("Patient_ID")) %>">History</a>
                    <asp:LinkButton ID="lbToggle" runat="server" CommandName="Toggle" CommandArgument='<%# Eval("Patient_ID") %>' CssClass="link" CausesValidation="false"
                        OnClientClick="return confirm('Change this patient\'s active status?');"><%# Convert.ToBoolean(Eval("Is_Active")) ? "Deactivate" : "Reactivate" %></asp:LinkButton>
                    <asp:LinkButton ID="lbDel" runat="server" CommandName="Del" CommandArgument='<%# Eval("Patient_ID") %>' CssClass="link danger" CausesValidation="false"
                        OnClientClick="return confirm('Permanently delete this patient? Only possible if they have no history.');">Delete</asp:LinkButton>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
    </asp:GridView>
    </div>

    <asp:Panel ID="pnlForm" runat="server" CssClass="panel" Visible="false" DefaultButton="btnSave">
        <h3><asp:Literal ID="litFormTitle" runat="server" Text="Add patient" /></h3>
        <asp:HiddenField ID="hfId" runat="server" Value="0" />
        <asp:ValidationSummary ID="vs" runat="server" CssClass="msg msg-err" ValidationGroup="pat" HeaderText="Please correct the following:" />
        <div class="grid grid-2">
            <div class="field"><label for="<%= txtFirst.ClientID %>">First name *</label><asp:TextBox ID="txtFirst" runat="server" MaxLength="50" />
                <asp:RequiredFieldValidator ID="r1" runat="server" ControlToValidate="txtFirst" ErrorMessage="First name is required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="pat" /></div>
            <div class="field"><label for="<%= txtLast.ClientID %>">Last name *</label><asp:TextBox ID="txtLast" runat="server" MaxLength="50" />
                <asp:RequiredFieldValidator ID="r2" runat="server" ControlToValidate="txtLast" ErrorMessage="Last name is required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="pat" /></div>
            <div class="field"><label for="<%= txtIdNo.ClientID %>">SA ID number *</label><asp:TextBox ID="txtIdNo" runat="server" MaxLength="13" inputmode="numeric" />
                <div class="hint">Date of birth and gender are derived from the ID number.</div>
                <asp:RequiredFieldValidator ID="r3" runat="server" ControlToValidate="txtIdNo" ErrorMessage="ID number is required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="pat" />
                <asp:RegularExpressionValidator ID="re3" runat="server" ControlToValidate="txtIdNo" ValidationExpression="^\d{13}$" ErrorMessage="ID number must be 13 digits." Text="13 digits" Display="Dynamic" CssClass="val" ValidationGroup="pat" /></div>
            <div class="field"><label for="<%= txtPhone.ClientID %>">Contact number *</label><asp:TextBox ID="txtPhone" runat="server" MaxLength="10" inputmode="tel" />
                <asp:RequiredFieldValidator ID="r4" runat="server" ControlToValidate="txtPhone" ErrorMessage="Contact number is required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="pat" />
                <asp:RegularExpressionValidator ID="re4" runat="server" ControlToValidate="txtPhone" ValidationExpression="^\d{10}$" ErrorMessage="Contact number must be 10 digits starting with 0." Text="Must be 10 digits" Display="Dynamic" CssClass="val" ValidationGroup="pat" /></div>
            <div class="field"><label for="<%= txtEmail.ClientID %>">Email *</label><asp:TextBox ID="txtEmail" runat="server" TextMode="Email" MaxLength="50" />
                <asp:RequiredFieldValidator ID="r5" runat="server" ControlToValidate="txtEmail" ErrorMessage="Email is required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="pat" />
                <asp:RegularExpressionValidator ID="re5" runat="server" ControlToValidate="txtEmail" ValidationExpression="^[^@\s]+@[^@\s]+\.[^@\s]{2,}$" ErrorMessage="Enter a valid email." Text="Invalid email" Display="Dynamic" CssClass="val" ValidationGroup="pat" /></div>
            <div class="field"><label for="<%= txtAddress.ClientID %>">Address *</label><asp:TextBox ID="txtAddress" runat="server" MaxLength="100" />
                <asp:RequiredFieldValidator ID="r6" runat="server" ControlToValidate="txtAddress" ErrorMessage="Address is required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="pat" /></div>
            <div class="field"><label for="<%= txtAllergies.ClientID %>">Allergies</label><asp:TextBox ID="txtAllergies" runat="server" TextMode="MultiLine" Rows="2" /></div>
            <div class="field"><label for="<%= txtNotes.ClientID %>">Extra notes</label><asp:TextBox ID="txtNotes" runat="server" TextMode="MultiLine" Rows="2" /></div>
        </div>
        <div class="toolbar">
            <asp:Button ID="btnSave" runat="server" Text="Save patient" CssClass="btn-sm" OnClick="btnSave_Click" ValidationGroup="pat" />
            <asp:Button ID="btnCancel" runat="server" Text="Cancel" CssClass="btn-sm alt" OnClick="btnCancel_Click" CausesValidation="false" />
        </div>
    </asp:Panel>
</asp:Content>
