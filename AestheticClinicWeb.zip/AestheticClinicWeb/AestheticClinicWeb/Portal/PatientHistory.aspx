<%@ Page Title="Patient History" Language="C#" MasterPageFile="~/App.Master" AutoEventWireup="true" CodeBehind="PatientHistory.aspx.cs" Inherits="AestheticClinicWeb.Portal.PatientHistory" %>
<asp:Content ID="c1" ContentPlaceHolderID="WorkContent" runat="server">
    <h1><asp:Literal ID="litName" runat="server" Text="Patient history" /></h1>
    <div class="crumb"><a href="<%= ResolveUrl("~/Portal/Patients.aspx") %>">Patients</a> &rsaquo; History</div>
    <asp:Label ID="lblMsg" runat="server" Visible="false" />

    <asp:PlaceHolder ID="phBody" runat="server">
        <div class="stat-row">
            <div class="stat-box"><div class="k">Appointments</div><div class="v"><asp:Literal ID="litAppts" runat="server" /></div></div>
            <div class="stat-box"><div class="k">Completed visits</div><div class="v"><asp:Literal ID="litDone" runat="server" /></div></div>
            <div class="stat-box"><div class="k">Total paid</div><div class="v"><asp:Literal ID="litPaid" runat="server" /></div></div>
            <div class="stat-box"><div class="k">Web account</div><div class="v sm"><asp:Literal ID="litWeb" runat="server" /></div></div>
        </div>

        <div class="panel">
            <h3>Details</h3>
            <dl class="kv cols">
                <dt>Patient #</dt><dd><asp:Literal ID="litPid" runat="server" /></dd>
                <dt>ID number</dt><dd><asp:Literal ID="litIdNo" runat="server" /></dd>
                <dt>Date of birth</dt><dd><asp:Literal ID="litDob" runat="server" /></dd>
                <dt>Contact</dt><dd><asp:Literal ID="litContact" runat="server" /></dd>
                <dt>Address</dt><dd><asp:Literal ID="litAddress" runat="server" /></dd>
                <dt>Allergies</dt><dd class="warn"><asp:Literal ID="litAllergies" runat="server" /></dd>
            </dl>
            <div class="toolbar">
                <a class="btn-sm" href="<%= ResolveUrl("~/Portal/Patients.aspx?edit=" + PatientIdQ) %>">Edit details</a>
                <a class="btn-sm alt" href="<%= ResolveUrl("~/Portal/Appointments.aspx?patient=" + PatientIdQ) %>">Book appointment</a>
                <a class="btn-sm alt" href="<%= ResolveUrl("~/Portal/Metrics.aspx?patient=" + PatientIdQ) %>">Record metrics</a>
                <a class="btn-sm alt" href="<%= ResolveUrl("~/Portal/Results.aspx?patient=" + PatientIdQ) %>">Record result</a>
            </div>
        </div>

        <div class="panel"><h3>Appointments (website + front-end system)</h3>
            <div class="table-wrap">
            <asp:GridView ID="gvAppts" runat="server" AutoGenerateColumns="false" CssClass="data" GridLines="None" EmptyDataText="No appointments.">
                <Columns>
                    <asp:BoundField DataField="Appointment_ID" HeaderText="#" />
                    <asp:TemplateField HeaderText="Date"><ItemTemplate><%# Ui.Date(Eval("Date")) %> <%# Ui.Time(Eval("Start_Time")) %></ItemTemplate></asp:TemplateField>
                    <asp:BoundField DataField="Service_Name" HeaderText="Treatment" />
                    <asp:TemplateField HeaderText="Status"><ItemTemplate><%# Ui.StatusPill(Eval("Status")) %></ItemTemplate></asp:TemplateField>
                    <asp:TemplateField HeaderText="Payment"><ItemTemplate><%# Ui.PaidPill(Eval("Is_Paid")) %></ItemTemplate></asp:TemplateField>
                </Columns>
            </asp:GridView></div>
        </div>
        <div class="panel"><h3>Payments</h3>
            <div class="table-wrap">
            <asp:GridView ID="gvPay" runat="server" AutoGenerateColumns="false" CssClass="data" GridLines="None" EmptyDataText="No payments.">
                <Columns>
                    <asp:BoundField DataField="Payment_ID" HeaderText="Receipt #" />
                    <asp:TemplateField HeaderText="Date"><ItemTemplate><%# Ui.Date(Eval("Date")) %></ItemTemplate></asp:TemplateField>
                    <asp:BoundField DataField="Service_Description" HeaderText="Treatment" />
                    <asp:TemplateField HeaderText="Amount"><ItemTemplate><%# Ui.Money(Eval("Amount")) %></ItemTemplate></asp:TemplateField>
                    <asp:TemplateField><ItemTemplate><a class="link" target="_blank" href="<%# ResolveUrl("~/Print/Receipt.aspx?id=" + Eval("Payment_ID")) %>">Receipt</a></ItemTemplate></asp:TemplateField>
                </Columns>
            </asp:GridView></div>
        </div>
        <div class="panel"><h3>Clinical metrics</h3>
            <div class="table-wrap">
            <asp:GridView ID="gvMetrics" runat="server" AutoGenerateColumns="false" CssClass="data" GridLines="None" EmptyDataText="No metrics recorded.">
                <Columns>
                    <asp:TemplateField HeaderText="Date"><ItemTemplate><%# Ui.Date(Eval("Date_Recorded")) %></ItemTemplate></asp:TemplateField>
                    <asp:BoundField DataField="Weight_kg" HeaderText="Weight (kg)" />
                    <asp:BoundField DataField="Abdominal_Circumference_cm" HeaderText="Abdominal (cm)" />
                    <asp:BoundField DataField="BMI" HeaderText="BMI" />
                    <asp:BoundField DataField="Blood_Pressure" HeaderText="BP" />
                    <asp:BoundField DataField="Notes" HeaderText="Notes" />
                </Columns>
            </asp:GridView></div>
        </div>
    </asp:PlaceHolder>
</asp:Content>
