using System;
using System.Data;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;

namespace AestheticClinicWeb.Portal
{
    /// <summary>Customer search result detail: every transaction for one patient, from both systems.</summary>
    public partial class PatientHistory : StaffPage
    {
        protected int PatientIdQ { get { return QueryInt("id"); } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            bool ok = Safe(lblMsg, () =>
            {
                var p = PatientRepository.Get(PatientIdQ);
                if (p == null) { phBody.Visible = false; Fail(lblMsg, "Patient not found."); return; }
                litName.Text = Server.HtmlEncode(p.FirstName + " " + p.LastName) + (p.IsActive ? "" : " <span class=\"pill pill-no\">Inactive</span>");
                litPid.Text = p.PatientId.ToString(); litIdNo.Text = Server.HtmlEncode(p.IdNumber);
                litDob.Text = p.Dob.ToString("yyyy-MM-dd") + " (" + Age(p.Dob) + " yrs, " + Ui.Gender(p.Gender.ToString()) + ")";
                litContact.Text = Server.HtmlEncode(p.Phone + " / " + p.Email); litAddress.Text = Server.HtmlEncode(p.Address);
                litAllergies.Text = string.IsNullOrWhiteSpace(p.Allergies) ? "None recorded" : Server.HtmlEncode(p.Allergies);

                var appts = AppointmentRepository.Search(null, null, "", "", p.PatientId);
                var pays = PaymentRepository.Search(null, null, "", p.PatientId);
                gvAppts.DataSource = appts; gvAppts.DataBind();
                gvPay.DataSource = pays; gvPay.DataBind();
                gvMetrics.DataSource = ClinicalRepository.Metrics(p.PatientId); gvMetrics.DataBind();

                int done = 0; decimal paid = 0;
                foreach (DataRow r in appts.Rows) if (Convert.ToString(r["Status"]) == ClinicSettings.StatusCompleted) done++;
                foreach (DataRow r in pays.Rows) paid += Convert.ToDecimal(r["Amount"]);
                litAppts.Text = appts.Rows.Count.ToString(); litDone.Text = done.ToString(); litPaid.Text = Ui.Money(paid);
                litWeb.Text = Ui.StatusPill(AccountRepository.PatientAccountState(p.PatientId));
            });
            if (!ok) phBody.Visible = false;
        }

        static int Age(DateTime dob)
        {
            int a = DateTime.Today.Year - dob.Year;
            if (dob.Date > DateTime.Today.AddYears(-a)) a--;
            return a;
        }
    }
}
