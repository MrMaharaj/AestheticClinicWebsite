using System;
using System.Data;
using System.Web.UI.WebControls;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;

namespace AestheticClinicWeb.Portal
{
    public partial class Results : StaffPage
    {
        int? SelectedPatient { get { int p; return int.TryParse(ddlPatient.SelectedValue, out p) ? (int?)p : null; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            Page.Form.Enctype = "multipart/form-data";
            if (IsPostBack) return;
            txtDate.Text = DateTime.Today.ToString("yyyy-MM-dd");
            Safe(lblMsg, () =>
            {
                ddlPatient.Items.Add(new ListItem("-- All patients --", ""));
                foreach (DataRow r in PatientRepository.ActiveForDropdown().Rows) ddlPatient.Items.Add(new ListItem(r["Display"].ToString(), r["Patient_ID"].ToString()));
            });
            int pre = QueryInt("patient");
            if (pre > 0 && ddlPatient.Items.FindByValue(pre.ToString()) != null) ddlPatient.SelectedValue = pre.ToString();
            FillAppts(); Bind();
        }

        void FillAppts()
        {
            Safe(lblMsg, () =>
            {
                ddlAppt.Items.Clear();
                ddlAppt.Items.Add(new ListItem(SelectedPatient == null ? "-- Select a patient first --" : "-- Select appointment --", ""));
                if (SelectedPatient == null) return;
                foreach (DataRow r in AppointmentRepository.ForDropdown(SelectedPatient, true).Rows) ddlAppt.Items.Add(new ListItem(r["Display"].ToString(), r["Appointment_ID"].ToString()));
            });
        }

        void Bind()
        {
            litFor.Text = SelectedPatient == null ? "(all patients)" : "for " + Server.HtmlEncode(ddlPatient.SelectedItem.Text);
            Safe(lblMsg, () => { gv.DataSource = ClinicalRepository.Results(SelectedPatient); gv.DataBind(); });
        }

        protected void ddlPatient_Changed(object sender, EventArgs e) { gv.PageIndex = 0; FillAppts(); Bind(); }
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e) { gv.PageIndex = e.NewPageIndex; Bind(); }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            Page.Validate("r"); if (!Page.IsValid) return;
            int appt; DateTime? d = ParseDate(txtDate.Text);
            if (!int.TryParse(ddlAppt.SelectedValue, out appt)) { Fail(lblMsg, "Please select an appointment."); return; }
            if (d == null || d.Value > DateTime.Today) { Fail(lblMsg, "Result date must be today or earlier."); return; }
            string e1, e2; var before = ReadImage(fuBefore, out e1); var after = ReadImage(fuAfter, out e2);
            if (e1 != null || e2 != null) { Fail(lblMsg, e1 ?? e2); return; }

            if (Safe(lblMsg, () => ClinicalRepository.AddResult(appt, d.Value, Check.Trunc(txtResult.Text, 100), Check.Trunc(txtNotes.Text, 250), before, after)))
            {
                Ok(lblMsg, "Result saved. The patient can now view it (and any photos) under My Progress & Results.");
                txtResult.Text = txtNotes.Text = "";
                Bind();
            }
        }

        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName != "Del") return;
            int id = Convert.ToInt32(e.CommandArgument);
            if (Safe(lblMsg, () => ClinicalRepository.DeleteResult(id))) Ok(lblMsg, "Result deleted.");
            Bind();
        }
    }
}
