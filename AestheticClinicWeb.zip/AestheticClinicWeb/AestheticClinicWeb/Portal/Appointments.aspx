<%@ Page Title="Appointments" Language="C#" MasterPageFile="~/App.Master" AutoEventWireup="true" CodeBehind="Appointments.aspx.cs" Inherits="AestheticClinicWeb.Portal.Appointments" %>
<asp:Content ID="c1" ContentPlaceHolderID="WorkContent" runat="server">
    <h1>Appointments</h1>
    <div class="crumb">Staff Portal &rsaquo; Appointments</div>
    <asp:Label ID="lblMsg" runat="server" Visible="false" />

    <details class="panel collapsible" id="bookPanel" <%= BookOpen ? "open" : "" %>>
        <summary><h3 style="display:inline;">&#10010; Book an appointment</h3></summary>
        <asp:Panel ID="pnlBook" runat="server" DefaultButton="btnFindPatient">
            <div class="grid grid-2">
                <div class="field">
                    <label for="<%= txtPatientFind.ClientID %>">Find patient</label>
                    <div class="inline">
                        <asp:TextBox ID="txtPatientFind" runat="server" placeholder="Name, ID number or phone" MaxLength="50" />
                        <asp:Button ID="btnFindPatient" runat="server" Text="Find" CssClass="btn-sm alt" OnClick="btnFindPatient_Click" CausesValidation="false" />
                    </div>
                </div>
                <div class="field">
                    <label for="<%= ddlPatient.ClientID %>">Patient</label>
                    <asp:DropDownList ID="ddlPatient" runat="server" />
                </div>
                <div class="field">
                    <label for="<%= ddlService.ClientID %>">Treatment</label>
                    <asp:DropDownList ID="ddlService" runat="server" AutoPostBack="true" OnSelectedIndexChanged="Slots_Changed" />
                </div>
                <div class="field">
                    <label for="<%= txtDate.ClientID %>">Date</label>
                    <asp:TextBox ID="txtDate" runat="server" TextMode="Date" AutoPostBack="true" OnTextChanged="Slots_Changed" />
                </div>
            </div>
            <label>Free times</label>
            <asp:RadioButtonList ID="rblSlots" runat="server" RepeatLayout="Flow" RepeatDirection="Horizontal" CssClass="slots" />
            <asp:Literal ID="litSlots" runat="server" />
            <div class="toolbar" style="margin-top:12px;">
                <asp:Button ID="btnBook" runat="server" Text="Book appointment" CssClass="btn-sm" OnClick="btnBook_Click" CausesValidation="false" />
            </div>
        </asp:Panel>
    </details>

    <asp:Panel ID="pnlFilter" runat="server" CssClass="filterbar" DefaultButton="btnFilter">
        <div class="field"><label for="<%= txtFrom.ClientID %>">From</label><asp:TextBox ID="txtFrom" runat="server" TextMode="Date" /></div>
        <div class="field"><label for="<%= txtTo.ClientID %>">To</label><asp:TextBox ID="txtTo" runat="server" TextMode="Date" /></div>
        <div class="field"><label for="<%= ddlStatus.ClientID %>">Status</label><asp:DropDownList ID="ddlStatus" runat="server" /></div>
        <div class="field"><label for="<%= txtFind.ClientID %>">Patient / treatment / #</label><asp:TextBox ID="txtFind" runat="server" MaxLength="50" /></div>
        <div class="field field-btn">
            <asp:Button ID="btnFilter" runat="server" Text="Search" CssClass="btn-sm" OnClick="btnFilter_Click" CausesValidation="false" />
            <asp:Button ID="btnToday" runat="server" Text="Today" CssClass="btn-sm alt" OnClick="btnToday_Click" CausesValidation="false" />
            <asp:Button ID="btnWeek" runat="server" Text="Next 7 days" CssClass="btn-sm alt" OnClick="btnWeek_Click" CausesValidation="false" />
        </div>
    </asp:Panel>
    <asp:Literal ID="litCount" runat="server" />

    <div class="table-wrap">
    <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="data" GridLines="None" DataKeyNames="Appointment_ID"
                  AllowPaging="true" PageSize="20" OnPageIndexChanging="gv_PageIndexChanging" OnRowCommand="gv_RowCommand"
                  EmptyDataText="No appointments match the filter." PagerStyle-CssClass="pager">
        <Columns>
            <asp:BoundField DataField="Appointment_ID" HeaderText="#" />
            <asp:TemplateField HeaderText="Date"><ItemTemplate><%# Ui.Date(Eval("Date")) %></ItemTemplate></asp:TemplateField>
            <asp:TemplateField HeaderText="Time"><ItemTemplate><%# Ui.Time(Eval("Start_Time")) %>&ndash;<%# Ui.Time(Eval("End_Time")) %></ItemTemplate></asp:TemplateField>
            <asp:TemplateField HeaderText="Patient"><ItemTemplate><a class="link" href="<%# ResolveUrl("~/Portal/PatientHistory.aspx?id=" + Eval("Patient_ID")) %>"><%#: Eval("PatientName") %></a></ItemTemplate></asp:TemplateField>
            <asp:BoundField DataField="Service_Name" HeaderText="Treatment" />
            <asp:TemplateField HeaderText="Status"><ItemTemplate><%# Ui.StatusPill(Eval("Status")) %></ItemTemplate></asp:TemplateField>
            <asp:TemplateField HeaderText="Paid"><ItemTemplate><%# Ui.PaidPill(Eval("Is_Paid")) %></ItemTemplate></asp:TemplateField>
            <asp:TemplateField HeaderText="Actions">
                <ItemTemplate>
                    <asp:LinkButton ID="lbDone" runat="server" CommandName="Done" CommandArgument='<%# Eval("Appointment_ID") %>' CssClass="link" Visible='<%# IsBooked(Eval("Status")) %>'>Complete</asp:LinkButton>
                    <asp:LinkButton ID="lbNo" runat="server" CommandName="NoShow" CommandArgument='<%# Eval("Appointment_ID") %>' CssClass="link" Visible='<%# IsBooked(Eval("Status")) %>' OnClientClick="return confirm('Mark as no-show?');">No-show</asp:LinkButton>
                    <asp:LinkButton ID="lbCx" runat="server" CommandName="Cancel" CommandArgument='<%# Eval("Appointment_ID") %>' CssClass="link danger" Visible='<%# IsBooked(Eval("Status")) %>' OnClientClick="return confirm('Cancel this appointment and free the slot?');">Cancel</asp:LinkButton>
                    <asp:LinkButton ID="lbRe" runat="server" CommandName="Rebook" CommandArgument='<%# Eval("Appointment_ID") %>' CssClass="link" Visible='<%# !IsBooked(Eval("Status")) %>' OnClientClick="return confirm('Set this appointment back to booked?');">Re-open</asp:LinkButton>
                    <a class="link" href="<%# ResolveUrl("~/Portal/Invoices.aspx?appt=" + Eval("Appointment_ID")) %>" style='<%# Convert.ToBoolean(Eval("Is_Paid")) || !CanPay(Eval("Status")) ? "display:none" : "" %>'>Pay</a>
                    <a class="link" target="_blank" href="<%# ResolveUrl("~/Print/Appointment.aspx?id=" + Eval("Appointment_ID")) %>">Print</a>
                    <asp:LinkButton ID="lbDel" runat="server" CommandName="Del" CommandArgument='<%# Eval("Appointment_ID") %>' CssClass="link danger" OnClientClick="return confirm('Permanently delete this appointment? Only allowed if it has no payments or clinical records.');">Delete</asp:LinkButton>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
    </asp:GridView>
    </div>
</asp:Content>
