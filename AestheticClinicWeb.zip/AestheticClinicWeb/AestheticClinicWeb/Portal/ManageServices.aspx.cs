using System;
using System.Data;
using System.Web.UI.WebControls;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;

namespace AestheticClinicWeb.Portal
{
    public partial class ManageServices : StaffPage
    {
        protected override bool AdminOnly { get { return true; } }

        protected void Page_Load(object sender, EventArgs e) { if (!IsPostBack) Bind(); }

        void Bind()
        {
            Safe(lblMsg, () =>
            {
                gv.DataSource = ServiceRepository.All("", txtSearch.Text); gv.DataBind();
                var sb = new System.Text.StringBuilder();
                foreach (DataRow r in ServiceRepository.Categories().Rows) sb.Append("<option value=\"").Append(Server.HtmlEncode(r[0].ToString())).Append("\">");
                litCats.Text = sb.ToString();
            });
        }

        protected void btnSearch_Click(object sender, EventArgs e) { Bind(); }
        protected void btnCancel_Click(object sender, EventArgs e) { pnlForm.Visible = false; }
        protected void btnNew_Click(object sender, EventArgs e)
        {
            pnlForm.Visible = true; hfId.Value = "0"; litForm.Text = "Add treatment";
            txtName.Text = txtCategory.Text = txtDesc.Text = txtPrice.Text = ""; txtDuration.Text = "30";
        }

        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int id = Convert.ToInt32(e.CommandArgument);
            if (e.CommandName == "EditS")
            {
                Safe(lblMsg, () =>
                {
                    var r = ServiceRepository.Get(id);
                    if (r == null) { Fail(lblMsg, "Treatment not found."); return; }
                    pnlForm.Visible = true; hfId.Value = id.ToString(); litForm.Text = "Edit treatment #" + id;
                    txtName.Text = Db.S(r, "Service_Name"); txtCategory.Text = Db.S(r, "Category"); txtDesc.Text = Db.S(r, "Description");
                    txtDuration.Text = Db.I(r, "Duration").ToString(); txtPrice.Text = Db.M(r, "Price").ToString("0.00", Inv);
                });
            }
            else if (e.CommandName == "Del")
            {
                string reason = null; bool ok = false;
                if (Safe(lblMsg, () => ok = ServiceRepository.TryDelete(id, out reason)))
                { if (ok) Ok(lblMsg, "Treatment deleted."); else Fail(lblMsg, reason); }
                Bind();
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            Page.Validate("svc"); if (!Page.IsValid) return;
            int id = int.Parse(hfId.Value), dur;
            decimal? price = ParseDec(txtPrice.Text);
            if (!int.TryParse(txtDuration.Text, out dur) || dur < 5 || dur > 480) { Fail(lblMsg, "Duration must be 5-480 minutes."); return; }
            if (price == null || price < 0 || price > 9999.99m) { Fail(lblMsg, "Price must be between 0 and 9999.99."); return; }
            string name = Check.Trunc(txtName.Text, 50);
            bool dup = false;
            if (!Safe(lblMsg, () => dup = ServiceRepository.NameExists(name, id))) return;
            if (dup) { Fail(lblMsg, "A treatment with this name already exists."); return; }

            if (Safe(lblMsg, () =>
            {
                if (id == 0) id = ServiceRepository.Insert(name, Check.Trunc(txtCategory.Text, 50), Check.Trunc(txtDesc.Text, 225), dur, price.Value);
                else ServiceRepository.Update(id, name, Check.Trunc(txtCategory.Text, 50), Check.Trunc(txtDesc.Text, 225), dur, price.Value);
            }))
            {
                Ok(lblMsg, "\"" + name + "\" saved at " + Ui.Money(price.Value) + ". The website now uses this price.");
                pnlForm.Visible = false; Bind();
            }
        }
    }
}
