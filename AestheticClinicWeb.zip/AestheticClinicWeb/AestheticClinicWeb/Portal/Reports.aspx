<%@ Page Title="BI Reports" Language="C#" MasterPageFile="~/App.Master" AutoEventWireup="true" CodeBehind="Reports.aspx.cs" Inherits="AestheticClinicWeb.Portal.Reports" %>
<asp:Content ID="c1" ContentPlaceHolderID="WorkContent" runat="server">
    <h1>Business Intelligence Reports</h1>
    <div class="crumb no-print">Staff Portal &rsaquo; Finance &rsaquo; Reports</div>
    <asp:Label ID="lblMsg" runat="server" Visible="false" />

    <asp:Panel ID="pnlFilter" runat="server" CssClass="filterbar no-print" DefaultButton="btnRun">
        <div class="field wide"><label for="<%= ddlReport.ClientID %>">Report</label>
            <asp:DropDownList ID="ddlReport" runat="server" AutoPostBack="true" OnSelectedIndexChanged="Run_Click" /></div>
        <div class="field"><label for="<%= txtFrom.ClientID %>">From</label><asp:TextBox ID="txtFrom" runat="server" TextMode="Date" /></div>
        <div class="field"><label for="<%= txtTo.ClientID %>">To</label><asp:TextBox ID="txtTo" runat="server" TextMode="Date" /></div>
        <div class="field"><label for="<%= ddlView.ClientID %>">Show as</label>
            <asp:DropDownList ID="ddlView" runat="server" AutoPostBack="true" OnSelectedIndexChanged="Run_Click">
                <asp:ListItem Value="both">Chart + table</asp:ListItem>
                <asp:ListItem Value="chart">Chart only</asp:ListItem>
                <asp:ListItem Value="table">Table only</asp:ListItem>
            </asp:DropDownList></div>
        <div class="field field-btn">
            <asp:Button ID="btnRun" runat="server" Text="Run report" CssClass="btn-sm" OnClick="Run_Click" />
        </div>
    </asp:Panel>
    <div class="toolbar no-print">
        <span class="hint">Quick ranges:</span>
        <asp:LinkButton ID="lbMonth" runat="server" CssClass="chip" OnClick="Range_Click" CommandArgument="month">This month</asp:LinkButton>
        <asp:LinkButton ID="lb3" runat="server" CssClass="chip" OnClick="Range_Click" CommandArgument="3m">Last 3 months</asp:LinkButton>
        <asp:LinkButton ID="lbYear" runat="server" CssClass="chip" OnClick="Range_Click" CommandArgument="year">This year</asp:LinkButton>
        <asp:LinkButton ID="lbAll" runat="server" CssClass="chip" OnClick="Range_Click" CommandArgument="all">All time</asp:LinkButton>
        <span class="spacer"></span>
        <asp:Button ID="btnCsv" runat="server" Text="&#11015; Export to Excel (CSV)" CssClass="btn-sm alt" OnClick="btnCsv_Click" />
        <button type="button" class="btn-sm alt" onclick="window.print()">&#128424; Print / Save as PDF</button>
    </div>

    <div class="panel report">
        <div class="report-head">
            <div>
                <div class="eyebrow-sm"><asp:Literal ID="litCat" runat="server" /></div>
                <h2><asp:Literal ID="litTitle" runat="server" /></h2>
                <p class="hint"><strong>Business question:</strong> <asp:Literal ID="litQuestion" runat="server" /></p>
            </div>
            <div class="hint right">Period: <asp:Literal ID="litPeriod" runat="server" /><br />Generated <%= DateTime.Now.ToString("yyyy-MM-dd HH:mm") %></div>
        </div>
        <asp:Literal ID="litKpi" runat="server" />
        <asp:Literal ID="litChart" runat="server" />
        <asp:Literal ID="litTable" runat="server" />
    </div>

    <div class="panel no-print">
        <h3>All reports</h3>
        <div class="grid grid-3">
            <asp:Repeater ID="rptCatalog" runat="server" OnItemCommand="rptCatalog_ItemCommand">
                <ItemTemplate>
                    <div class="card mini">
                        <div class="eyebrow-sm"><%#: Eval("Category") %><%# (bool)Eval("Complex") ? " &middot; analytical" : " &middot; routine" %></div>
                        <h4><%#: Eval("Title") %></h4>
                        <p class="hint"><%#: Eval("BusinessQuestion") %></p>
                        <asp:LinkButton ID="lbOpen" runat="server" CssClass="link" CommandName="Open" CommandArgument='<%# Eval("Key") %>'>Open &rarr;</asp:LinkButton>
                    </div>
                </ItemTemplate>
            </asp:Repeater>
        </div>
    </div>
</asp:Content>
