<%@ Page Title="Clinical Metrics" Language="C#" MasterPageFile="~/App.Master" AutoEventWireup="true" CodeBehind="Metrics.aspx.cs" Inherits="AestheticClinicWeb.Portal.Metrics" %>
<asp:Content ID="c1" ContentPlaceHolderID="WorkContent" runat="server">
    <h1>Clinical Metrics</h1>
    <div class="crumb">Staff Portal &rsaquo; Clinical metrics</div>
    <asp:Label ID="lblMsg" runat="server" Visible="false" />

    <div class="panel">
        <h3>Record measurements</h3>
        <div class="grid grid-2">
            <div class="field"><label for="<%= ddlPatient.ClientID %>">Patient</label>
                <asp:DropDownList ID="ddlPatient" runat="server" AutoPostBack="true" OnSelectedIndexChanged="ddlPatient_Changed" /></div>
            <div class="field"><label for="<%= ddlAppt.ClientID %>">Appointment</label>
                <asp:DropDownList ID="ddlAppt" runat="server" />
                <asp:RequiredFieldValidator ID="rfvAp" runat="server" ControlToValidate="ddlAppt" InitialValue="" Text="Select an appointment" Display="Dynamic" CssClass="val" ValidationGroup="m" /></div>
            <div class="field"><label for="<%= txtWeight.ClientID %>">Weight (kg)</label><asp:TextBox ID="txtWeight" runat="server" inputmode="decimal" MaxLength="6" />
                <asp:RangeValidator ID="rvW" runat="server" ControlToValidate="txtWeight" Type="Double" MinimumValue="20" MaximumValue="400" Text="20 - 400 kg" Display="Dynamic" CssClass="val" ValidationGroup="m" /></div>
            <div class="field"><label for="<%= txtHeight.ClientID %>">Height (cm)</label><asp:TextBox ID="txtHeight" runat="server" inputmode="decimal" MaxLength="6" />
                <asp:RangeValidator ID="rvH" runat="server" ControlToValidate="txtHeight" Type="Double" MinimumValue="80" MaximumValue="250" Text="80 - 250 cm" Display="Dynamic" CssClass="val" ValidationGroup="m" /></div>
            <div class="field"><label for="<%= txtAbd.ClientID %>">Abdominal circumference (cm)</label><asp:TextBox ID="txtAbd" runat="server" inputmode="decimal" MaxLength="6" />
                <asp:RangeValidator ID="rvA" runat="server" ControlToValidate="txtAbd" Type="Double" MinimumValue="30" MaximumValue="250" Text="30 - 250 cm" Display="Dynamic" CssClass="val" ValidationGroup="m" /></div>
            <div class="field"><label for="<%= txtBp.ClientID %>">Blood pressure</label><asp:TextBox ID="txtBp" runat="server" MaxLength="7" placeholder="120/80" />
                <asp:RegularExpressionValidator ID="reBp" runat="server" ControlToValidate="txtBp" ValidationExpression="^\d{2,3}/\d{2,3}$" Text="Format 120/80" Display="Dynamic" CssClass="val" ValidationGroup="m" /></div>
            <div class="field"><label for="<%= txtNotes.ClientID %>">Notes</label><asp:TextBox ID="txtNotes" runat="server" TextMode="MultiLine" Rows="2" MaxLength="500" /></div>
            <div class="field"><label for="<%= fuImage.ClientID %>">Progress photo (optional, max 2 MB)</label><asp:FileUpload ID="fuImage" runat="server" accept="image/*" /></div>
        </div>
        <asp:Button ID="btnSave" runat="server" Text="Save measurements" CssClass="btn-sm" OnClick="btnSave_Click" ValidationGroup="m" />
    </div>

    <div class="panel">
        <h3>History <asp:Literal ID="litFor" runat="server" /></h3>
        <div class="table-wrap">
        <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="data" GridLines="None" OnRowCommand="gv_RowCommand"
                      AllowPaging="true" PageSize="20" OnPageIndexChanging="gv_PageIndexChanging" EmptyDataText="No measurements recorded." PagerStyle-CssClass="pager">
            <Columns>
                <asp:TemplateField HeaderText="Date"><ItemTemplate><%# Ui.Date(Eval("Date_Recorded")) %></ItemTemplate></asp:TemplateField>
                <asp:BoundField DataField="PatientName" HeaderText="Patient" />
                <asp:BoundField DataField="Weight_kg" HeaderText="Weight" />
                <asp:BoundField DataField="Height_cm" HeaderText="Height" />
                <asp:BoundField DataField="BMI" HeaderText="BMI" />
                <asp:BoundField DataField="Abdominal_Circumference_cm" HeaderText="Abdominal" />
                <asp:BoundField DataField="Blood_Pressure" HeaderText="BP" />
                <asp:BoundField DataField="Notes" HeaderText="Notes" />
                <asp:TemplateField HeaderText="">
                    <ItemTemplate>
                        <%# Convert.ToInt32(Eval("HasImage")) == 1 ? "<a class=\"link\" target=\"_blank\" href=\"" + ResolveUrl("~/Handlers/Image.ashx?type=metric&id=" + Eval("Metric_ID")) + "\">Photo</a>" : "" %>
                        <asp:LinkButton ID="lbDel" runat="server" CommandName="Del" CommandArgument='<%# Eval("Metric_ID") %>' CssClass="link danger" CausesValidation="false" OnClientClick="return confirm('Delete this measurement?');">Delete</asp:LinkButton>
                    </ItemTemplate>
                </asp:TemplateField>
            </Columns>
        </asp:GridView>
        </div>
    </div>
</asp:Content>
