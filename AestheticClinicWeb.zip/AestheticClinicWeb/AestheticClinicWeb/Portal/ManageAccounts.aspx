<%@ Page Title="Manage Accounts" Language="C#" MasterPageFile="~/App.Master" AutoEventWireup="true" CodeBehind="ManageAccounts.aspx.cs" Inherits="AestheticClinicWeb.Portal.ManageAccounts" %>
<asp:Content ID="c1" ContentPlaceHolderID="WorkContent" runat="server">
    <h1>Manage Accounts <span class="mock-badge">Manager</span></h1>
    <div class="crumb">Staff Portal &rsaquo; Admin &rsaquo; Accounts</div>
    <asp:Label ID="lblMsg" runat="server" Visible="false" />

    <div class="panel">
        <h3>Patient online accounts</h3>
        <p class="hint">Patients log in with the email and password stored on their Patient record. New patients receive a temporary
            password by email and must create their own password at first login. Deactivating an account blocks website login only &mdash;
            the patient record, history and front-end system are not affected.</p>
        <asp:Panel ID="pnlAccSearch" runat="server" CssClass="toolbar" DefaultButton="btnAccSearch">
            <asp:DropDownList ID="ddlAccStatus" runat="server" AutoPostBack="true" OnSelectedIndexChanged="ddlAccStatus_Changed" CssClass="inline-select" aria-label="Filter by account status">
                <asp:ListItem Value="">All patients</asp:ListItem>
                <asp:ListItem Value="Active">Active</asp:ListItem>
                <asp:ListItem Value="Awaiting first login">Awaiting first login</asp:ListItem>
                <asp:ListItem Value="Deactivated">Deactivated / awaiting activation</asp:ListItem>
                <asp:ListItem Value="No online account">No online account</asp:ListItem>
            </asp:DropDownList>
            <asp:TextBox ID="txtAccSearch" runat="server" placeholder="Search name, email or patient #" CssClass="search" MaxLength="50" aria-label="Search patients" />
            <asp:Button ID="btnAccSearch" runat="server" Text="Search" CssClass="btn-sm" OnClick="ddlAccStatus_Changed" CausesValidation="false" />
        </asp:Panel>
        <asp:Literal ID="litMail" runat="server" />
        <div class="table-wrap">
        <asp:GridView ID="gvAcc" runat="server" AutoGenerateColumns="false" CssClass="data" GridLines="None" OnRowCommand="gvAcc_RowCommand"
                      AllowPaging="true" PageSize="20" OnPageIndexChanging="gvAcc_PageIndexChanging" PagerStyle-CssClass="pager" EmptyDataText="No patients match.">
            <Columns>
                <asp:BoundField DataField="Patient_ID" HeaderText="#" />
                <asp:TemplateField HeaderText="Name"><ItemTemplate><a class="link" href="<%# ResolveUrl("~/Portal/PatientHistory.aspx?id=" + Eval("Patient_ID")) %>"><%#: Eval("FullName") %></a><%# Convert.ToBoolean(Eval("Is_Active")) ? "" : " <span class=\"pill pill-no\">Archived</span>" %></ItemTemplate></asp:TemplateField>
                <asp:BoundField DataField="Email" HeaderText="Email (login)" />
                <asp:BoundField DataField="Contact_No" HeaderText="Contact" />
                <asp:TemplateField HeaderText="Online account"><ItemTemplate><%# Ui.StatusPill(Eval("AccountState")) %></ItemTemplate></asp:TemplateField>
                <asp:TemplateField><ItemTemplate>
                    <asp:LinkButton ID="lbOn" runat="server" CommandName="Activate" CommandArgument='<%# Eval("Patient_ID") %>' CssClass="link" CausesValidation="false"
                        Visible='<%# Convert.ToString(Eval("AccountState")) == "Deactivated" %>'>Activate</asp:LinkButton>
                    <asp:LinkButton ID="lbOff" runat="server" CommandName="Deactivate" CommandArgument='<%# Eval("Patient_ID") %>' CssClass="link danger" CausesValidation="false"
                        Visible='<%# Convert.ToString(Eval("AccountState")) == "Active" || Convert.ToString(Eval("AccountState")) == "Awaiting first login" %>'
                        OnClientClick="return confirm('Deactivate this patient\'s online account? They will not be able to log in to the website.');">Deactivate</asp:LinkButton>
                    <asp:LinkButton ID="lbTemp" runat="server" CommandName="Temp" CommandArgument='<%# Eval("Patient_ID") %>' CssClass="link" CausesValidation="false"
                        Visible='<%# Convert.ToBoolean(Eval("Is_Active")) %>'
                        OnClientClick="return confirm('Generate a temporary password? The patient must create a new password at next login.');"><%# Convert.ToString(Eval("AccountState")) == "No online account" ? "Create login" : "Reset password" %></asp:LinkButton>
                </ItemTemplate></asp:TemplateField>
            </Columns>
        </asp:GridView>
        </div>
    </div>
    <div class="panel">
        <h3>Staff accounts (shared with the front-end system)</h3>
        <asp:Panel ID="pnlStaffSearch" runat="server" CssClass="toolbar" DefaultButton="btnStaffSearch">
            <asp:TextBox ID="txtStaffSearch" runat="server" placeholder="Search staff" CssClass="search" MaxLength="50" aria-label="Search staff" />
            <asp:Button ID="btnStaffSearch" runat="server" Text="Search" CssClass="btn-sm" OnClick="btnStaffSearch_Click" CausesValidation="false" />
            <asp:Button ID="btnNewStaff" runat="server" Text="+ Add staff member" CssClass="btn-sm alt" OnClick="btnNewStaff_Click" CausesValidation="false" />
        </asp:Panel>
        <div class="table-wrap">
        <asp:GridView ID="gvStaff" runat="server" AutoGenerateColumns="false" CssClass="data" GridLines="None" OnRowCommand="gvStaff_RowCommand" EmptyDataText="No staff found.">
            <Columns>
                <asp:BoundField DataField="Staff_ID" HeaderText="#" />
                <asp:TemplateField HeaderText="Name"><ItemTemplate><%#: Eval("First_Name") + " " + Eval("Last_Name") %></ItemTemplate></asp:TemplateField>
                <asp:BoundField DataField="Email" HeaderText="Email (login)" />
                <asp:BoundField DataField="Role" HeaderText="Role" />
                <asp:TemplateField HeaderText="Status"><ItemTemplate><%# Ui.StatusPill(Convert.ToBoolean(Eval("Is_Active")) ? "Active" : "Inactive") %><%# Convert.ToBoolean(Eval("Is_First_Login")) ? " <span class=\"pill pill-wait\">Temp password</span>" : "" %></ItemTemplate></asp:TemplateField>
                <asp:TemplateField><ItemTemplate>
                    <asp:LinkButton ID="lbE" runat="server" CommandName="EditStaff" CommandArgument='<%# Eval("Staff_ID") %>' CssClass="link" CausesValidation="false">Edit</asp:LinkButton>
                    <asp:LinkButton ID="lbR" runat="server" CommandName="Reset" CommandArgument='<%# Eval("Staff_ID") %>' CssClass="link" CausesValidation="false" OnClientClick="return confirm('Generate a new temporary password for this staff member?');">Reset password</asp:LinkButton>
                    <asp:LinkButton ID="lbT" runat="server" CommandName="Toggle" CommandArgument='<%# Eval("Staff_ID") %>' CssClass="link danger" CausesValidation="false" OnClientClick="return confirm('Change this account\'s active status?');"><%# Convert.ToBoolean(Eval("Is_Active")) ? "Deactivate" : "Activate" %></asp:LinkButton>
                </ItemTemplate></asp:TemplateField>
            </Columns>
        </asp:GridView>
        </div>

        <asp:Panel ID="pnlStaff" runat="server" Visible="false" CssClass="subpanel" DefaultButton="btnSaveStaff">
            <h4><asp:Literal ID="litStaffForm" runat="server" /></h4>
            <asp:HiddenField ID="hfStaff" runat="server" Value="0" />
            <asp:ValidationSummary ID="vs" runat="server" CssClass="msg msg-err" ValidationGroup="st" />
            <div class="grid grid-2">
                <div class="field"><label for="<%= txtSF.ClientID %>">First name *</label><asp:TextBox ID="txtSF" runat="server" MaxLength="100" />
                    <asp:RequiredFieldValidator ID="r1" runat="server" ControlToValidate="txtSF" ErrorMessage="First name required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="st" /></div>
                <div class="field"><label for="<%= txtSL.ClientID %>">Last name *</label><asp:TextBox ID="txtSL" runat="server" MaxLength="100" />
                    <asp:RequiredFieldValidator ID="r2" runat="server" ControlToValidate="txtSL" ErrorMessage="Last name required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="st" /></div>
                <div class="field"><label for="<%= txtSE.ClientID %>">Email (login) *</label><asp:TextBox ID="txtSE" runat="server" TextMode="Email" MaxLength="100" />
                    <asp:RequiredFieldValidator ID="r3" runat="server" ControlToValidate="txtSE" ErrorMessage="Email required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="st" />
                    <asp:RegularExpressionValidator ID="re3" runat="server" ControlToValidate="txtSE" ValidationExpression="^[^@\s]+@[^@\s]+\.[^@\s]{2,}$" ErrorMessage="Invalid email." Text="Invalid email" Display="Dynamic" CssClass="val" ValidationGroup="st" /></div>
                <div class="field"><label for="<%= ddlRole.ClientID %>">Role *</label><asp:DropDownList ID="ddlRole" runat="server" /></div>
            </div>
            <p class="hint">New staff receive a temporary password and must change it at first login (website and Is_First_Login flag for the front-end system).</p>
            <div class="toolbar">
                <asp:Button ID="btnSaveStaff" runat="server" Text="Save" CssClass="btn-sm" OnClick="btnSaveStaff_Click" ValidationGroup="st" />
                <asp:Button ID="btnCancelStaff" runat="server" Text="Cancel" CssClass="btn-sm alt" OnClick="btnCancelStaff_Click" CausesValidation="false" />
            </div>
        </asp:Panel>
    </div>
</asp:Content>
