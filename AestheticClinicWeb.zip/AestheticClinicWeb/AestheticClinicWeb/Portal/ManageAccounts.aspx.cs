using System;
using System.Collections.Generic;
using System.Data;
using System.Security.Cryptography;
using System.Web.UI.WebControls;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;
using AestheticClinicWeb.Security;

namespace AestheticClinicWeb.Portal
{
    public partial class ManageAccounts : StaffPage
    {
        protected override bool AdminOnly { get { return true; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            BindAcc(); BindStaff(); FillRoles();
        }

        void FillRoles()
        {
            var roles = new SortedSet<string>(StringComparer.OrdinalIgnoreCase) { "Doctor", "Receptionist" };
            Safe(lblMsg, () => { foreach (DataRow r in Db.Table("SELECT DISTINCT Role FROM UserAccount WHERE AccountType='Staff'").Rows) roles.Add(Convert.ToString(r[0]).Trim()); });
            ddlRole.Items.Clear();
            foreach (var r in roles) if (r.Length > 0) ddlRole.Items.Add(r);
        }

        void BindAcc() { Safe(lblMsg, () => { gvAcc.DataSource = AccountRepository.PatientAccounts(ddlAccStatus.SelectedValue, txtAccSearch.Text); gvAcc.DataBind(); }); }
        void BindStaff() { Safe(lblMsg, () => { gvStaff.DataSource = AccountRepository.Staff(txtStaffSearch.Text); gvStaff.DataBind(); }); }

        protected void ddlAccStatus_Changed(object sender, EventArgs e) { gvAcc.PageIndex = 0; BindAcc(); }
        protected void gvAcc_PageIndexChanging(object sender, GridViewPageEventArgs e) { gvAcc.PageIndex = e.NewPageIndex; BindAcc(); }
        protected void btnStaffSearch_Click(object sender, EventArgs e) { BindStaff(); }
        protected void btnCancelStaff_Click(object sender, EventArgs e) { pnlStaff.Visible = false; }

        protected void gvAcc_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName != "Activate" && e.CommandName != "Deactivate" && e.CommandName != "Temp") return;
            int id = Convert.ToInt32(e.CommandArgument);
            litMail.Text = "";
            if (e.CommandName == "Temp")
            {
                string temp = TempPassword(), email = null;
                if (Safe(lblMsg, () => email = AccountRepository.IssueTempPassword(id, temp)))
                {
                    Ok(lblMsg, "Temporary password for patient #" + id + " (" + email + "): " + temp +
                               "  - the patient must create their own password at first login.");
                    // The website has no mail server, so open the staff member's email program with the message ready.
                    string body = "Hello,\r\n\r\nYour AestheticFlow online account is ready.\r\n\r\nLogin email: " + email +
                                  "\r\nTemporary password: " + temp + "\r\n\r\nLog in at " + Request.Url.GetLeftPart(UriPartial.Authority) + ResolveUrl("~/Account/Login.aspx") +
                                  " - you will be asked to create your own password.\r\n\r\nKind regards,\r\nAestheticFlow";
                    litMail.Text = "<p><a class=\"btn-sm\" href=\"mailto:" + System.Web.HttpUtility.HtmlAttributeEncode(email) + "?subject=" +
                                   Uri.EscapeDataString("Your AestheticFlow online account") + "&amp;body=" + Uri.EscapeDataString(body) +
                                   "\">&#9993; Email the temporary password to the patient</a></p>";
                }
            }
            else
            {
                bool on = e.CommandName == "Activate";
                if (Safe(lblMsg, () => AccountRepository.SetPatientAccountActive(id, on)))
                    Ok(lblMsg, "Online account for patient #" + id + (on ? " activated - the patient can log in to the website." : " deactivated - the patient can no longer log in to the website."));
            }
            BindAcc();
        }

        protected void btnNewStaff_Click(object sender, EventArgs e)
        {
            pnlStaff.Visible = true; hfStaff.Value = "0"; litStaffForm.Text = "Add staff member";
            txtSF.Text = txtSL.Text = txtSE.Text = "";
        }

        protected void gvStaff_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int id = Convert.ToInt32(e.CommandArgument);
            switch (e.CommandName)
            {
                case "EditStaff":
                    Safe(lblMsg, () =>
                    {
                        var s = AccountRepository.GetStaff(id);
                        if (s == null) return;
                        pnlStaff.Visible = true; hfStaff.Value = id.ToString(); litStaffForm.Text = "Edit staff #" + id;
                        txtSF.Text = Db.S(s, "First_Name"); txtSL.Text = Db.S(s, "Last_Name"); txtSE.Text = Db.S(s, "Email").Trim();
                        string role = Db.S(s, "Role").Trim();
                        if (ddlRole.Items.FindByValue(role) == null) ddlRole.Items.Add(role);
                        ddlRole.SelectedValue = role;
                    });
                    break;
                case "Reset":
                    string temp = TempPassword();
                    if (Safe(lblMsg, () => AccountRepository.ResetStaffPassword(id, temp)))
                        Ok(lblMsg, "Temporary password for staff #" + id + ": " + temp + "  (give it to the staff member securely; they must change it at next login).");
                    BindStaff(); break;
                case "Toggle":
                    if (id == Auth.Current.AccountId) { Fail(lblMsg, "You cannot deactivate your own account."); return; }
                    Safe(lblMsg, () =>
                    {
                        var s = AccountRepository.GetStaff(id);
                        bool nowActive = !Db.B(s, "Is_Active");
                        AccountRepository.SetStaffActive(id, nowActive);
                        Ok(lblMsg, Db.S(s, "First_Name") + " " + Db.S(s, "Last_Name") + (nowActive ? " activated." : " deactivated - they can no longer log in to the website or front-end system."));
                    });
                    BindStaff(); break;
            }
        }

        protected void btnSaveStaff_Click(object sender, EventArgs e)
        {
            Page.Validate("st"); if (!Page.IsValid) return;
            int id = int.Parse(hfStaff.Value);
            string email = txtSE.Text.Trim();
            if (!Check.Email(email)) { Fail(lblMsg, "Please enter a valid email."); return; }
            if (id == Auth.Current.AccountId && !Auth.IsAdminRole(ddlRole.SelectedValue)) { Fail(lblMsg, "You cannot remove your own manager role."); return; }
            bool inUse = false;
            if (!Safe(lblMsg, () => inUse = AccountRepository.EmailInUse(email, id == 0 ? (int?)null : id))) return;
            if (inUse) { Fail(lblMsg, "That email is already used by another account."); return; }

            string temp = TempPassword();
            if (Safe(lblMsg, () =>
            {
                if (id == 0) id = AccountRepository.AddStaff(Check.Trunc(txtSF.Text, 100), Check.Trunc(txtSL.Text, 100), email, ddlRole.SelectedValue, temp);
                else { AccountRepository.UpdateStaff(id, Check.Trunc(txtSF.Text, 100), Check.Trunc(txtSL.Text, 100), email, ddlRole.SelectedValue); temp = null; }
            }))
            {
                Ok(lblMsg, temp != null
                    ? "Staff member added (#" + id + "). Temporary password: " + temp + "  - they must change it at first login."
                    : "Staff member #" + id + " updated.");
                pnlStaff.Visible = false; BindStaff();
            }
        }

        /// <summary>Random temporary password that satisfies the password policy.</summary>
        static string TempPassword()
        {
            const string upper = "ABCDEFGHJKLMNPQRSTUVWXYZ", lower = "abcdefghijkmnpqrstuvwxyz", digits = "23456789", special = "!@#$%*";
            var b = new byte[8];
            using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(b);
            return "" + upper[b[0] % upper.Length] + lower[b[1] % lower.Length] + lower[b[2] % lower.Length] + lower[b[3] % lower.Length]
                      + digits[b[4] % digits.Length] + digits[b[5] % digits.Length] + special[b[6] % special.Length] + upper[b[7] % upper.Length];
        }
    }
}
