<%@ Page Title="Treatments & Prices" Language="C#" MasterPageFile="~/App.Master" AutoEventWireup="true" CodeBehind="ManageServices.aspx.cs" Inherits="AestheticClinicWeb.Portal.ManageServices" %>
<asp:Content ID="c1" ContentPlaceHolderID="WorkContent" runat="server">
    <h1>Treatments &amp; Prices <span class="mock-badge">Manager</span></h1>
    <div class="crumb">Staff Portal &rsaquo; Admin &rsaquo; Treatments</div>
    <asp:Label ID="lblMsg" runat="server" Visible="false" />

    <asp:Panel ID="pnlSearch" runat="server" CssClass="toolbar" DefaultButton="btnSearch">
        <asp:TextBox ID="txtSearch" runat="server" placeholder="Search treatments" CssClass="search" MaxLength="50" aria-label="Search treatments" />
        <asp:Button ID="btnSearch" runat="server" Text="Search" CssClass="btn-sm" OnClick="btnSearch_Click" CausesValidation="false" />
        <asp:Button ID="btnNew" runat="server" Text="+ Add treatment" CssClass="btn-sm alt" OnClick="btnNew_Click" CausesValidation="false" />
    </asp:Panel>

    <div class="table-wrap">
    <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="data" GridLines="None" DataKeyNames="Service_ID" OnRowCommand="gv_RowCommand" EmptyDataText="No treatments found.">
        <Columns>
            <asp:BoundField DataField="Service_ID" HeaderText="#" />
            <asp:BoundField DataField="Service_Name" HeaderText="Treatment" />
            <asp:BoundField DataField="Category" HeaderText="Category" />
            <asp:BoundField DataField="Description" HeaderText="Description" />
            <asp:BoundField DataField="Duration" HeaderText="Minutes" />
            <asp:TemplateField HeaderText="Price"><ItemTemplate><%# Ui.Money(Eval("Price")) %></ItemTemplate></asp:TemplateField>
            <asp:TemplateField><ItemTemplate>
                <asp:LinkButton ID="lbEdit" runat="server" CommandName="EditS" CommandArgument='<%# Eval("Service_ID") %>' CssClass="link" CausesValidation="false">Edit</asp:LinkButton>
                <asp:LinkButton ID="lbDel" runat="server" CommandName="Del" CommandArgument='<%# Eval("Service_ID") %>' CssClass="link danger" CausesValidation="false" OnClientClick="return confirm('Delete this treatment?');">Delete</asp:LinkButton>
            </ItemTemplate></asp:TemplateField>
        </Columns>
    </asp:GridView>
    </div>

    <asp:Panel ID="pnlForm" runat="server" CssClass="panel" Visible="false" DefaultButton="btnSave">
        <h3><asp:Literal ID="litForm" runat="server" /></h3>
        <asp:HiddenField ID="hfId" runat="server" Value="0" />
        <asp:ValidationSummary ID="vs" runat="server" CssClass="msg msg-err" ValidationGroup="svc" />
        <div class="grid grid-2">
            <div class="field"><label for="<%= txtName.ClientID %>">Name *</label><asp:TextBox ID="txtName" runat="server" MaxLength="50" />
                <asp:RequiredFieldValidator ID="r1" runat="server" ControlToValidate="txtName" ErrorMessage="Name is required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="svc" /></div>
            <div class="field"><label for="<%= txtCategory.ClientID %>">Category *</label><asp:TextBox ID="txtCategory" runat="server" MaxLength="50" list="cats" />
                <datalist id="cats"><asp:Literal ID="litCats" runat="server" /></datalist>
                <asp:RequiredFieldValidator ID="r2" runat="server" ControlToValidate="txtCategory" ErrorMessage="Category is required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="svc" /></div>
            <div class="field"><label for="<%= txtDuration.ClientID %>">Duration (minutes) *</label><asp:TextBox ID="txtDuration" runat="server" MaxLength="3" inputmode="numeric" />
                <asp:RequiredFieldValidator ID="r3" runat="server" ControlToValidate="txtDuration" ErrorMessage="Duration is required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="svc" />
                <asp:RangeValidator ID="rv3" runat="server" ControlToValidate="txtDuration" Type="Integer" MinimumValue="5" MaximumValue="480" ErrorMessage="Duration must be 5-480 minutes." Text="5 - 480" Display="Dynamic" CssClass="val" ValidationGroup="svc" /></div>
            <div class="field"><label for="<%= txtPrice.ClientID %>">Price (R) *</label><asp:TextBox ID="txtPrice" runat="server" MaxLength="7" inputmode="decimal" />
                <asp:RequiredFieldValidator ID="r4" runat="server" ControlToValidate="txtPrice" ErrorMessage="Price is required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="svc" />
                <asp:RangeValidator ID="rv4" runat="server" ControlToValidate="txtPrice" Type="Double" MinimumValue="0" MaximumValue="9999.99" ErrorMessage="Price must be 0 - 9999.99." Text="0 - 9999.99" Display="Dynamic" CssClass="val" ValidationGroup="svc" /></div>
        </div>
        <div class="field"><label for="<%= txtDesc.ClientID %>">Description *</label><asp:TextBox ID="txtDesc" runat="server" MaxLength="225" TextMode="MultiLine" Rows="2" />
            <asp:RequiredFieldValidator ID="r5" runat="server" ControlToValidate="txtDesc" ErrorMessage="Description is required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="svc" /></div>
        <p class="hint">Price changes apply immediately on the website (public Treatments page, bookings, outstanding balances). Note: the front-end system's Payments screen currently uses fixed prices in code (frmPayments), so it will not pick up a new price until that screen is changed to read Service.Price. Past payments keep the amount actually paid.</p>
        <div class="toolbar">
            <asp:Button ID="btnSave" runat="server" Text="Save treatment" CssClass="btn-sm" OnClick="btnSave_Click" ValidationGroup="svc" />
            <asp:Button ID="btnCancel" runat="server" Text="Cancel" CssClass="btn-sm alt" OnClick="btnCancel_Click" CausesValidation="false" />
        </div>
    </asp:Panel>
</asp:Content>
