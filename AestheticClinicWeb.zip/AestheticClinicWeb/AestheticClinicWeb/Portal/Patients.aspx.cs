using System;
using System.Web.UI.WebControls;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;

namespace AestheticClinicWeb.Portal
{
    public partial class Patients : StaffPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            Bind();
            if (Request.QueryString["new"] == "1") ShowForm(null);
            int edit = QueryInt("edit");
            if (edit > 0) Edit(edit);
        }

        void Bind()
        {
            Safe(lblMsg, () => { gv.DataSource = PatientRepository.Search(txtSearch.Text, chkInactive.Checked); gv.DataBind(); });
        }

        protected void btnSearch_Click(object sender, EventArgs e) { gv.PageIndex = 0; Bind(); }
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e) { gv.PageIndex = e.NewPageIndex; Bind(); }
        protected void btnNew_Click(object sender, EventArgs e) { ShowForm(null); }
        protected void btnCancel_Click(object sender, EventArgs e) { pnlForm.Visible = false; }

        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Page") return;
            int id = Convert.ToInt32(e.CommandArgument);
            switch (e.CommandName)
            {
                case "EditP": Edit(id); break;
                case "Toggle":
                    PatientRecord p = null;
                    if (Safe(lblMsg, () => { p = PatientRepository.Get(id); if (p != null) PatientRepository.SetActive(id, !p.IsActive); }) && p != null)
                        Ok(lblMsg, p.FirstName + " " + p.LastName + (p.IsActive ? " has been deactivated (history kept; cannot be booked)." : " has been reactivated."));
                    Bind(); break;
                case "Del":
                    string reason = null; bool deleted = false;
                    if (Safe(lblMsg, () => deleted = PatientRepository.TryDelete(id, out reason)))
                    { if (deleted) Ok(lblMsg, "Patient #" + id + " deleted."); else Fail(lblMsg, reason); }
                    Bind(); break;
            }
        }

        void Edit(int id)
        {
            PatientRecord p = null;
            if (!Safe(lblMsg, () => p = PatientRepository.Get(id))) return;
            if (p == null) { Fail(lblMsg, "Patient not found."); return; }
            ShowForm(p);
        }

        void ShowForm(PatientRecord p)
        {
            pnlForm.Visible = true;
            hfId.Value = p == null ? "0" : p.PatientId.ToString();
            litFormTitle.Text = p == null ? "Add patient" : "Edit patient #" + p.PatientId;
            txtFirst.Text = p == null ? "" : p.FirstName; txtLast.Text = p == null ? "" : p.LastName;
            txtIdNo.Text = p == null ? "" : p.IdNumber; txtPhone.Text = p == null ? "" : p.Phone;
            txtEmail.Text = p == null ? "" : p.Email; txtAddress.Text = p == null ? "" : p.Address;
            txtAllergies.Text = p == null ? "" : p.Allergies; txtNotes.Text = p == null ? "" : p.ExtraNotes;
            txtFirst.Focus();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            Page.Validate("pat"); if (!Page.IsValid) return;
            int id = int.Parse(hfId.Value);
            PatientRecord existing = null;
            if (id > 0 && !Safe(lblMsg, () => existing = PatientRepository.Get(id))) return;

            // Records captured in the FES often have ID numbers that fail the SA checksum (or whose gender digits
            // disagree with the stored gender). If the ID is UNCHANGED we keep the stored date of birth and gender
            // and skip the check, so staff can still edit the record without corrupting it. New/changed IDs are validated.
            DateTime dob; char gender; string err;
            bool idUnchanged = existing != null && existing.IdNumber == txtIdNo.Text.Trim();
            if (idUnchanged) { dob = existing.Dob; gender = existing.Gender; }
            else if (!Check.SaId(txtIdNo.Text, out dob, out gender, out err)) { Fail(lblMsg, err); return; }

            bool phoneUnchanged = existing != null && existing.Phone == txtPhone.Text.Trim();
            if (!phoneUnchanged && !Check.Phone(txtPhone.Text)) { Fail(lblMsg, "Contact number must be 10 digits starting with 0."); return; }
            if (!Check.Email(txtEmail.Text)) { Fail(lblMsg, "Please enter a valid email address (max 50 characters)."); return; }

            var rec = new PatientRecord
            {
                PatientId = id, FirstName = Check.Trunc(txtFirst.Text, 50), LastName = Check.Trunc(txtLast.Text, 50),
                IdNumber = txtIdNo.Text.Trim(), Gender = gender, Dob = dob, Phone = txtPhone.Text.Trim(), Email = txtEmail.Text.Trim(),
                Address = Check.Trunc(txtAddress.Text, 100), Allergies = txtAllergies.Text, ExtraNotes = txtNotes.Text
            };

            bool dup = false;
            if (!Safe(lblMsg, () => dup = PatientRepository.IdNumberExists(rec.IdNumber, id))) return;
            if (dup) { Fail(lblMsg, "Another patient already has this ID number."); return; }

            int newId = id;
            if (Safe(lblMsg, () => { if (id == 0) newId = PatientRepository.Insert(rec); else PatientRepository.Update(rec); }))
            {
                Ok(lblMsg, id == 0 ? "Patient " + rec.FirstName + " " + rec.LastName + " added (Patient #" + newId + "). They can now be booked in the website and the front-end system."
                                   : "Patient #" + id + " updated. Name changes were applied to all their appointments, payments and results.");
                pnlForm.Visible = false;
                txtSearch.Text = rec.IdNumber; Bind();
            }
        }
    }
}
