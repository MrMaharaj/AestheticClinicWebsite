using System;
using System.Web.UI.WebControls;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;
using AestheticClinicWeb.Security;

namespace AestheticClinicWeb.Portal
{
    public partial class Dashboard : StaffPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            if (Request.QueryString["welcome"] == "1") Ok(lblMsg, "Your new password has been saved.");
            Bind();
        }

        protected bool IsBooked(object s) { return Convert.ToString(s) == ClinicSettings.StatusBooked; }

        void Bind()
        {
            Safe(lblMsg, () =>
            {
                var k = ReportRepository.DashboardKpis();
                litToday.Text = Db.I(k, "TodayAppts").ToString();
                litPatients.Text = Db.I(k, "ActivePatients").ToString();
                litOutstanding.Text = Ui.Money(k["Outstanding"]);
                litRevenue.Text = Ui.Money(k["MonthRevenue"]);
                int pending = Db.I(k, "PendingAccounts");
                phPending.Visible = Auth.IsAdmin && pending > 0;
                litPending.Text = pending.ToString();
                gvToday.DataSource = AppointmentRepository.ForDay(DateTime.Today); gvToday.DataBind();
            });
        }

        protected void gvToday_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int id = Convert.ToInt32(e.CommandArgument);
            string status = e.CommandName == "Done" ? ClinicSettings.StatusCompleted : e.CommandName == "NoShow" ? ClinicSettings.StatusNoShow : null;
            if (status == null) return;
            if (Safe(lblMsg, () => AppointmentRepository.UpdateStatus(id, status)))
                Ok(lblMsg, "Appointment #" + id + " marked as " + status + ".");
            Bind();
        }
    }
}
