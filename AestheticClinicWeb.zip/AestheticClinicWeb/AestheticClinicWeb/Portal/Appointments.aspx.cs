using System;
using System.Data;
using System.Web.UI.WebControls;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;

namespace AestheticClinicWeb.Portal
{
    public partial class Appointments : StaffPage
    {
        protected bool BookOpen { get { return (bool?)ViewState["bookOpen"] ?? false; } set { ViewState["bookOpen"] = value; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            txtDate.Attributes["min"] = DateTime.Today.ToString("yyyy-MM-dd");
            if (IsPostBack) return;

            ddlStatus.Items.Add(new ListItem("All statuses", ""));
            foreach (var s in ClinicSettings.AllStatuses) ddlStatus.Items.Add(s);
            txtFrom.Text = DateTime.Today.ToString("yyyy-MM-dd");
            txtTo.Text = DateTime.Today.AddDays(30).ToString("yyyy-MM-dd");
            txtDate.Text = DateTime.Today.ToString("yyyy-MM-dd");

            Safe(lblMsg, () =>
            {
                ddlService.Items.Add(new ListItem("-- Select treatment --", ""));
                foreach (DataRow r in ServiceRepository.All().Rows)
                    ddlService.Items.Add(new ListItem(r["Service_Name"] + " (" + r["Duration"] + " min, " + Ui.Money(r["Price"]) + ")", r["Service_ID"].ToString()));
            });
            FillPatients("");

            int pre = QueryInt("patient");
            if (pre > 0 && ddlPatient.Items.FindByValue(pre.ToString()) != null) { ddlPatient.SelectedValue = pre.ToString(); BookOpen = true; }
            if (pre > 0) { txtFind.Text = ""; }
            Bind();
        }

        void FillPatients(string term)
        {
            Safe(lblMsg, () =>
            {
                ddlPatient.Items.Clear();
                var dt = PatientRepository.Search(term, false);
                ddlPatient.Items.Add(new ListItem(dt.Rows.Count == 0 ? "-- No matching patients --" : "-- Select patient (" + dt.Rows.Count + ") --", ""));
                foreach (DataRow r in dt.Rows)
                    ddlPatient.Items.Add(new ListItem(r["Last_Name"] + ", " + r["First_Name"] + " (" + Convert.ToString(r["ID_Number"]).Trim() + ")", r["Patient_ID"].ToString()));
                if (dt.Rows.Count == 1) ddlPatient.SelectedIndex = 1;
            });
        }

        protected bool IsBooked(object s) { return Convert.ToString(s) == ClinicSettings.StatusBooked; }
        protected bool CanPay(object s) { return Convert.ToString(s) != ClinicSettings.StatusCancelled; }

        void Bind()
        {
            Safe(lblMsg, () =>
            {
                var dt = AppointmentRepository.Search(ParseDate(txtFrom.Text), ParseDate(txtTo.Text), ddlStatus.SelectedValue, txtFind.Text, QueryInt("patient") > 0 ? (int?)QueryInt("patient") : null);
                gv.DataSource = dt; gv.DataBind();
                litCount.Text = "<p class=\"hint\">" + dt.Rows.Count + " appointment(s) found.</p>";
            });
        }

        protected void btnFilter_Click(object sender, EventArgs e) { gv.PageIndex = 0; Bind(); }
        protected void btnToday_Click(object sender, EventArgs e) { txtFrom.Text = txtTo.Text = DateTime.Today.ToString("yyyy-MM-dd"); gv.PageIndex = 0; Bind(); }
        protected void btnWeek_Click(object sender, EventArgs e) { txtFrom.Text = DateTime.Today.ToString("yyyy-MM-dd"); txtTo.Text = DateTime.Today.AddDays(7).ToString("yyyy-MM-dd"); gv.PageIndex = 0; Bind(); }
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e) { gv.PageIndex = e.NewPageIndex; Bind(); }

        protected void btnFindPatient_Click(object sender, EventArgs e) { BookOpen = true; FillPatients(txtPatientFind.Text); }

        protected void Slots_Changed(object sender, EventArgs e) { BookOpen = true; LoadSlots(); }

        void LoadSlots()
        {
            rblSlots.Items.Clear(); litSlots.Text = "";
            int sid; DateTime? d = ParseDate(txtDate.Text);
            if (!int.TryParse(ddlService.SelectedValue, out sid) || d == null) { litSlots.Text = "<div class=\"hint\">Select a treatment and date.</div>"; return; }
            Safe(lblMsg, () =>
            {
                var s = ServiceRepository.Get(sid);
                foreach (var t in AppointmentRepository.AvailableSlots(d.Value, Db.I(s, "Duration")))
                    rblSlots.Items.Add(new ListItem(t.ToString(@"hh\:mm"), t.ToString(@"hh\:mm")));
                if (rblSlots.Items.Count == 0) litSlots.Text = "<div class=\"empty\">No free times on this date (closed, fully booked or in the past).</div>";
            });
        }

        protected void btnBook_Click(object sender, EventArgs e)
        {
            BookOpen = true;
            int pid, sid; TimeSpan t; DateTime? d = ParseDate(txtDate.Text);
            if (!int.TryParse(ddlPatient.SelectedValue, out pid)) { Fail(lblMsg, "Please select a patient."); return; }
            if (!int.TryParse(ddlService.SelectedValue, out sid)) { Fail(lblMsg, "Please select a treatment."); return; }
            if (d == null) { Fail(lblMsg, "Please choose a date."); return; }
            if (!TimeSpan.TryParse(rblSlots.SelectedValue, out t)) { Fail(lblMsg, "Please choose a free time."); return; }

            int id = 0;
            if (Safe(lblMsg, () => id = AppointmentRepository.Book(pid, sid, d.Value, t)))
            {
                Ok(lblMsg, "Appointment #" + id + " booked for " + ddlPatient.SelectedItem.Text + " on " + d.Value.ToString("yyyy-MM-dd") + " at " + t.ToString(@"hh\:mm") + ". Visible in the front-end system now.");
                BookOpen = false;
                txtFrom.Text = d.Value.ToString("yyyy-MM-dd"); txtTo.Text = d.Value.ToString("yyyy-MM-dd");
                Bind();
            }
            LoadSlots();
        }

        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Page") return;
            int id = Convert.ToInt32(e.CommandArgument);
            string status = null;
            switch (e.CommandName)
            {
                case "Done": status = ClinicSettings.StatusCompleted; break;
                case "NoShow": status = ClinicSettings.StatusNoShow; break;
                case "Cancel": status = ClinicSettings.StatusCancelled; break;
                case "Rebook": status = ClinicSettings.StatusBooked; break;
                case "Del":
                    string reason = null; bool ok = false;
                    if (Safe(lblMsg, () => ok = AppointmentRepository.TryDelete(id, out reason)))
                    { if (ok) Ok(lblMsg, "Appointment #" + id + " deleted."); else Fail(lblMsg, reason); }
                    Bind(); return;
            }
            if (status == null) return;
            if (status == ClinicSettings.StatusBooked)
            {
                // Re-opening must not create a double booking
                int clash = 0;
                if (!Safe(lblMsg, () => clash = Convert.ToInt32(Db.Scalar(@"SELECT COUNT(*) FROM Appointment a JOIN Appointment b ON b.Date=a.Date
                        AND b.Appointment_ID<>a.Appointment_ID AND b.Status<>@c
                        AND DATEADD(SECOND, -DATEPART(SECOND, b.Start_Time), b.Start_Time) < DATEADD(SECOND, -DATEPART(SECOND, a.End_Time), a.End_Time)
                        AND DATEADD(SECOND, -DATEPART(SECOND, b.End_Time), b.End_Time) > DATEADD(SECOND, -DATEPART(SECOND, a.Start_Time), a.Start_Time)
                        WHERE a.Appointment_ID=@i", Db.P("@i", id), Db.P("@c", ClinicSettings.StatusCancelled))))) return;
                if (clash >= ClinicSettings.MaxConcurrent) { Fail(lblMsg, "Cannot re-open: that time slot has been booked by someone else."); return; }
            }
            if (Safe(lblMsg, () => AppointmentRepository.UpdateStatus(id, status)))
                Ok(lblMsg, "Appointment #" + id + " updated to \"" + status + "\".");
            Bind();
        }
    }
}
