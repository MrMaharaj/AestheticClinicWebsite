using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;

namespace AestheticClinicWeb.Portal
{
    /// <summary>
    /// BI reports in four formats: on-screen table, bar chart, Excel (CSV) export and print/PDF.
    /// </summary>
    public partial class Reports : StaffPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            foreach (var r in ReportRepository.All) ddlReport.Items.Add(new ListItem(r.Category + " - " + r.Title, r.Key));
            if (!string.IsNullOrEmpty(Request.QueryString["r"]) && ddlReport.Items.FindByValue(Request.QueryString["r"]) != null)
                ddlReport.SelectedValue = Request.QueryString["r"];
            SetRange("year");
            rptCatalog.DataSource = ReportRepository.All.Select(r => new { r.Key, r.Title, r.Category, r.BusinessQuestion, r.Complex }).ToList();
            rptCatalog.DataBind();
            Run();
        }

        void SetRange(string which)
        {
            var t = DateTime.Today;
            DateTime from = which == "month" ? new DateTime(t.Year, t.Month, 1)
                          : which == "3m" ? new DateTime(t.Year, t.Month, 1).AddMonths(-2)
                          : which == "all" ? new DateTime(2000, 1, 1)
                          : new DateTime(t.Year, 1, 1);
            DateTime to = which == "all" ? t.AddYears(1) : new DateTime(t.Year, 12, 31);
            if (which == "month" || which == "3m") to = new DateTime(t.Year, t.Month, 1).AddMonths(1).AddDays(-1);
            txtFrom.Text = from.ToString("yyyy-MM-dd"); txtTo.Text = to.ToString("yyyy-MM-dd");
        }

        protected void Range_Click(object sender, EventArgs e) { SetRange(((LinkButton)sender).CommandArgument); Run(); }
        protected void Run_Click(object sender, EventArgs e) { Run(); }

        protected void rptCatalog_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            ddlReport.SelectedValue = Convert.ToString(e.CommandArgument); Run();
        }

        bool GetRange(out DateTime f, out DateTime t)
        {
            var a = ParseDate(txtFrom.Text); var b = ParseDate(txtTo.Text);
            f = a ?? DateTime.Today.AddYears(-1); t = b ?? DateTime.Today;
            if (f > t) { Fail(lblMsg, "'From' date must be before 'To' date."); return false; }
            return true;
        }

        void Run()
        {
            var def = ReportRepository.Find(ddlReport.SelectedValue);
            litTitle.Text = Server.HtmlEncode(def.Title);
            litCat.Text = Server.HtmlEncode(def.Category + (def.Complex ? " · analytical report" : " · routine report"));
            litQuestion.Text = Server.HtmlEncode(def.BusinessQuestion);
            litChart.Text = litTable.Text = litKpi.Text = "";
            DateTime f, t;
            if (!GetRange(out f, out t)) return;
            litPeriod.Text = f.ToString("yyyy-MM-dd") + " to " + t.ToString("yyyy-MM-dd");

            Safe(lblMsg, () =>
            {
                DataTable dt = def.Run(f, t);
                litKpi.Text = Kpis(dt, def);
                if (ddlView.SelectedValue != "table") litChart.Text = Ui.BarChart(dt, def.LabelColumn, def.ValueColumn, def.ValueIsMoney);
                if (ddlView.SelectedValue != "chart" || dt.Rows.Count == 0) litTable.Text = Ui.HtmlTable(dt);
            });
        }

        /// <summary>Headline numbers above each report (total, average, top item).</summary>
        static string Kpis(DataTable dt, ReportDefinition def)
        {
            if (dt.Rows.Count == 0 || !dt.Columns.Contains(def.ValueColumn)) return "";
            var vals = dt.AsEnumerable().Where(r => !r.IsNull(def.ValueColumn)).Select(r => new { L = Convert.ToString(r[def.LabelColumn]), V = Convert.ToDecimal(r[def.ValueColumn]) }).ToList();
            if (vals.Count == 0) return "";
            var top = vals.OrderByDescending(v => v.V).First();
            Func<decimal, string> fmt = v => def.ValueIsMoney ? Ui.Money(v) : v.ToString("#,##0.##", Inv);
            bool additive = !def.ValueColumn.Contains("%") && !def.ValueColumn.Contains("Change");
            var sb = new StringBuilder("<div class=\"stat-row three\">");
            sb.Append(Box(additive ? "Total " + def.ValueColumn : "Rows", additive ? fmt(vals.Sum(v => v.V)) : vals.Count.ToString()));
            sb.Append(Box("Average per row", fmt(Math.Round(vals.Average(v => v.V), 2))));
            sb.Append(Box("Highest: " + top.L, fmt(top.V)));
            return sb.Append("</div>").ToString();
        }

        static string Box(string k, string v)
        {
            return "<div class=\"stat-box\"><div class=\"k\">" + System.Web.HttpUtility.HtmlEncode(k) + "</div><div class=\"v sm\">" + System.Web.HttpUtility.HtmlEncode(v) + "</div></div>";
        }

        protected void btnCsv_Click(object sender, EventArgs e)
        {
            var def = ReportRepository.Find(ddlReport.SelectedValue);
            DateTime f, t;
            if (!GetRange(out f, out t)) { Run(); return; }
            DataTable dt = null;
            if (!Safe(lblMsg, () => dt = def.Run(f, t))) { Run(); return; }

            string file = def.Key + "_" + f.ToString("yyyyMMdd") + "-" + t.ToString("yyyyMMdd") + ".csv";
            Response.Clear();
            Response.ContentType = "text/csv";
            Response.ContentEncoding = Encoding.UTF8;
            Response.AddHeader("Content-Disposition", "attachment; filename=\"" + file + "\"");
            Response.BinaryWrite(Encoding.UTF8.GetPreamble());   // BOM so Excel opens UTF-8 correctly
            Response.Write(Ui.Csv(dt));
            Response.Flush();
            Response.SuppressContent = true;
            Context.ApplicationInstance.CompleteRequest();
        }
    }
}
