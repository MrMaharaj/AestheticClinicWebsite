<%@ Page Title="Payments & Invoices" Language="C#" MasterPageFile="~/App.Master" AutoEventWireup="true" CodeBehind="Invoices.aspx.cs" Inherits="AestheticClinicWeb.Portal.Invoices" %>
<asp:Content ID="c1" ContentPlaceHolderID="WorkContent" runat="server">
    <h1>Payments &amp; Invoices</h1>
    <div class="crumb">Staff Portal &rsaquo; Finance &rsaquo; Payments</div>
    <asp:Label ID="lblMsg" runat="server" Visible="false" />

    <div class="panel">
        <h3>Unpaid appointments <asp:Literal ID="litUnpaidTotal" runat="server" /></h3>
        <div class="table-wrap">
        <asp:GridView ID="gvUnpaid" runat="server" AutoGenerateColumns="false" CssClass="data" GridLines="None" DataKeyNames="Appointment_ID"
                      OnRowCommand="gvUnpaid_RowCommand" OnRowDataBound="gvUnpaid_RowDataBound" EmptyDataText="No unpaid appointments.">
            <Columns>
                <asp:BoundField DataField="Appointment_ID" HeaderText="Appt #" />
                <asp:TemplateField HeaderText="Date"><ItemTemplate><%# Ui.Date(Eval("Date")) %> <%# Ui.Time(Eval("Start_Time")) %></ItemTemplate></asp:TemplateField>
                <asp:BoundField DataField="PatientName" HeaderText="Patient" />
                <asp:BoundField DataField="Service_Name" HeaderText="Treatment" />
                <asp:TemplateField HeaderText="Status"><ItemTemplate><%# Ui.StatusPill(Eval("Status")) %></ItemTemplate></asp:TemplateField>
                <asp:TemplateField HeaderText="Amount (R)">
                    <ItemTemplate>
                        <asp:TextBox ID="txtAmount" runat="server" CssClass="amount" MaxLength="7" Text='<%# Convert.ToDecimal(Eval("Price")).ToString("0.00", System.Globalization.CultureInfo.InvariantCulture) %>' aria-label="Amount" />
                    </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField>
                    <ItemTemplate>
                        <asp:LinkButton ID="lbPay" runat="server" CommandName="Pay" CommandArgument='<%# Container.DataItemIndex %>' CssClass="btn-sm" CausesValidation="false"
                            OnClientClick="return confirm('Record this payment?');">Record payment</asp:LinkButton>
                    </ItemTemplate>
                </asp:TemplateField>
            </Columns>
        </asp:GridView>
        </div>
    </div>

    <div class="panel">
        <h3>Payment history</h3>
        <asp:Panel ID="pnlFilter" runat="server" CssClass="filterbar" DefaultButton="btnFilter">
            <div class="field"><label for="<%= txtFrom.ClientID %>">From</label><asp:TextBox ID="txtFrom" runat="server" TextMode="Date" /></div>
            <div class="field"><label for="<%= txtTo.ClientID %>">To</label><asp:TextBox ID="txtTo" runat="server" TextMode="Date" /></div>
            <div class="field"><label for="<%= txtFind.ClientID %>">Patient / treatment / receipt #</label><asp:TextBox ID="txtFind" runat="server" MaxLength="50" /></div>
            <div class="field field-btn"><asp:Button ID="btnFilter" runat="server" Text="Search" CssClass="btn-sm" OnClick="btnFilter_Click" CausesValidation="false" /></div>
        </asp:Panel>
        <asp:Literal ID="litTotal" runat="server" />
        <div class="table-wrap">
        <asp:GridView ID="gvPaid" runat="server" AutoGenerateColumns="false" CssClass="data" GridLines="None" OnRowCommand="gvPaid_RowCommand"
                      AllowPaging="true" PageSize="20" OnPageIndexChanging="gvPaid_PageIndexChanging" EmptyDataText="No payments found." PagerStyle-CssClass="pager">
            <Columns>
                <asp:BoundField DataField="Payment_ID" HeaderText="Receipt #" />
                <asp:TemplateField HeaderText="Date"><ItemTemplate><%# Ui.Date(Eval("Date")) %></ItemTemplate></asp:TemplateField>
                <asp:BoundField DataField="PatientName" HeaderText="Patient" />
                <asp:BoundField DataField="Service_Description" HeaderText="Treatment" />
                <asp:BoundField DataField="Appointment_ID" HeaderText="Appt #" />
                <asp:TemplateField HeaderText="Amount"><ItemTemplate><%# Ui.Money(Eval("Amount")) %></ItemTemplate></asp:TemplateField>
                <asp:TemplateField>
                    <ItemTemplate>
                        <a class="link" target="_blank" href="<%# ResolveUrl("~/Print/Receipt.aspx?id=" + Eval("Payment_ID")) %>">Receipt</a>
                        <asp:LinkButton ID="lbRev" runat="server" CommandName="Reverse" CommandArgument='<%# Eval("Payment_ID") %>' CssClass="link danger" Visible='<%# IsAdmin %>'
                            CausesValidation="false" OnClientClick="return confirm('Reverse (delete) this payment? The appointment will show as unpaid again.');">Reverse</asp:LinkButton>
                    </ItemTemplate>
                </asp:TemplateField>
            </Columns>
        </asp:GridView>
        </div>
    </div>
</asp:Content>
