<%@ Page Title="Staff Dashboard" Language="C#" MasterPageFile="~/App.Master" AutoEventWireup="true" CodeBehind="Dashboard.aspx.cs" Inherits="AestheticClinicWeb.Portal.Dashboard" %>
<asp:Content ID="c1" ContentPlaceHolderID="WorkContent" runat="server">
    <h1>Dashboard</h1>
    <div class="crumb">Staff Portal &rsaquo; Dashboard &middot; <%= DateTime.Today.ToString("dddd, d MMMM yyyy") %></div>
    <asp:Label ID="lblMsg" runat="server" Visible="false" />
    <asp:PlaceHolder ID="phPending" runat="server" Visible="false">
        <div class="msg msg-info"><asp:Literal ID="litPending" runat="server" /> patient web account(s) awaiting approval.
            <a href="<%= ResolveUrl("~/Portal/ManageAccounts.aspx") %>">Review now &rarr;</a></div>
    </asp:PlaceHolder>

    <div class="stat-row">
        <div class="stat-box"><div class="k">Today's appointments</div><div class="v"><asp:Literal ID="litToday" runat="server" Text="-" /></div></div>
        <div class="stat-box"><div class="k">Active patients</div><div class="v"><asp:Literal ID="litPatients" runat="server" Text="-" /></div></div>
        <div class="stat-box"><div class="k">Outstanding (due)</div><div class="v"><asp:Literal ID="litOutstanding" runat="server" Text="-" /></div></div>
        <div class="stat-box"><div class="k">Revenue this month</div><div class="v"><asp:Literal ID="litRevenue" runat="server" Text="-" /></div></div>
    </div>

    <div class="panel">
        <h3>Today's schedule</h3>
        <div class="table-wrap">
        <asp:GridView ID="gvToday" runat="server" AutoGenerateColumns="false" CssClass="data" GridLines="None" DataKeyNames="Appointment_ID"
                      OnRowCommand="gvToday_RowCommand" EmptyDataText="No appointments today.">
            <Columns>
                <asp:TemplateField HeaderText="Time"><ItemTemplate><%# Ui.Time(Eval("Start_Time")) %>&ndash;<%# Ui.Time(Eval("End_Time")) %></ItemTemplate></asp:TemplateField>
                <asp:TemplateField HeaderText="Patient"><ItemTemplate><a class="link" href="<%# ResolveUrl("~/Portal/PatientHistory.aspx?id=" + Eval("Patient_ID")) %>"><%#: Eval("PatientName") %></a></ItemTemplate></asp:TemplateField>
                <asp:BoundField DataField="Service_Name" HeaderText="Treatment" />
                <asp:TemplateField HeaderText="Status"><ItemTemplate><%# Ui.StatusPill(Eval("Status")) %></ItemTemplate></asp:TemplateField>
                <asp:TemplateField HeaderText="Payment"><ItemTemplate><%# Ui.PaidPill(Eval("Is_Paid")) %></ItemTemplate></asp:TemplateField>
                <asp:TemplateField HeaderText="Quick update">
                    <ItemTemplate>
                        <asp:LinkButton ID="lbDone" runat="server" CommandName="Done" CommandArgument='<%# Eval("Appointment_ID") %>' CssClass="link" Visible='<%# IsBooked(Eval("Status")) %>'>Completed</asp:LinkButton>
                        <asp:LinkButton ID="lbNoShow" runat="server" CommandName="NoShow" CommandArgument='<%# Eval("Appointment_ID") %>' CssClass="link danger" Visible='<%# IsBooked(Eval("Status")) %>'
                            OnClientClick="return confirm('Mark as no-show?');">No-show</asp:LinkButton>
                        <a class="link" href="<%# ResolveUrl("~/Portal/Invoices.aspx?appt=" + Eval("Appointment_ID")) %>" style='<%# Convert.ToBoolean(Eval("Is_Paid")) ? "display:none" : "" %>'>Take payment</a>
                    </ItemTemplate>
                </asp:TemplateField>
            </Columns>
        </asp:GridView>
        </div>
    </div>

    <div class="panel">
        <h3>Quick actions</h3>
        <div class="toolbar">
            <a class="btn-sm" href="<%= ResolveUrl("~/Portal/Patients.aspx?new=1") %>">+ Add patient</a>
            <a class="btn-sm" href="<%= ResolveUrl("~/Portal/Appointments.aspx") %>">+ Book appointment</a>
            <a class="btn-sm alt" href="<%= ResolveUrl("~/Portal/Invoices.aspx") %>">Record payment</a>
            <a class="btn-sm alt" href="<%= ResolveUrl("~/Portal/Reports.aspx") %>">BI reports</a>
        </div>
    </div>
</asp:Content>
