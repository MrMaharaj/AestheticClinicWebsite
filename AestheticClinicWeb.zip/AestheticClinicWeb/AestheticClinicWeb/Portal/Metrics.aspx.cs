using System;
using System.Data;
using System.Web.UI.WebControls;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;

namespace AestheticClinicWeb.Portal
{
    public partial class Metrics : StaffPage
    {
        int? SelectedPatient { get { int p; return int.TryParse(ddlPatient.SelectedValue, out p) ? (int?)p : null; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            Page.Form.Enctype = "multipart/form-data";
            if (IsPostBack) return;
            Safe(lblMsg, () =>
            {
                ddlPatient.Items.Add(new ListItem("-- All patients --", ""));
                foreach (DataRow r in PatientRepository.ActiveForDropdown().Rows) ddlPatient.Items.Add(new ListItem(r["Display"].ToString(), r["Patient_ID"].ToString()));
            });
            int pre = QueryInt("patient");
            if (pre > 0 && ddlPatient.Items.FindByValue(pre.ToString()) != null) ddlPatient.SelectedValue = pre.ToString();
            FillAppts(); Bind();
        }

        void FillAppts()
        {
            Safe(lblMsg, () =>
            {
                ddlAppt.Items.Clear();
                ddlAppt.Items.Add(new ListItem(SelectedPatient == null ? "-- Select a patient first --" : "-- Select appointment --", ""));
                if (SelectedPatient == null) return;
                foreach (DataRow r in AppointmentRepository.ForDropdown(SelectedPatient, true).Rows) ddlAppt.Items.Add(new ListItem(r["Display"].ToString(), r["Appointment_ID"].ToString()));
            });
        }

        void Bind()
        {
            litFor.Text = SelectedPatient == null ? "(all patients)" : "for " + Server.HtmlEncode(ddlPatient.SelectedItem.Text);
            Safe(lblMsg, () => { gv.DataSource = ClinicalRepository.Metrics(SelectedPatient); gv.DataBind(); });
        }

        protected void ddlPatient_Changed(object sender, EventArgs e) { gv.PageIndex = 0; FillAppts(); Bind(); }
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e) { gv.PageIndex = e.NewPageIndex; Bind(); }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            Page.Validate("m"); if (!Page.IsValid) return;
            int appt;
            if (!int.TryParse(ddlAppt.SelectedValue, out appt)) { Fail(lblMsg, "Please select an appointment."); return; }
            decimal? w = ParseDec(txtWeight.Text), h = ParseDec(txtHeight.Text), a = ParseDec(txtAbd.Text);
            if (w == null && h == null && a == null && txtBp.Text.Trim() == "" && txtNotes.Text.Trim() == "")
            { Fail(lblMsg, "Enter at least one measurement or note."); return; }
            if ((txtWeight.Text.Trim() != "" && w == null) || (txtHeight.Text.Trim() != "" && h == null) || (txtAbd.Text.Trim() != "" && a == null))
            { Fail(lblMsg, "Measurements must be numbers, e.g. 72.5"); return; }
            string imgErr; var img = ReadImage(fuImage, out imgErr);
            if (imgErr != null) { Fail(lblMsg, imgErr); return; }

            if (Safe(lblMsg, () => ClinicalRepository.AddMetric(appt, w, a, h, txtBp.Text, Check.Trunc(txtNotes.Text, 500), img)))
            {
                Ok(lblMsg, "Measurements saved. The patient can see them under My Progress.");
                txtWeight.Text = txtHeight.Text = txtAbd.Text = txtBp.Text = txtNotes.Text = "";
                Bind();
            }
        }

        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName != "Del") return;
            int id = Convert.ToInt32(e.CommandArgument);
            if (Safe(lblMsg, () => ClinicalRepository.DeleteMetric(id))) Ok(lblMsg, "Measurement deleted.");
            Bind();
        }
    }
}
