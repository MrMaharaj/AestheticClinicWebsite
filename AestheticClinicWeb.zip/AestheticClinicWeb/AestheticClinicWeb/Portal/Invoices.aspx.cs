using System;
using System.Data;
using System.Web.UI.WebControls;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;
using AestheticClinicWeb.Security;

namespace AestheticClinicWeb.Portal
{
    public partial class Invoices : StaffPage
    {
        protected bool IsAdmin { get { return Auth.IsAdmin; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            txtFrom.Text = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-2).ToString("yyyy-MM-dd");
            txtTo.Text = DateTime.Today.ToString("yyyy-MM-dd");
            BindUnpaid(); BindPaid();
        }

        void BindUnpaid()
        {
            Safe(lblMsg, () =>
            {
                var dt = PaymentRepository.Unpaid(null);
                int appt = QueryInt("appt");
                if (appt > 0) { dt.DefaultView.RowFilter = "Appointment_ID = " + appt; }   // came from "Pay" link
                gvUnpaid.DataSource = dt.DefaultView; gvUnpaid.DataBind();
                decimal total = 0; foreach (DataRowView r in dt.DefaultView) total += Convert.ToDecimal(r["Price"]);
                litUnpaidTotal.Text = "<span class=\"hint\">(" + dt.DefaultView.Count + " &middot; " + Ui.Money(total) + ")" +
                    (appt > 0 ? " &middot; <a href=\"" + ResolveUrl("~/Portal/Invoices.aspx") + "\">show all</a>" : "") + "</span>";
            });
        }

        void BindPaid()
        {
            Safe(lblMsg, () =>
            {
                var dt = PaymentRepository.Search(ParseDate(txtFrom.Text), ParseDate(txtTo.Text), txtFind.Text, null);
                gvPaid.DataSource = dt; gvPaid.DataBind();
                decimal total = 0; foreach (DataRow r in dt.Rows) total += Convert.ToDecimal(r["Amount"]);
                litTotal.Text = "<p class=\"hint\">" + dt.Rows.Count + " payment(s), total <strong>" + Ui.Money(total) + "</strong></p>";
            });
        }

        protected void gvUnpaid_RowDataBound(object sender, GridViewRowEventArgs e) { }

        protected void gvUnpaid_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName != "Pay") return;
            int index = Convert.ToInt32(e.CommandArgument);
            if (index < 0 || index >= gvUnpaid.Rows.Count) { Fail(lblMsg, "Please refresh and try again."); return; }
            var row = gvUnpaid.Rows[index];
            int apptId = Convert.ToInt32(gvUnpaid.DataKeys[index].Value);
            var txt = (TextBox)row.FindControl("txtAmount");
            decimal? amount = ParseDec(txt.Text);
            if (amount == null || amount <= 0 || amount > 9999.99m) { Fail(lblMsg, "Enter a valid amount between 0.01 and 9999.99."); return; }

            int payId = 0;
            if (Safe(lblMsg, () => payId = PaymentRepository.Record(apptId, amount.Value)))
            {
                lblMsg.CssClass = "msg msg-ok"; lblMsg.Visible = true;
                lblMsg.Text = "&#10004; Payment of " + Ui.Money(amount.Value) + " recorded for appointment #" + apptId + " (receipt #" + payId +
                              "). The appointment is now marked as paid in both systems. <a target=\"_blank\" href=\"" +
                              ResolveUrl("~/Print/Receipt.aspx?id=" + payId) + "\">Print receipt</a>";
            }
            BindUnpaid(); BindPaid();
        }

        protected void gvPaid_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName != "Reverse") return;
            if (!Auth.IsAdmin) { Fail(lblMsg, "Only managers can reverse payments."); return; }
            int id = Convert.ToInt32(e.CommandArgument);
            if (Safe(lblMsg, () => PaymentRepository.Delete(id))) Ok(lblMsg, "Payment #" + id + " reversed. The appointment is unpaid again.");
            BindUnpaid(); BindPaid();
        }

        protected void btnFilter_Click(object sender, EventArgs e) { gvPaid.PageIndex = 0; BindPaid(); }
        protected void gvPaid_PageIndexChanging(object sender, GridViewPageEventArgs e) { gvPaid.PageIndex = e.NewPageIndex; BindPaid(); }
    }
}
