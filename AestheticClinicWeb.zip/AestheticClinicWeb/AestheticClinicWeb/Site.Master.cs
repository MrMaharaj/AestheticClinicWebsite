using System;
using System.Web.UI;
using AestheticClinicWeb.Security;

namespace AestheticClinicWeb
{
    public partial class SiteMaster : MasterPage
    {
        protected bool IsStaffUser { get { return Auth.IsStaff; } }
        protected bool IsPatientUser { get { return Auth.IsPatient; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            // Never cache authenticated pages (prevents "Back" showing data after logout).
            if (Request.IsAuthenticated)
            {
                Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
                Response.Cache.SetNoStore();
            }
        }

        /// <summary>Returns "active" when the current page matches, for menu highlighting.</summary>
        protected string Active(string page)
        {
            string path = (Request.AppRelativeCurrentExecutionFilePath ?? "").ToLowerInvariant();
            switch (page)
            {
                case "Home": return path.EndsWith("/default.aspx") || path == "~/" ? "active" : "";
                case "Services": return path.EndsWith("services.aspx") && !path.Contains("/portal/") ? "active" : "";
                case "About": return path.EndsWith("about.aspx") ? "active" : "";
                case "Contact": return path.EndsWith("contact.aspx") ? "active" : "";
                case "Help": return path.EndsWith("help.aspx") ? "active" : "";
                case "Register": return path.EndsWith("register.aspx") ? "active" : "";
                case "Portal": return path.Contains("/portal/") ? "active" : "";
                case "Patient": return path.Contains("/patient/") ? "active" : "";
                default: return "";
            }
        }

        /// <summary>Friendly first name for the logged-in user.</summary>
        protected string ShortName()
        {
            var id = Auth.Current;
            if (id == null) return Context.User.Identity.Name;
            var name = (id.FullName ?? "").Trim();
            return name.Length == 0 ? id.Email : name.Split(' ')[0];
        }
    }
}
