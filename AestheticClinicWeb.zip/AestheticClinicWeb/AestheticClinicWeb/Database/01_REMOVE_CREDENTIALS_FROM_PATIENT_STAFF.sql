/* =====================================================================
   REMOVE ALL CREDENTIAL COLUMNS FROM Patient AND Staff TABLES

   These columns should ONLY exist in UserAccount table.
   This script safely removes them if they exist.

   Safe to run multiple times.
   ===================================================================== */

USE [GroupWst6];
GO

PRINT '';
PRINT '====================================================================';
PRINT '     REMOVING CREDENTIAL COLUMNS FROM PATIENT AND STAFF TABLES';
PRINT '====================================================================';
PRINT '';

-- =====================================================================
-- Remove default constraints first (they may block column deletion)
-- =====================================================================
PRINT 'STEP 1: Removing default constraints...';
PRINT '??????????????????????????????????????';

-- Remove default constraints from Patient table
DECLARE @constraintName NVARCHAR(128);

-- Drop DF_Patient_Is_First_Login if it exists
SELECT @constraintName = name FROM sys.default_constraints 
WHERE parent_object_id = OBJECT_ID('Patient') AND name = 'DF_Patient_Is_First_Login';
IF @constraintName IS NOT NULL
BEGIN
    EXEC('ALTER TABLE dbo.Patient DROP CONSTRAINT [' + @constraintName + ']');
    PRINT '? Dropped constraint: DF_Patient_Is_First_Login';
END

-- Drop DF_Patient_Is_Account_Active if it exists
SELECT @constraintName = name FROM sys.default_constraints 
WHERE parent_object_id = OBJECT_ID('Patient') AND name = 'DF_Patient_Is_Account_Active';
IF @constraintName IS NOT NULL
BEGIN
    EXEC('ALTER TABLE dbo.Patient DROP CONSTRAINT [' + @constraintName + ']');
    PRINT '? Dropped constraint: DF_Patient_Is_Account_Active';
END

-- Drop DF_Staff_Is_First_Login if it exists
SELECT @constraintName = name FROM sys.default_constraints 
WHERE parent_object_id = OBJECT_ID('Staff') AND name = 'DF_Staff_Is_First_Login';
IF @constraintName IS NOT NULL
BEGIN
    EXEC('ALTER TABLE dbo.Staff DROP CONSTRAINT [' + @constraintName + ']');
    PRINT '? Dropped constraint: DF_Staff_Is_First_Login';
END

-- =====================================================================
-- Remove columns from Patient table (if they exist)
-- =====================================================================
PRINT '';
PRINT 'STEP 2: Removing columns from Patient table...';
PRINT '???????????????????????????????????????????????';

IF COL_LENGTH('dbo.Patient', 'Password') IS NOT NULL
BEGIN
    ALTER TABLE dbo.Patient DROP COLUMN [Password];
    PRINT '? Dropped Patient.Password';
END
ELSE
    PRINT '� Patient.Password does not exist (skipped)';

IF COL_LENGTH('dbo.Patient', 'Is_First_Login') IS NOT NULL
BEGIN
    ALTER TABLE dbo.Patient DROP COLUMN [Is_First_Login];
    PRINT '? Dropped Patient.Is_First_Login';
END
ELSE
    PRINT '� Patient.Is_First_Login does not exist (skipped)';

IF COL_LENGTH('dbo.Patient', 'Is_Account_Active') IS NOT NULL
BEGIN
    ALTER TABLE dbo.Patient DROP COLUMN [Is_Account_Active];
    PRINT '? Dropped Patient.Is_Account_Active';
END
ELSE
    PRINT '� Patient.Is_Account_Active does not exist (skipped)';

IF COL_LENGTH('dbo.Patient', 'Security_Question') IS NOT NULL
BEGIN
    ALTER TABLE dbo.Patient DROP COLUMN [Security_Question];
    PRINT '? Dropped Patient.Security_Question';
END
ELSE
    PRINT '� Patient.Security_Question does not exist (skipped)';

IF COL_LENGTH('dbo.Patient', 'Security_Answer') IS NOT NULL
BEGIN
    ALTER TABLE dbo.Patient DROP COLUMN [Security_Answer];
    PRINT '? Dropped Patient.Security_Answer';
END
ELSE
    PRINT '� Patient.Security_Answer does not exist (skipped)';

-- =====================================================================
-- Remove columns from Staff table (if they exist)
-- =====================================================================
PRINT '';
PRINT 'STEP 3: Removing columns from Staff table...';
PRINT '??????????????????????????????????????????????';

IF COL_LENGTH('dbo.Staff', 'Password') IS NOT NULL
BEGIN
    ALTER TABLE dbo.Staff DROP COLUMN [Password];
    PRINT '? Dropped Staff.Password';
END
ELSE
    PRINT '� Staff.Password does not exist (skipped)';

IF COL_LENGTH('dbo.Staff', 'Is_First_Login') IS NOT NULL
BEGIN
    ALTER TABLE dbo.Staff DROP COLUMN [Is_First_Login];
    PRINT '? Dropped Staff.Is_First_Login';
END
ELSE
    PRINT '� Staff.Is_First_Login does not exist (skipped)';

IF COL_LENGTH('dbo.Staff', 'Security_Question') IS NOT NULL
BEGIN
    ALTER TABLE dbo.Staff DROP COLUMN [Security_Question];
    PRINT '? Dropped Staff.Security_Question';
END
ELSE
    PRINT '� Staff.Security_Question does not exist (skipped)';

IF COL_LENGTH('dbo.Staff', 'Security_Answer') IS NOT NULL
BEGIN
    ALTER TABLE dbo.Staff DROP COLUMN [Security_Answer];
    PRINT '? Dropped Staff.Security_Answer';
END
ELSE
    PRINT '� Staff.Security_Answer does not exist (skipped)';

IF COL_LENGTH('dbo.Staff', 'Role') IS NOT NULL
BEGIN
    ALTER TABLE dbo.Staff DROP COLUMN [Role];
    PRINT '? Dropped Staff.Role';
END
ELSE
    PRINT '� Staff.Role does not exist (skipped)';

-- =====================================================================
-- Verification: Check that UserAccount has all staff credentials
-- =====================================================================
PRINT '';
PRINT 'STEP 4: Verification - Staff with no UserAccount entry...';
PRINT '??????????????????????????????????????????????????????????';

DECLARE @staffNoAccount INT = (
    SELECT COUNT(*) 
    FROM Staff s
    LEFT JOIN UserAccount ua ON s.Staff_ID = ua.Staff_ID AND ua.AccountType = 'Staff'
    WHERE ua.User_ID IS NULL
);

IF @staffNoAccount > 0
BEGIN
    PRINT '? WARNING: ' + CAST(@staffNoAccount AS VARCHAR(10)) + ' staff members have no UserAccount entry!';
    PRINT '  These staff will NOT be able to log in until they have a UserAccount record.';
    PRINT '  Staff IDs without accounts:';
    SELECT '  ? Staff_ID: ' + CAST(s.Staff_ID AS VARCHAR(10)) + ' (' + s.First_Name + ' ' + s.Last_Name + ')'
    FROM Staff s
    LEFT JOIN UserAccount ua ON s.Staff_ID = ua.Staff_ID AND ua.AccountType = 'Staff'
    WHERE ua.User_ID IS NULL;
END
ELSE
BEGIN
    PRINT '? All staff members have UserAccount entries';
END

PRINT '';
PRINT '====================================================================';
PRINT '                    REMOVAL COMPLETE';
PRINT '====================================================================';
PRINT '';
PRINT 'Next step: If you received a warning above, create UserAccount entries';
PRINT '          for those staff members using the Staff management page.';
PRINT '';

