/* =====================================================================
   CLEANUP - Remove deprecated credential columns from Patient table

   This script should be run AFTER:
   1. Database migration script (06_Migrate_To_Unified_UserAccount.sql) completed
   2. Code deployment (AccountRepository_Secure.cs) deployed
   3. Testing confirms login works with unified UserAccount table (1-2 weeks)

   This removes the old credential columns from Patient table since they're now in UserAccount.
   The Patient table becomes a pure data table (no credentials).

   SAFE TO RE-RUN: Script checks if columns exist before dropping.
   DO NOT RUN UNTIL YOU'VE TESTED FOR 1-2 WEEKS
   ===================================================================== */

USE [GroupWst6];
GO

PRINT 'Verifying data migration before cleanup...';
PRINT '';

-- Verification 1: Check if all patient passwords are in UserAccount
SELECT 'VERIFICATION 1: Patient credentials in UserAccount' AS [Check];
SELECT COUNT(*) AS PatientCredentialsInUserAccount 
FROM dbo.UserAccount 
WHERE AccountType = 'Patient';
GO

-- Verification 2: Show what will be deleted from Patient table
SELECT 'VERIFICATION 2: Credentials in Patient table that will be deleted' AS [Check];
SELECT COUNT(*) AS PatientRecordsWithCredentials
FROM dbo.Patient 
WHERE [Password] IS NOT NULL;
GO

-- If the count in Verification 2 is 0, we're safe to proceed
-- If it's > 0, those credentials haven't been migrated yet!

PRINT '';
PRINT '===============================================================';
PRINT 'PROCEEDING WITH CREDENTIAL COLUMN CLEANUP';
PRINT '===============================================================';
PRINT '';

-- Drop old credential columns from Patient table one by one
IF COL_LENGTH('dbo.Patient', 'Password') IS NOT NULL
BEGIN
    ALTER TABLE dbo.Patient DROP COLUMN [Password];
    PRINT '? Dropped Patient.Password column';
END
ELSE
    PRINT '? Patient.Password column already dropped or does not exist';

GO

IF COL_LENGTH('dbo.Patient', 'Is_First_Login') IS NOT NULL
BEGIN
    ALTER TABLE dbo.Patient DROP COLUMN Is_First_Login;
    PRINT '? Dropped Patient.Is_First_Login column';
END
ELSE
    PRINT '? Patient.Is_First_Login column already dropped or does not exist';

GO

IF COL_LENGTH('dbo.Patient', 'Is_Account_Active') IS NOT NULL
BEGIN
    ALTER TABLE dbo.Patient DROP COLUMN Is_Account_Active;
    PRINT '? Dropped Patient.Is_Account_Active column';
END
ELSE
    PRINT '? Patient.Is_Account_Active column already dropped or does not exist';

GO

IF COL_LENGTH('dbo.Patient', 'Security_Question') IS NOT NULL
BEGIN
    ALTER TABLE dbo.Patient DROP COLUMN Security_Question;
    PRINT '? Dropped Patient.Security_Question column';
END
ELSE
    PRINT '? Patient.Security_Question column already dropped or does not exist';

GO

IF COL_LENGTH('dbo.Patient', 'Security_Answer') IS NOT NULL
BEGIN
    ALTER TABLE dbo.Patient DROP COLUMN Security_Answer;
    PRINT '? Dropped Patient.Security_Answer column';
END
ELSE
    PRINT '? Patient.Security_Answer column already dropped or does not exist';

GO

-- Verify final structure
PRINT '';
PRINT '===============================================================';
PRINT 'FINAL PATIENT TABLE STRUCTURE';
PRINT '===============================================================';
PRINT '';

SELECT 'Patient Table Columns (should NOT include Password or Security_*)' AS [Status];
SELECT 
    COLUMN_NAME, 
    DATA_TYPE, 
    IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'Patient'
ORDER BY ORDINAL_POSITION;

GO

PRINT '';
PRINT '===============================================================';
PRINT 'CLEANUP COMPLETE ?';
PRINT '===============================================================';
PRINT '';
PRINT 'Patient table is now a pure data table (no credentials).';
PRINT 'All login credentials are centralized in the UserAccount table.';
PRINT '';
PRINT 'Architecture is now:';
PRINT '  � UserAccount table: ALL credentials (Patient + Staff)';
PRINT '  � Patient table: Pure patient data (no credentials)';
PRINT '  � Staff table: Pure staff data (no credentials)';
PRINT '';
PRINT '===============================================================';
GO
