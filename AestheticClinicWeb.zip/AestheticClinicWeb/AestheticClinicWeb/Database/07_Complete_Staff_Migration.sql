/* =====================================================================
   COMPREHENSIVE MIGRATION - Unified UserAccount Architecture

   This script performs a COMPLETE migration to the unified architecture:
   1. Migrates ALL remaining staff credentials from Staff table to UserAccount
   2. Ensures ALL patient credentials are in UserAccount
   3. Verifies data integrity
   4. Provides detailed reporting

   SAFE TO RE-RUN: Checks before inserting to avoid duplicates
   NO DATA LOSS: Uses transactions with rollback on error
   ===================================================================== */

USE [GroupWst6];
GO

SET NOCOUNT ON;
GO

PRINT '======================================================';
PRINT 'COMPREHENSIVE UNIFIED USERACCOUNT MIGRATION';
PRINT '======================================================';
PRINT '';
PRINT 'Starting migration at: ' + CAST(GETDATE() AS VARCHAR(30));
PRINT '';

-- =====================================================================
-- PHASE 1: MIGRATION STATUS REPORT (BEFORE)
-- =====================================================================

PRINT '======================================================';
PRINT 'PHASE 1: CURRENT STATUS (BEFORE MIGRATION)';
PRINT '======================================================';
PRINT '';

PRINT 'Staff credentials distribution:';
SELECT 
    'In UserAccount' AS Location,
    COUNT(*) AS Count
FROM UserAccount
WHERE AccountType = 'Staff'
UNION ALL
SELECT 
    'In Staff table (not yet migrated)',
    COUNT(*)
FROM Staff s
WHERE NOT EXISTS (SELECT 1 FROM UserAccount ua WHERE ua.Staff_ID = s.Staff_ID);

GO

PRINT '';
PRINT 'Patient credentials distribution:';
SELECT 
    'In UserAccount' AS Location,
    COUNT(*) AS Count
FROM UserAccount
WHERE AccountType = 'Patient'
UNION ALL
SELECT 
    'In Patient table only (backup)',
    COUNT(*)
FROM Patient
WHERE [Password] IS NOT NULL;

GO

-- =====================================================================
-- PHASE 2: MIGRATE STAFF CREDENTIALS
-- =====================================================================

PRINT '';
PRINT '======================================================';
PRINT 'PHASE 2: MIGRATING STAFF CREDENTIALS TO USERACCOUNT';
PRINT '======================================================';
PRINT '';

BEGIN TRAN MigrateStaff
BEGIN TRY
    DECLARE @StaffMigratedCount INT = 0;

    -- Migrate staff members who don't have UserAccount entries yet
    INSERT INTO UserAccount (
        Email, [Password], [Role], AccountType, Staff_ID, 
        Account_Status, Security_Question, Security_Answer,
        Is_First_Login, Is_Active, Is_Account_Active, Created_Date, Modified_Date
    )
    SELECT 
        LTRIM(RTRIM(s.Email)) AS Email,
        s.[Password],
        s.[Role],
        'Staff' AS AccountType,
        s.Staff_ID,
        'Confirmed' AS Account_Status,
        ISNULL(s.Security_Question, 'Not Set') AS Security_Question,
        ISNULL(s.Security_Answer, 'Not Set') AS Security_Answer,
        ISNULL(s.Is_First_Login, 0) AS Is_First_Login,
        s.Is_Active,
        1 AS Is_Account_Active,
        GETDATE() AS Created_Date,
        GETDATE() AS Modified_Date
    FROM Staff s
    WHERE NOT EXISTS (
        SELECT 1 FROM UserAccount ua 
        WHERE ua.Staff_ID = s.Staff_ID 
        AND ua.AccountType = 'Staff'
    );

    SET @StaffMigratedCount = @@ROWCOUNT;

    IF @StaffMigratedCount > 0
    BEGIN
        PRINT CAST(@StaffMigratedCount AS VARCHAR(10)) + ' staff member(s) migrated to UserAccount.';
    END
    ELSE
    BEGIN
        PRINT 'All staff members already in UserAccount (none to migrate).';
    END

    COMMIT TRAN MigrateStaff;
    PRINT 'Staff migration completed successfully.';
END TRY
BEGIN CATCH
    ROLLBACK TRAN MigrateStaff;
    PRINT 'ERROR during staff migration: ' + ERROR_MESSAGE();
    RAISERROR('Staff migration failed', 16, 1);
END CATCH

GO

-- =====================================================================
-- PHASE 3: ENSURE ALL PATIENT CREDENTIALS ARE MIGRATED
-- =====================================================================

PRINT '';
PRINT '======================================================';
PRINT 'PHASE 3: ENSURING ALL PATIENT CREDENTIALS IN USERACCOUNT';
PRINT '======================================================';
PRINT '';

BEGIN TRAN MigratePatients
BEGIN TRY
    DECLARE @PatientMigratedCount INT = 0;

    -- Migrate patients who have passwords but no UserAccount entry yet
    INSERT INTO UserAccount (
        Email, [Password], [Role], AccountType, Patient_ID,
        Account_Status, Security_Question, Security_Answer,
        Is_First_Login, Is_Active, Is_Account_Active, Created_Date, Modified_Date
    )
    SELECT 
        LTRIM(RTRIM(p.Email)) AS Email,
        p.[Password],
        'Patient' AS [Role],
        'Patient' AS AccountType,
        p.Patient_ID,
        'Confirmed' AS Account_Status,
        ISNULL(p.Security_Question, 'Not Set') AS Security_Question,
        ISNULL(p.Security_Answer, 'Not Set') AS Security_Answer,
        ISNULL(p.Is_First_Login, 0) AS Is_First_Login,
        p.Is_Active,
        ISNULL(p.Is_Account_Active, 1) AS Is_Account_Active,
        GETDATE() AS Created_Date,
        GETDATE() AS Modified_Date
    FROM Patient p
    WHERE p.[Password] IS NOT NULL
    AND NOT EXISTS (
        SELECT 1 FROM UserAccount ua 
        WHERE ua.Patient_ID = p.Patient_ID
        AND ua.AccountType = 'Patient'
    );

    SET @PatientMigratedCount = @@ROWCOUNT;

    IF @PatientMigratedCount > 0
    BEGIN
        PRINT CAST(@PatientMigratedCount AS VARCHAR(10)) + ' patient credential(s) migrated to UserAccount.';
    END
    ELSE
    BEGIN
        PRINT 'All patient credentials already in UserAccount (none to migrate).';
    END

    COMMIT TRAN MigratePatients;
    PRINT 'Patient migration completed successfully.';
END TRY
BEGIN CATCH
    ROLLBACK TRAN MigratePatients;
    PRINT 'ERROR during patient migration: ' + ERROR_MESSAGE();
    RAISERROR('Patient migration failed', 16, 1);
END CATCH

GO

-- =====================================================================
-- PHASE 4: DATA VERIFICATION
-- =====================================================================

PRINT '';
PRINT '======================================================';
PRINT 'PHASE 4: DATA VERIFICATION & INTEGRITY CHECKS';
PRINT '======================================================';
PRINT '';

-- Check 1: All staff in UserAccount
PRINT 'CHECK 1: Staff account coverage';
SELECT 
    'Staff_ID' AS [Field],
    'Count' AS [Value]
WHERE 1=0
UNION ALL
SELECT 
    CAST(Staff_ID AS VARCHAR(MAX)),
    'Staff with UserAccount'
FROM (
    SELECT s.Staff_ID
    FROM Staff s
    JOIN UserAccount ua ON ua.Staff_ID = s.Staff_ID AND ua.AccountType = 'Staff'
)
GROUP BY Staff_ID
ORDER BY Staff_ID;

DECLARE @StaffTotal INT = (SELECT COUNT(*) FROM Staff);
DECLARE @StaffInUA INT = (SELECT COUNT(*) FROM UserAccount WHERE AccountType = 'Staff' AND Staff_ID IS NOT NULL);

PRINT 'Total Staff records: ' + CAST(@StaffTotal AS VARCHAR(10));
PRINT 'Staff with UserAccount: ' + CAST(@StaffInUA AS VARCHAR(10));

IF @StaffTotal = @StaffInUA
    PRINT '? All staff members have UserAccount entries';
ELSE
    PRINT '? WARNING: ' + CAST(@StaffTotal - @StaffInUA AS VARCHAR(10)) + ' staff without UserAccount!';

GO

PRINT '';

-- Check 2: All patients with credentials in UserAccount
PRINT 'CHECK 2: Patient account coverage';
DECLARE @PatientCreds INT = (SELECT COUNT(*) FROM Patient WHERE [Password] IS NOT NULL);
DECLARE @PatientInUA INT = (SELECT COUNT(*) FROM UserAccount WHERE AccountType = 'Patient' AND Patient_ID IS NOT NULL);

PRINT 'Patient records with credentials: ' + CAST(@PatientCreds AS VARCHAR(10));
PRINT 'Patients with UserAccount entries: ' + CAST(@PatientInUA AS VARCHAR(10));

IF @PatientCreds = @PatientInUA
    PRINT '? All patients with credentials have UserAccount entries';
ELSE
    PRINT '? WARNING: ' + CAST(@PatientCreds - @PatientInUA AS VARCHAR(10)) + ' patients not in UserAccount!';

GO

PRINT '';

-- Check 3: No duplicate emails in UserAccount
PRINT 'CHECK 3: Email uniqueness in UserAccount';
SELECT 
    Email,
    COUNT(*) AS DuplicateCount
FROM UserAccount
GROUP BY Email
HAVING COUNT(*) > 1;

IF @@ROWCOUNT = 0
    PRINT '? No duplicate emails found in UserAccount';
ELSE
    PRINT '? WARNING: Duplicate emails found in UserAccount (see above)';

GO

PRINT '';

-- Check 4: Referential integrity
PRINT 'CHECK 4: Referential integrity';

-- Staff_ID references
SELECT 
    COUNT(*) AS OrphanStaffReferences
FROM UserAccount
WHERE Staff_ID IS NOT NULL
AND NOT EXISTS (SELECT 1 FROM Staff WHERE Staff_ID = UserAccount.Staff_ID);

IF @@ROWCOUNT = 0 OR (SELECT COUNT(*) FROM UserAccount WHERE Staff_ID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM Staff WHERE Staff_ID = UserAccount.Staff_ID)) = 0
    PRINT '? All Staff_ID references are valid';
ELSE
    PRINT '? WARNING: Orphan Staff_ID references found';

GO

-- Patient_ID references
SELECT 
    COUNT(*) AS OrphanPatientReferences
FROM UserAccount
WHERE Patient_ID IS NOT NULL
AND NOT EXISTS (SELECT 1 FROM Patient WHERE Patient_ID = UserAccount.Patient_ID);

IF @@ROWCOUNT = 0 OR (SELECT COUNT(*) FROM UserAccount WHERE Patient_ID IS NOT NULL AND NOT EXISTS (SELECT 1 FROM Patient WHERE Patient_ID = UserAccount.Patient_ID)) = 0
    PRINT '? All Patient_ID references are valid';
ELSE
    PRINT '? WARNING: Orphan Patient_ID references found';

GO

-- =====================================================================
-- PHASE 5: FINAL STATUS REPORT
-- =====================================================================

PRINT '';
PRINT '======================================================';
PRINT 'PHASE 5: FINAL STATUS (AFTER MIGRATION)';
PRINT '======================================================';
PRINT '';

PRINT 'UserAccount table contents:';
SELECT 
    'AccountType' AS [Attribute],
    COUNT(*) AS [Count]
FROM UserAccount
GROUP BY AccountType
ORDER BY AccountType;

GO

PRINT '';
PRINT 'Summary:';

SELECT 
    'Staff members with web credentials' AS [Description],
    COUNT(*) AS [Count]
FROM UserAccount
WHERE AccountType = 'Staff';

SELECT 
    'Patients with web credentials',
    COUNT(*)
FROM UserAccount
WHERE AccountType = 'Patient';

SELECT 
    'Patients with backup credentials still in Patient table',
    COUNT(*)
FROM Patient
WHERE [Password] IS NOT NULL;

GO

PRINT '';
PRINT '======================================================';
PRINT 'MIGRATION COMPLETE';
PRINT '======================================================';
PRINT 'Completed at: ' + CAST(GETDATE() AS VARCHAR(30));
PRINT '';
PRINT 'Next steps:';
PRINT '1. Run comprehensive tests (see TESTING_CHECKLIST.md)';
PRINT '2. Verify patient login works';
PRINT '3. Verify staff login works';
PRINT '4. Verify admin account management works';
PRINT '5. Monitor for 1-2 weeks for stability';
PRINT '6. Then run 08_Cleanup_Old_Credentials.sql to remove backup columns';
PRINT '======================================================';
GO

SET NOCOUNT OFF;
GO
