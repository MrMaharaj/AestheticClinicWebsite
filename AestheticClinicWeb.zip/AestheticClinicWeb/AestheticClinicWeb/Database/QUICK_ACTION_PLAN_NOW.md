# QUICK ACTION PLAN - GET CREDENTIALS REMOVED NOW

## What You Need to Do (Right Now)

You have credential columns still in Patient and Staff tables. Here's exactly what to do:

---

## Option A: If You Don't Know Why They're Still There

### Step 1: Diagnose
1. Open SQL Server Management Studio
2. Connect to your database: `GroupWst6`
3. **Open file:** `Database/11_DIAGNOSTIC_Why_Cleanup_Failed.sql`
4. **Click:** Execute (F5)
5. **Read the output** to see:
   - Are the columns still there? (should show 1 or 0)
   - What constraints might be blocking removal?
   - How much data in UserAccount? (did migration work?)

### Step 2: Force Remove
1. **Open file:** `Database/12_FORCE_Remove_Credentials.sql`
2. **Click:** Execute (F5)
3. **Watch the output** for messages like:
   - "? Dropped Patient.[Password]"
   - "? Dropped Staff.[Password]"
   - etc.

### Step 3: Verify
At the end of the output, you should see:
```
Patient Table:
Password:                Removed ?
Is_First_Login:          Removed ?
Is_Account_Active:       Removed ?
Security_Question:       Removed ?
Security_Answer:         Removed ?

Staff Table:
Password:                Removed ?
Is_First_Login:          Removed ?
Is_Account_Active:       Removed ?
Security_Question:       Removed ?
Security_Answer:         Removed ?
```

**If all say "Removed ?"** ? You're done! ?

**If any say "STILL EXISTS ??"** ? See troubleshooting below

---

## Option B: If You Want to Just Remove Them (Skip Diagnosis)

### Do This:
1. **Back up database first:**
   - In SQL Management Studio
   - Right-click database ? Tasks ? Back Up
   - Save to a safe location (like `C:\Backup\`)

2. **Open file:** `Database/12_FORCE_Remove_Credentials.sql`

3. **Execute** (F5)

4. **Read the output** and verify all columns removed

5. **Done!**

---

## Option C: Run Just One Piece

**If you only want to test Patient table first:**

Replace the entire script with just this:

```sql
USE [GroupWst6];
GO

-- Test dropping ONE column
BEGIN TRAN
BEGIN TRY
    IF COL_LENGTH('dbo.Patient', 'Password') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN [Password]
        PRINT '? SUCCESS: Dropped Patient.Password'
    END
    ELSE
        PRINT '? Patient.Password already removed'
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    PRINT '? ERROR: ' + ERROR_MESSAGE()
END CATCH
```

This will show you if there's a permission or constraint issue.

---

## Troubleshooting Quick Fixes

### "Access Denied" or "Permission" Error
**Problem:** Your user doesn't have ALTER TABLE permission

**Fix:** 
1. Run SQL as Administrator
   - SQL Server Management Studio ? File ? Options
   - Or run cmd as Administrator, then open SSMS
2. Or ask your database admin to run the scripts

---

### "Column is being referenced by an INDEX" Error
**Problem:** An index on the column is preventing removal

**Fix:**
1. Run `12_FORCE_Remove_Credentials.sql`
   - It automatically drops blocking indexes
2. If it still fails, find the index:
   ```sql
   SELECT i.name
   FROM sys.indexes i
   INNER JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
   WHERE ic.name = 'Password' AND OBJECT_NAME(i.object_id) = 'Patient'
   ```
3. Drop it manually:
   ```sql
   DROP INDEX [IndexName] ON dbo.Patient
   ```

---

### "Column is being referenced by a CONSTRAINT" Error
**Problem:** A foreign key or check constraint references the column

**Fix:**
1. Find the constraint:
   ```sql
   SELECT CONSTRAINT_NAME 
   FROM INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE 
   WHERE TABLE_NAME = 'Patient' AND COLUMN_NAME = 'Password'
   ```
2. Drop it:
   ```sql
   ALTER TABLE dbo.Patient DROP CONSTRAINT [ConstraintName]
   ```
3. Then drop the column:
   ```sql
   ALTER TABLE dbo.Patient DROP COLUMN [Password]
   ```

---

### "Column is in use" or "Cannot find column" Error
**Problem:** Either column is locked by another user, or it's already been deleted

**Fix:**
1. Make sure no one else is using the database
2. Close any other connections to GroupWst6
3. In SQL Server Management Studio, click: Query ? Disconnect
4. Wait 30 seconds
5. Click: Query ? Connect
6. Try again

---

### "Still seeing columns in SSMS after deletion"
**Problem:** SSMS cache issue

**Fix:**
1. Close SQL Server Management Studio completely
2. Re-open it
3. Navigate back to your database
4. Right-click table ? Refresh
5. Should show updated column list

---

## Confirm Credentials Are Gone

After running the cleanup, run this to confirm:

```sql
USE [GroupWst6];
GO

-- Patient table structure
SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'Patient' 
ORDER BY ORDINAL_POSITION
GO

-- Staff table structure  
SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'Staff'
ORDER BY ORDINAL_POSITION
GO
```

**Look for:**
- Patient and Staff columns should NOT include: Password, Is_First_Login, Is_Account_Active, Security_Question, Security_Answer
- They should only have: First_Name, Last_Name, DOB, Address, Phone, Email, Role (Staff only), Is_Active, etc.

---

## Verify Login Still Works

After cleanup, test that login still works:

1. Go to your application
2. Click: Login
3. Enter credentials of a staff member (e.g., doctor)
4. Should login successfully ?

**If login fails:**
- Check application error logs
- Make sure UserAccount table has all credentials (run diagnostic)
- Verify AccountRepository.cs is correct

---

## What Gets Removed

| Table | Columns Removed |
|-------|-----------------|
| **Patient** | Password, Is_First_Login, Is_Account_Active, Security_Question, Security_Answer, Account_Status |
| **Staff** | Password, Is_First_Login, Is_Account_Active, Security_Question, Security_Answer |

**Stays in Patient/Staff:**
- All other data (First_Name, Last_Name, DOB, Address, Phone, Email, Role, Is_Active, etc.)
- Everything is preserved except credentials

**Now only in UserAccount:**
- Email (login username)
- Password (PBKDF2 hash)
- Role
- AccountType (Patient/Staff)
- Is_Active, Is_Account_Active
- Security_Question, Security_Answer
- Created_Date, Modified_Date

---

## Files You Need

```
Database/11_DIAGNOSTIC_Why_Cleanup_Failed.sql  ? Run this FIRST
Database/12_FORCE_Remove_Credentials.sql       ? Run this SECOND
```

Both are in your project, ready to use.

---

## Summary

**If you just want them gone:**
1. Back up database
2. Run: `12_FORCE_Remove_Credentials.sql`
3. Check output for "Removed ?"
4. Done!

**If you want to understand why they're still there:**
1. Run: `11_DIAGNOSTIC_Why_Cleanup_Failed.sql`
2. Read output
3. Run: `12_FORCE_Remove_Credentials.sql`
4. Check output for "Removed ?"
5. Done!

---

**Pick your path above and get started! ??**
