/*
   =====================================================================
   FINAL CLEANUP - Remove all credential/security columns from Patient and Staff

   This script should be run AFTER:
   1. Database migration 06 and 07 completed
   2. Code deployed and tested for 1-2 weeks
   3. You've confirmed logins work with unified UserAccount table

   This removes ALL password and security-related columns from Patient and Staff tables.
   After this, credentials are ONLY in the UserAccount table (single source of truth).

   IMPORTANT CHANGES:
   ?????????????????
   Patient table: Removes
     - Password
     - Is_First_Login
     - Is_Account_Active
     - Security_Question
     - Security_Answer
     - Account_Status (if exists)

   Staff table: Removes
     - Password
     - Is_First_Login
     - Is_Account_Active
     - Security_Question (if exists)
     - Security_Answer (if exists)

   RESULT:
   ???????
   Patient & Staff tables become PURE DATA TABLES
   - No credentials
   - No login information
   - Credentials ONLY in UserAccount table

   Access Control:
   ???????????????
   All role-based access is handled via:
   - UserAccount.Role (Doctor, Receptionist, etc.)
   - UserAccount.AccountType (Patient or Staff)
   - Application code (Auth.cs, StaffPage.cs, PatientPage.cs)

   SAFE TO RE-RUN: Script checks if columns exist before dropping
   ===================================================================== */

USE [GroupWst6];
GO

PRINT '============================================================================';
PRINT 'FINAL CLEANUP: Move all credentials to UserAccount only';
PRINT '============================================================================';
PRINT '';

-- ====================================================================
-- VERIFICATION: Check if cleanup is safe
-- ====================================================================

PRINT 'VERIFICATION 1: Checking if all patient credentials are in UserAccount...';
SELECT 
    'Patient Count' AS [Table],
    COUNT(*) AS [Total Records],
    SUM(CASE WHEN pa.[Password] IS NOT NULL THEN 1 ELSE 0 END) AS [With Password in Patient],
    SUM(CASE WHEN ua.User_ID IS NOT NULL THEN 1 ELSE 0 END) AS [In UserAccount]
FROM dbo.Patient pa
LEFT JOIN dbo.UserAccount ua ON pa.Patient_ID = ua.Patient_ID
GO

PRINT '';
PRINT 'VERIFICATION 2: Checking if all staff credentials are in UserAccount...';
SELECT 
    'Staff Count' AS [Table],
    COUNT(*) AS [Total Records],
    SUM(CASE WHEN s.[Password] IS NOT NULL THEN 1 ELSE 0 END) AS [With Password in Staff],
    SUM(CASE WHEN ua.User_ID IS NOT NULL THEN 1 ELSE 0 END) AS [In UserAccount]
FROM dbo.Staff s
LEFT JOIN dbo.UserAccount ua ON s.Staff_ID = ua.Staff_ID
GO

PRINT '';
PRINT '??  If "With Password in Patient" or "With Password in Staff" > 0, STOP!';
PRINT '    Credentials still exist outside UserAccount. Do NOT run cleanup yet.';
PRINT '';

-- ====================================================================
-- PART 1: Remove credential columns from Patient table
-- ====================================================================

PRINT 'PART 1: Cleaning Patient table...';
PRINT '?????????????????????????????????';

BEGIN TRAN;
BEGIN TRY

    IF COL_LENGTH('dbo.Patient', 'Password') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN [Password];
        PRINT '? Dropped Patient.[Password]';
    END

    IF COL_LENGTH('dbo.Patient', 'Is_First_Login') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN [Is_First_Login];
        PRINT '? Dropped Patient.[Is_First_Login]';
    END

    IF COL_LENGTH('dbo.Patient', 'Is_Account_Active') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN [Is_Account_Active];
        PRINT '? Dropped Patient.[Is_Account_Active]';
    END

    IF COL_LENGTH('dbo.Patient', 'Security_Question') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN [Security_Question];
        PRINT '? Dropped Patient.[Security_Question]';
    END

    IF COL_LENGTH('dbo.Patient', 'Security_Answer') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN [Security_Answer];
        PRINT '? Dropped Patient.[Security_Answer]';
    END

    IF COL_LENGTH('dbo.Patient', 'Account_Status') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN [Account_Status];
        PRINT '? Dropped Patient.[Account_Status]';
    END

    COMMIT;
    PRINT 'Patient table cleanup: ? SUCCESS';

END TRY
BEGIN CATCH
    ROLLBACK;
    DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
    PRINT '? ERROR during Patient cleanup: ' + @ErrorMessage;
    RAISERROR (@ErrorMessage, 16, 1);
END CATCH

GO

-- ====================================================================
-- PART 2: Remove credential columns from Staff table
-- ====================================================================

PRINT '';
PRINT 'PART 2: Cleaning Staff table...';
PRINT '???????????????????????????????';

BEGIN TRAN;
BEGIN TRY

    IF COL_LENGTH('dbo.Staff', 'Password') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN [Password];
        PRINT '? Dropped Staff.[Password]';
    END

    IF COL_LENGTH('dbo.Staff', 'Is_First_Login') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN [Is_First_Login];
        PRINT '? Dropped Staff.[Is_First_Login]';
    END

    IF COL_LENGTH('dbo.Staff', 'Is_Account_Active') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN [Is_Account_Active];
        PRINT '? Dropped Staff.[Is_Account_Active]';
    END

    IF COL_LENGTH('dbo.Staff', 'Security_Question') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN [Security_Question];
        PRINT '? Dropped Staff.[Security_Question]';
    END

    IF COL_LENGTH('dbo.Staff', 'Security_Answer') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN [Security_Answer];
        PRINT '? Dropped Staff.[Security_Answer]';
    END

    COMMIT;
    PRINT 'Staff table cleanup: ? SUCCESS';

END TRY
BEGIN CATCH
    ROLLBACK;
    DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
    PRINT '? ERROR during Staff cleanup: ' + @ErrorMessage;
    RAISERROR (@ErrorMessage, 16, 1);
END CATCH

GO

-- ====================================================================
-- FINAL VERIFICATION
-- ====================================================================

PRINT '';
PRINT 'FINAL VERIFICATION: Confirming cleanup...';
PRINT '?????????????????????????????????????????';

SELECT 'Patient Table Structure' AS [Check];
SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'Patient' 
ORDER BY ORDINAL_POSITION
GO

PRINT '';
SELECT 'Staff Table Structure' AS [Check];
SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'Staff' 
ORDER BY ORDINAL_POSITION
GO

PRINT '';
PRINT '? CLEANUP COMPLETE!';
PRINT '';
PRINT 'SUMMARY:';
PRINT '  ? All credentials removed from Patient table';
PRINT '  ? All credentials removed from Staff table';
PRINT '  ? All credentials now ONLY in UserAccount table';
PRINT '  ? Single source of truth established';
PRINT '  ? Maximum security achieved';
PRINT '';
PRINT 'NEXT STEPS:';
PRINT '  1. Test application thoroughly';
PRINT '  2. Monitor logs for any errors';
PRINT '  3. Backup database after testing';
PRINT '';
PRINT '============================================================================';
