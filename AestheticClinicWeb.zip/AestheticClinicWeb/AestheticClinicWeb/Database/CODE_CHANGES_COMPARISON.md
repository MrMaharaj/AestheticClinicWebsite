# Code Changes Comparison

## Overview of Changes

This document shows the key differences between the old (AccountRepository.cs) and new (AccountRepository_Secure.cs) code.

---

## 1. Login Method

### BEFORE: Separate checks for Staff and Patient

```csharp
public static LoginResult Login(string email, string password)
{
    email = (email ?? "").Trim();

    // 1. Check Staff table
    var s = Row("SELECT TOP 1 * FROM Staff WHERE Email = @e", P("@e", email));
    if (s != null && PasswordHasher.Verify(password, S(s, "Password")))
    {
        if (!B(s, "Is_Active")) 
            return new LoginResult { Error = "Staff account deactivated." };
        string role = S(s, "Role").Trim();
        return new LoginResult
        {
            Identity = new ClinicIdentity
            {
                Kind = AccountKind.Staff, 
                AccountId = I(s, "Staff_ID"), 
                Email = S(s, "Email").Trim(),
                FullName = (S(s, "First_Name") + " " + S(s, "Last_Name")).Trim(), 
                DbRole = role,
                IsAdmin = Auth.IsAdminRole(role), 
                MustChangePassword = B(s, "Is_First_Login")
            }
        };
    }

    // 2. Check Patient table (if Password IS NOT NULL)
    var rows = Table(@"SELECT Patient_ID, First_Name, Last_Name, Email, Password, 
                             Is_First_Login, Is_Active, Is_Account_Active
                       FROM Patient WHERE Email = @e AND Password IS NOT NULL", 
                     P("@e", email));
    if (rows.Rows.Count > 1)
        return new LoginResult { Error = "Multiple patient records use this email." };

    if (rows.Rows.Count == 1)
    {
        var p = rows.Rows[0];
        if (!PasswordHasher.Verify(password, S(p, "Password"))) 
            return new LoginResult { Error = BadLogin };
        if (!B(p, "Is_Active"))
            return new LoginResult { Error = "Patient record is no longer active." };
        if (!B(p, "Is_Account_Active"))
            return new LoginResult { Error = "Online account is not active yet." };

        int pid = I(p, "Patient_ID");
        return new LoginResult
        {
            Identity = new ClinicIdentity
            {
                Kind = AccountKind.Patient, 
                AccountId = pid, 
                PatientId = pid, 
                Email = S(p, "Email").Trim(),
                FullName = (S(p, "First_Name") + " " + S(p, "Last_Name")).Trim(), 
                DbRole = ClinicSettings.PatientRole,
                MustChangePassword = B(p, "Is_First_Login")
            }
        };
    }

    // 3. Not found
    return new LoginResult { Error = BadLogin };
}
```

**Issues:**
- Two separate database queries
- Two different tables to check
- Duplicate logic for password verification, status checks
- Hard to audit (no single place to add logging)
- Credentials tied to Patient table

### AFTER: Unified check using UserAccount table

```csharp
public static LoginResult Login(string email, string password)
{
    email = (email ?? "").Trim();

    // Single unified lookup
    var ua = Row(@"SELECT UserAccount_ID, Email, Password, Role, AccountType, 
                          Patient_ID, Staff_ID, Is_Active, Is_First_Login, Is_Account_Active
                   FROM UserAccount WHERE Email = @e", P("@e", email));

    if (ua == null)
        return new LoginResult { Error = BadLogin };

    // Verify password
    if (!PasswordHasher.Verify(password, S(ua, "Password")))
        return new LoginResult { Error = BadLogin };

    // Check account status
    if (!B(ua, "Is_Active"))
        return new LoginResult { Error = "Account has been deactivated." };

    if (!B(ua, "Is_Account_Active"))
        return new LoginResult { Error = "Account is not active yet." };

    string accountType = S(ua, "AccountType").Trim();
    string role = S(ua, "Role").Trim();

    // Branch based on account type
    if (accountType == "Staff")
    {
        int staffId = I(ua, "Staff_ID");
        var staff = Row("SELECT First_Name, Last_Name FROM Staff WHERE Staff_ID=@id", 
                       P("@id", staffId));
        if (staff == null)
            return new LoginResult { Error = "Staff record not found." };

        return new LoginResult
        {
            Identity = new ClinicIdentity
            {
                Kind = AccountKind.Staff,
                AccountId = staffId,
                Email = S(ua, "Email").Trim(),
                FullName = (S(staff, "First_Name") + " " + S(staff, "Last_Name")).Trim(),
                DbRole = role,
                IsAdmin = Auth.IsAdminRole(role),
                MustChangePassword = B(ua, "Is_First_Login")
            }
        };
    }
    else if (accountType == "Patient")
    {
        int patientId = I(ua, "Patient_ID");
        var patient = Row("SELECT First_Name, Last_Name, Is_Active FROM Patient WHERE Patient_ID=@id", 
                         P("@id", patientId));
        if (patient == null)
            return new LoginResult { Error = "Patient record not found." };

        if (!B(patient, "Is_Active"))
            return new LoginResult { Error = "Patient record is no longer active." };

        return new LoginResult
        {
            Identity = new ClinicIdentity
            {
                Kind = AccountKind.Patient,
                AccountId = patientId,
                PatientId = patientId,
                Email = S(ua, "Email").Trim(),
                FullName = (S(patient, "First_Name") + " " + S(patient, "Last_Name")).Trim(),
                DbRole = ClinicSettings.PatientRole,
                MustChangePassword = B(ua, "Is_First_Login")
            }
        };
    }

    return new LoginResult { Error = BadLogin };
}
```

**Benefits:**
- Single query to UserAccount
- Unified password verification
- Easier to add audit logging
- Clearer code flow
- Credentials centralized
- Can add new account types easily (e.g., Admin, Receptionist)

---

## 2. Patient Registration

### BEFORE: Writes to Patient table

```csharp
public static bool RegisterPatient(Registration r, out bool linkedExisting)
{
    bool linked = false, active = ClinicSettings.AutoApprovePatients;
    InTransaction((con, tx) =>
    {
        var existing = Table(con, tx, 
            "SELECT Patient_ID, Email, Contact_No, Password FROM Patient WHERE ID_Number = @id", 
            P("@id", r.IdNumber));

        string pw = PasswordHasher.Hash(r.Password), 
               ans = PasswordHasher.Hash(NormaliseAnswer(r.Answer));

        if (existing.Rows.Count > 0)
        {
            // Link to existing patient
            var e = existing.Rows[0];
            if (!e.IsNull("Password"))
                throw new InvalidOperationException("You already have an online account.");

            bool emailMatch = string.Equals(S(e, "Email").Trim(), r.Email.Trim(), 
                                          StringComparison.OrdinalIgnoreCase);
            bool phoneMatch = S(e, "Contact_No").Trim() == r.Phone.Trim();
            if (!emailMatch && !phoneMatch)
                throw new InvalidOperationException("Email and cell don't match records.");

            // UPDATE Patient directly
            Execute(con, tx, 
                @"UPDATE Patient SET Email=@e, Password=@pw, Is_First_Login=0, Is_Account_Active=@a,
                  Security_Question=@q, Security_Answer=@ans WHERE Patient_ID=@p",
                P("@e", r.Email), P("@pw", pw), P("@a", active), 
                P("@q", r.Question), P("@ans", ans), P("@p", I(e, "Patient_ID")));
            linked = true;
        }
        else
        {
            // Create new patient
            Execute(con, tx, @"
                INSERT INTO Patient (First_Name, Last_Name, ID_Number, Gender, Date_Of_Birth, 
                                   Address, Contact_No, Email, Allergies, Extra_Notes, Is_Active,
                                   Password, Is_First_Login, Is_Account_Active, Security_Question, Security_Answer)
                VALUES (@f, @l, @id, @g, @dob, @ad, @c, @e, @al, NULL, 1, @pw, 0, @a, @q, @ans)",
                P("@f", r.FirstName), P("@l", r.LastName), P("@id", r.IdNumber), 
                P("@g", r.Gender.ToString()), P("@dob", r.Dob), P("@ad", r.Address), 
                P("@c", r.Phone), P("@e", r.Email),
                new SqlParameter("@al", SqlDbType.Text) { Value = string.IsNullOrWhiteSpace(r.Allergies) ? (object)DBNull.Value : r.Allergies },
                P("@pw", pw), P("@a", active), P("@q", r.Question), P("@ans", ans));
        }
        return 0;
    });
    linkedExisting = linked;
    return active;
}
```

**Issues:**
- Credentials stored directly in Patient table
- Mixed credential and patient data
- Hard to manage credentials separately
- Can't restrict password changes without exposing full record

### AFTER: Creates entries in both Patient and UserAccount tables

```csharp
public static bool RegisterPatient(Registration r, out bool linkedExisting)
{
    bool linked = false, active = ClinicSettings.AutoApprovePatients;
    InTransaction((con, tx) =>
    {
        // Find existing patient by ID number
        var existing = Table(con, tx, 
            "SELECT Patient_ID, Email, Contact_No FROM Patient WHERE ID_Number = @id", 
            P("@id", r.IdNumber));

        string pw = PasswordHasher.Hash(r.Password);
        string ans = PasswordHasher.Hash(NormaliseAnswer(r.Answer));

        if (existing.Rows.Count > 0)
        {
            // Link to existing patient record
            var e = existing.Rows[0];
            int patientId = I(e, "Patient_ID");

            // Check if this patient already has a login
            int existingLogin = Convert.ToInt32(Scalar(con, tx, 
                "SELECT COUNT(*) FROM UserAccount WHERE Patient_ID=@pid", 
                P("@pid", patientId)));
            if (existingLogin > 0)
                throw new InvalidOperationException("You already have an online account.");

            // Verify email or phone matches
            bool emailMatch = string.Equals(S(e, "Email").Trim(), r.Email.Trim(), 
                                           StringComparison.OrdinalIgnoreCase);
            bool phoneMatch = S(e, "Contact_No").Trim() == r.Phone.Trim();
            if (!emailMatch && !phoneMatch)
                throw new InvalidOperationException("Email and cell don't match records.");

            // CREATE UserAccount entry (not modifying Patient table)
            Execute(con, tx, @"
                INSERT INTO UserAccount (Email, Password, Role, AccountType, Patient_ID, 
                                        Is_Active, Is_First_Login, Is_Account_Active, 
                                        Security_Question, Security_Answer)
                VALUES (@e, @pw, 'Patient', 'Patient', @pid, 1, 0, @a, @q, @ans)",
                P("@e", r.Email), P("@pw", pw), P("@pid", patientId), 
                P("@a", active), P("@q", r.Question), P("@ans", ans));

            // Update patient email if different
            if (!emailMatch)
            {
                Execute(con, tx, "UPDATE Patient SET Email=@e WHERE Patient_ID=@pid",
                    P("@e", r.Email), P("@pid", patientId));
            }

            linked = true;
        }
        else
        {
            // Create new patient record
            int newPatientId = Convert.ToInt32(Scalar(con, tx, @"
                INSERT INTO Patient (First_Name, Last_Name, ID_Number, Gender, Date_Of_Birth, 
                                    Address, Contact_No, Email, Allergies, Extra_Notes, Is_Active)
                VALUES (@f, @l, @id, @g, @dob, @ad, @c, @e, @al, NULL, 1);
                SELECT CAST(SCOPE_IDENTITY() AS int);",
                P("@f", r.FirstName), P("@l", r.LastName), P("@id", r.IdNumber), 
                P("@g", r.Gender.ToString()), P("@dob", r.Dob), P("@ad", r.Address), 
                P("@c", r.Phone), P("@e", r.Email),
                new SqlParameter("@al", SqlDbType.Text) { Value = string.IsNullOrWhiteSpace(r.Allergies) ? (object)DBNull.Value : r.Allergies }));

            // CREATE UserAccount entry
            Execute(con, tx, @"
                INSERT INTO UserAccount (Email, Password, Role, AccountType, Patient_ID, 
                                        Is_Active, Is_First_Login, Is_Account_Active, 
                                        Security_Question, Security_Answer)
                VALUES (@e, @pw, 'Patient', 'Patient', @pid, 1, 0, @a, @q, @ans)",
                P("@e", r.Email), P("@pw", pw), P("@pid", newPatientId),
                P("@a", active), P("@q", r.Question), P("@ans", ans));
        }
        return 0;
    });
    linkedExisting = linked;
    return active;
}
```

**Benefits:**
- Patient table remains clean (data only, no credentials)
- Credentials stored separately in UserAccount
- Can manage logins independently from patient records
- Better for compliance/auditing
- Can restrict credential access without affecting patient data

---

## 3. Set Password Method

### BEFORE

```csharp
public static void SetPassword(AccountKind kind, int id, string newPassword)
{
    if (kind == AccountKind.Staff)
        Execute("UPDATE Staff SET Password=@p, Is_First_Login=0 WHERE Staff_ID=@i", 
                P("@p", PasswordHasher.ForStorage(newPassword)), P("@i", id));
    else
        Execute("UPDATE Patient SET Password=@p, Is_First_Login=0 WHERE Patient_ID=@i", 
                P("@p", PasswordHasher.Hash(newPassword)), P("@i", id));
}
```

**Issue:** Updates in two different tables (Staff and Patient)

### AFTER

```csharp
public static void SetPassword(AccountKind kind, int id, string newPassword)
{
    if (kind == AccountKind.Staff)
        Execute("UPDATE UserAccount SET Password=@p, Is_First_Login=0 WHERE Staff_ID=@i", 
                P("@p", PasswordHasher.ForStorage(newPassword)), P("@i", id));
    else
        Execute("UPDATE UserAccount SET Password=@p, Is_First_Login=0 WHERE Patient_ID=@i", 
                P("@p", PasswordHasher.Hash(newPassword)), P("@i", id));
}
```

**Benefit:** Single table, unified password management

---

## 4. Get Security Question Method

### BEFORE

```csharp
public static string GetSecurityQuestion(string email, out AccountKind kind, out int id)
{
    kind = AccountKind.Staff; id = 0;

    // Check Staff table
    var s = Row("SELECT Staff_ID, Security_Question FROM Staff WHERE Email=@e AND Is_Active=1", 
                P("@e", email.Trim()));
    if (s != null) 
    { 
        id = I(s, "Staff_ID"); 
        return Usable(S(s, "Security_Question")); 
    }

    // Check Patient table
    var p = Table("SELECT Patient_ID, Security_Question FROM Patient WHERE Email=@e AND Password IS NOT NULL AND Is_Active=1 AND Is_Account_Active=1", 
                  P("@e", email.Trim()));
    if (p.Rows.Count == 1) 
    { 
        kind = AccountKind.Patient; 
        id = I(p.Rows[0], "Patient_ID"); 
        return Usable(S(p.Rows[0], "Security_Question")); 
    }

    return null;
}
```

**Issues:** Two queries, different logic for staff vs patient

### AFTER

```csharp
public static string GetSecurityQuestion(string email, out AccountKind kind, out int id)
{
    kind = AccountKind.Staff; id = 0;

    // Single unified lookup
    var ua = Row("SELECT UserAccount_ID, AccountType, Staff_ID, Patient_ID, Security_Question FROM UserAccount WHERE Email=@e AND Is_Active=1", 
                 P("@e", email.Trim()));
    if (ua == null) return null;

    string accountType = S(ua, "AccountType").Trim();
    if (accountType == "Staff")
    {
        kind = AccountKind.Staff;
        id = I(ua, "Staff_ID");
    }
    else
    {
        kind = AccountKind.Patient;
        id = I(ua, "Patient_ID");
    }
    return Usable(S(ua, "Security_Question"));
}
```

**Benefit:** Single table lookup, unified logic

---

## Summary of Changes

| Aspect | Before | After |
|--------|--------|-------|
| **Credential Storage** | Staff table + Patient table | UserAccount table only |
| **Login Query** | 2 queries | 1 query |
| **Registration** | Update Patient.Password | Insert into UserAccount |
| **Password Reset** | Update Staff/Patient | Update UserAccount |
| **Security Question** | Check Staff/Patient | Check UserAccount |
| **Code Duplication** | High (staff vs patient logic) | Low (unified logic) |
| **Auditability** | Hard (scattered sources) | Easy (single table) |
| **Compliance** | Difficult | Easy |

---

## Migration Checklist

- [ ] Understand the architectural changes
- [ ] Review SECURITY_MIGRATION_GUIDE.md
- [ ] Backup current database
- [ ] Run 06_Migrate_To_Unified_UserAccount.sql
- [ ] Replace AccountRepository.cs with AccountRepository_Secure.cs
- [ ] Rebuild solution
- [ ] Test login flow
- [ ] Test patient registration
- [ ] Test password reset
- [ ] Test admin account management
- [ ] Monitor logs for errors
- [ ] Run 08_Cleanup_Old_Credentials.sql (after 1-2 weeks)
