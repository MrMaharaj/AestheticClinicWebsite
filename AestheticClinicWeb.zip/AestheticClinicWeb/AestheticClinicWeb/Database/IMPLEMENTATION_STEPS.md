# Implementation Guide: Moving to Unified UserAccount

## Quick Start

### Step 1: Run Database Migration (SAFE - no data loss)

```sql
/* In SQL Server Management Studio */
USE GroupWst6;
GO
-- Run the contents of: 06_Migrate_To_Unified_UserAccount.sql
```

This script:
- Creates the new `UserAccount` table
- Copies existing patient credentials from Patient table to UserAccount
- Verifies the migration
- **Does NOT** delete old Patient.Password column yet

### Step 2: Update Your C# Code

**Option A: Replace the file** (Recommended for production)
```
1. Backup the original file:
   - Copy AestheticClinicWeb\Data\AccountRepository.cs 
   - Save as AccountRepository_BACKUP.cs

2. Replace it:
   - Delete AestheticClinicWeb\Data\AccountRepository.cs
   - Rename AccountRepository_Secure.cs to AccountRepository.cs
   - Delete the backup
```

**Option B: Parallel testing** (For testing first)
```
1. Keep both files temporarily
2. Test the new one on a staging environment
3. Replace when confident
```

### Step 3: Test Everything

Before going live, test these scenarios:

**Patient Registration & Login:**
```
1. Register a new patient
   ? Should create Patient record + UserAccount record
   ? Email should be in UserAccount table

2. Login as the new patient
   ? Should find credentials in UserAccount (not Patient table)
   ? Dashboard should load

3. Change password after first login
   ? Password should be updated in UserAccount (not Patient table)

4. Use Forgot Password
   ? Security question should come from UserAccount
   ? Password reset should update UserAccount
```

**Staff Login:**
```
1. Login as existing staff member
   ? Should still work with Staff table password
   ? OR Staff credentials should also be in UserAccount (if migrated)
```

**Admin Functions:**
```
1. Approve patient registration
   ? Should update UserAccount.Is_Account_Active

2. Deactivate patient account
   ? Should update UserAccount.Is_Account_Active

3. Issue temporary password
   ? Should update/create UserAccount entry
   ? Email should come from Patient table (or UserAccount)
```

### Step 4: Clean Up (ONLY after testing confirms everything works)

```sql
/* In SQL Server Management Studio */
USE GroupWst6;
GO
-- Run the contents of: 08_Cleanup_Old_Credentials.sql

/* This removes:
   - Patient.Password
   - Patient.Is_First_Login
   - Patient.Is_Account_Active
   - Patient.Security_Question
   - Patient.Security_Answer
*/
```

## What Changed in the Code

### Login Process

**BEFORE:**
```
Login(email, password)
  ?? Check Staff table
  ?? Check Patient table (if Password IS NOT NULL)
  ?? Return error if not found
```

**AFTER:**
```
Login(email, password)
  ?? Check UserAccount table (single query)
  ?? If Staff: Look up Staff.First_Name for full name
  ?? If Patient: Look up Patient.First_Name for full name
  ?? Return error if not found
```

### Patient Registration

**BEFORE:**
```
RegisterPatient()
  ?? Find existing Patient by ID
  ?? Update/Insert Patient.Email, Patient.Password, etc.
```

**AFTER:**
```
RegisterPatient()
  ?? Find existing Patient by ID
  ?? Create new Patient if needed
  ?? Create UserAccount entry with Email, Password, etc.
```

### Password Management

**BEFORE:**
```
SetPassword(Patient, newPassword)
  ?? UPDATE Patient SET Password = hash WHERE Patient_ID = ?
```

**AFTER:**
```
SetPassword(Patient, newPassword)
  ?? UPDATE UserAccount SET Password = hash WHERE Patient_ID = ?
```

## Database Queries Reference

### Find all patient logins
```sql
SELECT * FROM UserAccount 
WHERE AccountType = 'Patient';
```

### Find all staff logins
```sql
SELECT * FROM UserAccount 
WHERE AccountType = 'Staff';
```

### Find patient account status
```sql
SELECT p.Patient_ID, p.First_Name, p.Last_Name, ua.Email, 
       CASE WHEN ua.Is_Account_Active = 0 THEN 'Deactivated'
            WHEN ua.Is_First_Login = 1 THEN 'Awaiting First Login'
            ELSE 'Active'
       END AS Status
FROM Patient p
LEFT JOIN UserAccount ua ON ua.Patient_ID = p.Patient_ID
WHERE p.Patient_ID = 123;  -- Replace with patient ID
```

### Reset patient password
```sql
UPDATE UserAccount 
SET Password = 'temporary_password_here', 
    Is_First_Login = 1 
WHERE Patient_ID = 123;  -- Replace with patient ID
```

### Deactivate patient account
```sql
UPDATE UserAccount 
SET Is_Account_Active = 0 
WHERE Patient_ID = 123;  -- Replace with patient ID
```

## Troubleshooting

### Problem: "Email already exists" when registering
**Cause**: Email is in UserAccount.Email  
**Solution**: Either use different email or admin must reset the account

### Problem: Patient can't login after registering
**Cause 1**: UserAccount entry wasn't created  
**Solution**: Check if Patient record exists but UserAccount doesn't

**Cause 2**: Accounts:AutoApprovePatients = false and account not approved  
**Solution**: Approve in admin panel

### Problem: Staff can't login
**Cause**: Staff credentials not migrated to UserAccount  
**Solution**: During transition, staff passwords still work from Staff table. The code checks UserAccount first but can fall back to Staff table if needed.

### Problem: "Patient record not found" error
**Cause**: Patient_ID in UserAccount doesn't have matching Patient record  
**Solution**: Data integrity issue - contact admin

## Rollback (If Needed)

If the new code has issues:

1. **Restore AccountRepository.cs from backup**
   ```
   cp AccountRepository_BACKUP.cs AccountRepository.cs
   Recompile
   ```

2. **Patient credentials still exist in Patient table** (if you didn't run step 4)
   - The app will still work with old Patient.Password columns
   - No data loss

3. **If cleanup script was run**, you need to restore from database backup

## Monitoring

After deployment, monitor:

1. **Check logs for login errors**
   ```
   Look for messages like:
   - "Login Unsuccessful"
   - "Patient record not found"
   - "Email not found"
   ```

2. **Verify new patients use UserAccount**
   ```sql
   SELECT COUNT(*) FROM UserAccount WHERE AccountType = 'Patient';
   SELECT COUNT(*) FROM Patient WHERE Password IS NOT NULL;
   /* These should match or be close (UserAccount may have more) */
   ```

3. **Check for orphaned records**
   ```sql
   -- UserAccounts without matching Patient
   SELECT ua.* FROM UserAccount ua
   LEFT JOIN Patient p ON ua.Patient_ID = p.Patient_ID
   WHERE ua.AccountType = 'Patient' AND p.Patient_ID IS NULL;
   ```

## Questions?

1. **Is this a breaking change?** No, existing functionality continues
2. **Can I rollback?** Yes, until you run the cleanup script
3. **Do I need to update FES?** No, FES can continue using Staff table
4. **What about existing staff passwords?** Still in Staff table for now
5. **When should I run cleanup?** After 1-2 weeks of successful operation

## Success Criteria

After implementation, you should have:

- ? All patient credentials in UserAccount table
- ? New patient registrations use UserAccount
- ? Patient login works from UserAccount
- ? Password reset works with UserAccount
- ? Admin account management uses UserAccount
- ? No patient credentials in Patient table (after cleanup)
- ? Old Patient.Password column removed (after cleanup)
