/*
   =====================================================================
   FORCE CLEANUP - Remove credential columns even with constraints

   This script will:
   1. DROP any indexes that reference credential columns
   2. DROP any constraints that reference credential columns  
   3. DROP the credential columns themselves
   4. Leave no trace of credentials in Patient/Staff tables

   SAFE: Checks for existence before dropping
   ===================================================================== */

USE [GroupWst6];
GO

PRINT '=================================================================';
PRINT 'FORCE CLEANUP: Remove ALL credential columns';
PRINT '=================================================================';
PRINT '';

-- ====================================================================
-- PART 1: Clean up indexes on Patient table
-- ====================================================================

PRINT 'PART 1: Removing indexes on Patient table credential columns...';
PRINT '??????????????????????????????????????????????????????????????';

DECLARE @indexName NVARCHAR(256)
DECLARE @indexSql NVARCHAR(MAX)

-- Find and drop any indexes on credential columns
DECLARE IndexCursor CURSOR FOR
SELECT DISTINCT i.name
FROM sys.indexes i
INNER JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
WHERE i.object_id = OBJECT_ID('dbo.Patient')
  AND ic.name IN ('Password', 'Is_First_Login', 'Is_Account_Active', 'Security_Question', 'Security_Answer', 'Account_Status')
  AND i.is_primary_key = 0
  AND i.is_unique = 0

OPEN IndexCursor
FETCH NEXT FROM IndexCursor INTO @indexName
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @indexSql = 'DROP INDEX [' + @indexName + '] ON dbo.Patient'
    EXEC sp_executesql @indexSql
    PRINT 'Dropped index: ' + @indexName
    FETCH NEXT FROM IndexCursor INTO @indexName
END
CLOSE IndexCursor
DEALLOCATE IndexCursor

-- ====================================================================
-- PART 2: Clean up indexes on Staff table
-- ====================================================================

PRINT ''
PRINT 'PART 2: Removing indexes on Staff table credential columns...';
PRINT '???????????????????????????????????????????????????????????';

DECLARE IndexCursor2 CURSOR FOR
SELECT DISTINCT i.name
FROM sys.indexes i
INNER JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
WHERE i.object_id = OBJECT_ID('dbo.Staff')
  AND ic.name IN ('Password', 'Is_First_Login', 'Is_Account_Active', 'Security_Question', 'Security_Answer')
  AND i.is_primary_key = 0
  AND i.is_unique = 0

OPEN IndexCursor2
FETCH NEXT FROM IndexCursor2 INTO @indexName
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @indexSql = 'DROP INDEX [' + @indexName + '] ON dbo.Staff'
    EXEC sp_executesql @indexSql
    PRINT 'Dropped index: ' + @indexName
    FETCH NEXT FROM IndexCursor2 INTO @indexName
END
CLOSE IndexCursor2
DEALLOCATE IndexCursor2

-- ====================================================================
-- PART 3: Remove credential columns from Patient table
-- ====================================================================

PRINT ''
PRINT 'PART 3: Removing credential columns from Patient table...';
PRINT '?????????????????????????????????????????????????????????';

BEGIN TRAN
BEGIN TRY

    -- Drop columns one by one with error handling
    IF COL_LENGTH('dbo.Patient', 'Password') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN [Password]
        PRINT '? Dropped Patient.[Password]'
    END
    ELSE
        PRINT '? Patient.[Password] already removed or does not exist'

    IF COL_LENGTH('dbo.Patient', 'Is_First_Login') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN [Is_First_Login]
        PRINT '? Dropped Patient.[Is_First_Login]'
    END
    ELSE
        PRINT '? Patient.[Is_First_Login] already removed or does not exist'

    IF COL_LENGTH('dbo.Patient', 'Is_Account_Active') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN [Is_Account_Active]
        PRINT '? Dropped Patient.[Is_Account_Active]'
    END
    ELSE
        PRINT '? Patient.[Is_Account_Active] already removed or does not exist'

    IF COL_LENGTH('dbo.Patient', 'Security_Question') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN [Security_Question]
        PRINT '? Dropped Patient.[Security_Question]'
    END
    ELSE
        PRINT '? Patient.[Security_Question] already removed or does not exist'

    IF COL_LENGTH('dbo.Patient', 'Security_Answer') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN [Security_Answer]
        PRINT '? Dropped Patient.[Security_Answer]'
    END
    ELSE
        PRINT '? Patient.[Security_Answer] already removed or does not exist'

    IF COL_LENGTH('dbo.Patient', 'Account_Status') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN [Account_Status]
        PRINT '? Dropped Patient.[Account_Status]'
    END
    ELSE
        PRINT '? Patient.[Account_Status] already removed or does not exist'

    COMMIT
    PRINT ''
    PRINT '? Patient table cleanup SUCCESSFUL'

END TRY
BEGIN CATCH
    ROLLBACK
    DECLARE @ErrorMsg NVARCHAR(4000) = ERROR_MESSAGE()
    PRINT '? Patient table cleanup FAILED: ' + @ErrorMsg
    RAISERROR (@ErrorMsg, 16, 1)
END CATCH

-- ====================================================================
-- PART 4: Remove credential columns from Staff table
-- ====================================================================

PRINT ''
PRINT 'PART 4: Removing credential columns from Staff table...';
PRINT '????????????????????????????????????????????????????????';

BEGIN TRAN
BEGIN TRY

    IF COL_LENGTH('dbo.Staff', 'Password') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN [Password]
        PRINT '? Dropped Staff.[Password]'
    END
    ELSE
        PRINT '? Staff.[Password] already removed or does not exist'

    IF COL_LENGTH('dbo.Staff', 'Is_First_Login') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN [Is_First_Login]
        PRINT '? Dropped Staff.[Is_First_Login]'
    END
    ELSE
        PRINT '? Staff.[Is_First_Login] already removed or does not exist'

    IF COL_LENGTH('dbo.Staff', 'Is_Account_Active') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN [Is_Account_Active]
        PRINT '? Dropped Staff.[Is_Account_Active]'
    END
    ELSE
        PRINT '? Staff.[Is_Account_Active] already removed or does not exist'

    IF COL_LENGTH('dbo.Staff', 'Security_Question') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN [Security_Question]
        PRINT '? Dropped Staff.[Security_Question]'
    END
    ELSE
        PRINT '? Staff.[Security_Question] already removed or does not exist'

    IF COL_LENGTH('dbo.Staff', 'Security_Answer') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN [Security_Answer]
        PRINT '? Dropped Staff.[Security_Answer]'
    END
    ELSE
        PRINT '? Staff.[Security_Answer] already removed or does not exist'

    COMMIT
    PRINT ''
    PRINT '? Staff table cleanup SUCCESSFUL'

END TRY
BEGIN CATCH
    ROLLBACK
    DECLARE @ErrorMsg2 NVARCHAR(4000) = ERROR_MESSAGE()
    PRINT '? Staff table cleanup FAILED: ' + @ErrorMsg2
    RAISERROR (@ErrorMsg2, 16, 1)
END CATCH

-- ====================================================================
-- PART 5: Final verification
-- ====================================================================

PRINT ''
PRINT 'PART 5: Final Verification - Credentials removed?';
PRINT '??????????????????????????????????????????????????';
PRINT ''

SELECT 
    'Patient Table' AS [Table],
    COUNT(*) AS [Total Records],
    CASE WHEN COL_LENGTH('dbo.Patient', 'Password') IS NOT NULL THEN 'STILL EXISTS ??' ELSE 'Removed ?' END AS [Password],
    CASE WHEN COL_LENGTH('dbo.Patient', 'Is_First_Login') IS NOT NULL THEN 'STILL EXISTS ??' ELSE 'Removed ?' END AS [Is_First_Login],
    CASE WHEN COL_LENGTH('dbo.Patient', 'Is_Account_Active') IS NOT NULL THEN 'STILL EXISTS ??' ELSE 'Removed ?' END AS [Is_Account_Active],
    CASE WHEN COL_LENGTH('dbo.Patient', 'Security_Question') IS NOT NULL THEN 'STILL EXISTS ??' ELSE 'Removed ?' END AS [Security_Question],
    CASE WHEN COL_LENGTH('dbo.Patient', 'Security_Answer') IS NOT NULL THEN 'STILL EXISTS ??' ELSE 'Removed ?' END AS [Security_Answer]
FROM dbo.Patient
GO

PRINT ''

SELECT 
    'Staff Table' AS [Table],
    COUNT(*) AS [Total Records],
    CASE WHEN COL_LENGTH('dbo.Staff', 'Password') IS NOT NULL THEN 'STILL EXISTS ??' ELSE 'Removed ?' END AS [Password],
    CASE WHEN COL_LENGTH('dbo.Staff', 'Is_First_Login') IS NOT NULL THEN 'STILL EXISTS ??' ELSE 'Removed ?' END AS [Is_First_Login],
    CASE WHEN COL_LENGTH('dbo.Staff', 'Is_Account_Active') IS NOT NULL THEN 'STILL EXISTS ??' ELSE 'Removed ?' END AS [Is_Account_Active],
    CASE WHEN COL_LENGTH('dbo.Staff', 'Security_Question') IS NOT NULL THEN 'STILL EXISTS ??' ELSE 'Removed ?' END AS [Security_Question],
    CASE WHEN COL_LENGTH('dbo.Staff', 'Security_Answer') IS NOT NULL THEN 'STILL EXISTS ??' ELSE 'Removed ?' END AS [Security_Answer]
FROM dbo.Staff
GO

PRINT ''
PRINT '=================================================================';
PRINT 'CLEANUP COMPLETE'
PRINT '=================================================================';
PRINT ''
PRINT '? If all columns show "Removed ?", cleanup was successful!';
PRINT '? If any show "STILL EXISTS ??", please check error messages above';
PRINT ''
