/* OPTIONAL (any time) minor schema addition for the website (M4 brief allows minor ERD changes for web requirements).
   Stores enquiries from the public Contact page. If you skip this, the Contact page still works
   and confirms receipt - it just doesn't save the message. Document it in the PFR if you add it. */
USE [GroupWst6];
IF OBJECT_ID('dbo.ContactEnquiry', 'U') IS NULL
CREATE TABLE dbo.ContactEnquiry (
    Enquiry_ID     INT IDENTITY(1,1) PRIMARY KEY,
    Full_Name      VARCHAR(100) NOT NULL,
    Email          VARCHAR(50)  NOT NULL,
    Contact_No     CHAR(10)     NULL,
    Treatment      VARCHAR(50)  NULL,
    Message        VARCHAR(500) NOT NULL,
    Date_Received  DATETIME     NOT NULL DEFAULT GETDATE(),
    Status         VARCHAR(20)  NOT NULL DEFAULT 'New'
);
