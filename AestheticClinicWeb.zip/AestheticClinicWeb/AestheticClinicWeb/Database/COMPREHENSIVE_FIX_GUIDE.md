# COMPREHENSIVE PROJECT FIX GUIDE

## ?? Objective
Convert your AestheticClinicWeb project to use **unified UserAccount credentials** where:
- ? ALL authentication credentials stored in `UserAccount` table ONLY
- ? `Patient` table contains ONLY patient demographic data
- ? `Staff` table contains ONLY staff information
- ? No credential/role fields in Patient or Staff tables
- ? Maximum security with centralized credential management

---

## ?? What You're Fixing

### Current Issues
1. **Duplicate credentials** - Credentials may still exist in Patient/Staff tables
2. **Inconsistent role management** - Role might be in Staff table instead of UserAccount
3. **Missing UserAccount entries** - Some staff may not have UserAccount records
4. **Security risk** - Credentials scattered across multiple tables
5. **Code-database mismatch** - Code expects credentials in UserAccount, but DB might have them elsewhere

### Target Architecture
```
UNIFIED CREDENTIAL SYSTEM
?????????????????????????????????????????????????????????????

???????????????????????????????????????????
?        UserAccount Table                ?
?  (SINGLE SOURCE OF TRUTH)               ?
???????????????????????????????????????????
? � User_ID (PK)                          ?
? � Email (Unique login ID)               ?
? � Password (Hashed)                     ?
? � Role (Doctor, Receptionist, etc.)     ?
? � AccountType (Staff or Patient)        ?
? � Staff_ID (FK to Staff, if staff)      ?
? � Patient_ID (FK to Patient, if patient)?
? � Is_Active (Account enabled)           ?
? � Is_First_Login (Force pwd change)     ?
? � Is_Account_Active (Can log in)        ?
? � Security_Question (Forgot pwd)        ?
? � Security_Answer (Forgot pwd)          ?
???????????????????????????????????????????
         ?              ?
    ??????????????   ????????????????
    ? Staff      ?   ? Patient      ?
    ??????????????   ????????????????
    ?Staff_ID    ?   ?Patient_ID    ?
    ?First_Name  ?   ?First_Name    ?
    ?Last_Name   ?   ?Last_Name     ?
    ?Email       ?   ?ID_Number     ?
    ?Is_Active   ?   ?Gender        ?
    ?(No creds)  ?   ?DOB           ?
    ?(No role)   ?   ?Address       ?
    ?            ?   ?Contact_No    ?
    ?            ?   ?Email         ?
    ?            ?   ?Allergies     ?
    ?            ?   ?Is_Active     ?
    ?            ?   ?(No creds)    ?
    ??????????????   ????????????????
```

---

## ??? STEP 1: Run Master Database Fix Script

### Step 1a: Execute the Master Fix Script

**File:** `Database/00_MASTER_FIX_UNIFIED_CREDENTIALS.sql`

**Instructions:**
1. Open **SQL Server Management Studio (SSMS)**
2. Connect to your database: `GroupWst6` (146.230.177.46)
3. Open the file: `Database/00_MASTER_FIX_UNIFIED_CREDENTIALS.sql`
4. Execute it (F5 or Query ? Execute)

**What it does:**
- ? Removes all default constraints
- ? Removes Password column from Patient table
- ? Removes Password, Role, Is_First_Login, Security_* columns from Staff table
- ? Ensures Email and Is_Active columns exist in both tables
- ? Verifies UserAccount table structure
- ? Identifies orphaned staff/patients
- ? Displays final table structures

**Expected Output:**
```
? Removed Patient.Password
? Removed Staff.Password
? Removed Staff.Role (now managed in UserAccount)
? Removed Staff.Is_First_Login
... (more removals)
? All staff members have UserAccount entries
? UserAccount table has all required columns

FINAL TABLE STRUCTURES
Patient table columns:
  � Patient_ID (int, NOT NULL)
  � First_Name (varchar, NOT NULL)
  � Last_Name (varchar, NOT NULL)
  ...

Staff table columns:
  � Staff_ID (int, NOT NULL)
  � First_Name (varchar, NOT NULL)
  � Last_Name (varchar, NOT NULL)
  � Email (varchar, nullable)
  � Is_Active (bit, NOT NULL)

UserAccount table columns:
  � User_ID (int, NOT NULL)
  � Email (varchar, NOT NULL)
  � Password (varchar, NOT NULL)
  � Role (varchar, NOT NULL)
  ...
```

---

## ??? STEP 2: Review Code (Already Fixed)

Your C# code in `AccountRepository.cs` is **already correctly configured**:

### ? Login() Method (Lines 42-117)
- ? Checks UserAccount ONLY
- ? No fallback to Staff/Patient tables
- ? Verifies credentials in UserAccount

### ? Staff() Method (Lines 327-337)
- ? Reads `ua.Role` from UserAccount (not `s.Role`)
- ? Query: `SELECT ... ua.Role ... FROM UserAccount ua JOIN Staff s`

### ? AddStaff() Method (Lines 339-360)
- ? Creates Staff record with name/email only (NO password)
- ? Creates UserAccount record with credentials and role
- ? Separate concerns: Staff table ? UserAccount table

### ? UpdateStaff() Method (Lines 363-372)
- ? Updates name/email in Staff table
- ? Updates role/email in UserAccount table
- ? No duplicate role updates

---

## ??? STEP 3: Handle Orphaned Staff (If Any)

### Check Results from Script
The master fix script will tell you if any staff have no UserAccount entry.

**If you see warnings like:**
```
? WARNING: 3 staff members have no UserAccount entry!
Staff without UserAccount:
  ? Staff_ID: 1 | John Doe | Email: john@clinic.com
  ? Staff_ID: 2 | Jane Smith | Email: jane@clinic.com
  ? Staff_ID: 3 | Bob Johnson | Email: NO EMAIL
```

### Fix #1: Create UserAccount via Application UI
1. Log in as Admin to staff portal
2. Go to `Portal ? Manage Staff`
3. Click "Add Staff" or find the orphaned staff
4. Create UserAccount entry with:
   - Email
   - Temporary password
   - Role (Doctor, Receptionist, etc.)
5. Staff can log in with temporary password and change it

### Fix #2: Create UserAccount via SQL (If needed)
```sql
INSERT INTO UserAccount (Email, [Password], [Role], AccountType, Staff_ID, Is_Active, Is_First_Login, Is_Account_Active)
VALUES (@email, @hashedPassword, @role, 'Staff', @staffId, 1, 1, 1);
```

---

## ??? STEP 4: Rebuild Application

### Step 4a: Clean Rebuild
```
Visual Studio ? Build ? Clean Solution
(Wait for completion)
Visual Studio ? Build ? Rebuild Solution
```

### Step 4b: Verify No Compilation Errors
? Should see "Build succeeded"

---

## ?? STEP 5: Comprehensive Testing

### Test #1: Staff Login
```
1. Log out completely
2. Go to Login page
3. Enter staff email/password
4. Should successfully log in
5. Should see Portal dashboard
6. Check no SQL errors
```

### Test #2: Staff List Display
```
1. Log in as admin/doctor
2. Go to Portal ? Manage Staff
3. Should see list of all staff
4. Columns should show: Name, Email, Role, Status
5. NO missing roles or errors
```

### Test #3: Add New Staff
```
1. In Portal ? Manage Staff
2. Click "Add New Staff"
3. Enter: Name, Email, Role
4. Click Create
5. New staff should appear in list
6. Should receive temporary password
7. Should be able to log in
```

### Test #4: Edit Staff
```
1. In Portal ? Manage Staff
2. Click on a staff member
3. Edit name or email
4. Save
5. Changes should persist
6. Staff should still be able to log in
```

### Test #5: Reset Password
```
1. In Portal ? Manage Staff
2. Click on a staff member
3. Click "Reset Password"
4. Enter temporary password
5. Staff receives new password
6. Staff must change it on next login
```

### Test #6: Patient Registration
```
1. Go to website home
2. Click "Register" or "Book Online"
3. Fill registration form
4. Should create new patient
5. Should create UserAccount
6. Email should be sent
7. Should be able to log in
```

### Test #7: Patient Login
```
1. Go to Login page
2. Enter patient email/password
3. Should successfully log in
4. Should see Patient dashboard
5. Should see appointments, invoices, etc.
```

### Test #8: Change Password (Staff)
```
1. Log in as staff
2. Go to Account ? Change Password
3. Enter old password
4. Enter new password
5. Should successfully change
6. Should log out
7. Log back in with new password
```

### Test #9: Forgot Password (Patient)
```
1. Go to Login page
2. Click "Forgot password"
3. Enter email
4. Should show security question
5. Answer correctly
6. Should be able to reset password
7. Should be able to log in with new password
```

---

## ?? Final Database Schema

### Patient Table (Demographics Only)
```sql
CREATE TABLE Patient (
    Patient_ID INT PRIMARY KEY IDENTITY(1,1),
    First_Name VARCHAR(50) NOT NULL,
    Last_Name VARCHAR(50) NOT NULL,
    ID_Number VARCHAR(13) NOT NULL,
    Gender CHAR(1) NOT NULL,
    Date_Of_Birth DATETIME NOT NULL,
    Address VARCHAR(200),
    Contact_No VARCHAR(10),
    Email VARCHAR(100),
    Allergies TEXT,
    Extra_Notes TEXT,
    Is_Active BIT NOT NULL DEFAULT 1
    -- NO: Password, Is_First_Login, Security_Question, Security_Answer, etc.
);
```

### Staff Table (Info Only)
```sql
CREATE TABLE Staff (
    Staff_ID INT PRIMARY KEY IDENTITY(1,1),
    First_Name VARCHAR(50) NOT NULL,
    Last_Name VARCHAR(50) NOT NULL,
    Email VARCHAR(100),
    Is_Active BIT NOT NULL DEFAULT 1
    -- NO: Password, Role, Is_First_Login, Security_Question, Security_Answer, etc.
);
```

### UserAccount Table (Credentials ONLY)
```sql
CREATE TABLE UserAccount (
    User_ID INT PRIMARY KEY IDENTITY(1,1),
    Email VARCHAR(100) NOT NULL UNIQUE,
    [Password] VARCHAR(255) NOT NULL,
    [Role] VARCHAR(50) NOT NULL,
    AccountType VARCHAR(20) NOT NULL, -- 'Staff' or 'Patient'
    Staff_ID INT FOREIGN KEY REFERENCES Staff(Staff_ID),
    Patient_ID INT FOREIGN KEY REFERENCES Patient(Patient_ID),
    Is_Active BIT NOT NULL DEFAULT 1,
    Is_First_Login BIT NOT NULL DEFAULT 0,
    Is_Account_Active BIT NOT NULL DEFAULT 1,
    Security_Question VARCHAR(225),
    Security_Answer VARCHAR(225)
);
```

---

## ? Verification Checklist

- [ ] Master fix script executed successfully
- [ ] No compilation errors after rebuild
- [ ] Staff login works
- [ ] Staff list shows in Portal
- [ ] Add new staff works
- [ ] Edit staff works
- [ ] Reset password works
- [ ] Patient registration works
- [ ] Patient login works
- [ ] Change password works (staff)
- [ ] Forgot password works (patient)
- [ ] All roles display correctly
- [ ] No SQL errors in any operation
- [ ] UserAccount is single source of truth for all credentials

---

## ?? Security Benefits

? **Centralized Credentials**
- All passwords in one place
- Easier to implement security policies
- Easier to audit access

? **Separation of Concerns**
- Patient data ? Authentication data
- Staff data ? Authentication data
- Cleaner, more maintainable schema

? **GDPR Compliance**
- Easier to purge old credentials
- Clear data retention policies
- Better data governance

? **Future-Ready**
- Can add MFA easily
- Can implement session tracking
- Can add account lockouts
- Can add password expiration

---

## ?? Troubleshooting

### Issue: "SQL Error 207: Invalid column name"
**Cause:** Old credential columns still exist or being referenced
**Fix:** Ensure master script completed successfully, rebuild app

### Issue: "Staff list not showing in Portal"
**Cause:** Query trying to read `s.Role` instead of `ua.Role`
**Fix:** Verify `AccountRepository.Staff()` method uses `ua.Role`

### Issue: "Can't log in as staff"
**Cause:** Staff have no UserAccount entry
**Fix:** Run master script to identify, then create UserAccount via UI or SQL

### Issue: "Add staff fails with constraint error"
**Cause:** Default constraint still exists on a column
**Fix:** Master script should handle this, re-run it

### Issue: "Passwords not working"
**Cause:** Password column deleted but still being used
**Fix:** Verify code only uses UserAccount for credentials

---

## ?? Files Modified

### C# Code
- ? `AccountRepository.cs` - Already fixed (Login, Staff, AddStaff, UpdateStaff methods)
- ? No changes needed

### Database Scripts
- ? `00_MASTER_FIX_UNIFIED_CREDENTIALS.sql` - Use this ONLY

### Configuration
- ? `connections.config` - No changes needed
- ? `Web.config` - No changes needed

---

## ?? Success Criteria

When complete, you should have:
- ? Zero credential fields in Patient table
- ? Zero credential fields in Staff table
- ? ALL credentials in UserAccount table
- ? All staff can log in successfully
- ? All staff have UserAccount entries
- ? Roles managed through UserAccount only
- ? No SQL errors or warnings
- ? Code compiles without errors
- ? Staff list displays correctly in Portal
- ? All tests pass

---

**When complete, your system will have a clean, secure, unified credential architecture! ??**
