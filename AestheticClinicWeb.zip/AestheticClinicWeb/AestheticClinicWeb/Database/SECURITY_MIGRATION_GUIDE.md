# Security Migration: Unified Login Credentials

## Problem Statement
The original architecture stored login credentials in two separate places:
- **Staff login**: `Staff` table (Email, Password, Role)
- **Patient login**: `Patient` table (Email, Password, Role, Security_Question, Security_Answer)

This creates security risks:
1. **Data Sensitivity**: Patient records mix personal health data with sensitive credentials
2. **Access Control**: Harder to restrict who can modify passwords without exposing full patient records
3. **Audit Trail**: No centralized place to log authentication events
4. **Compliance**: Makes GDPR compliance harder (harder to purge old credentials separately)
5. **Maintenance**: Duplicate logic for password hashing, security questions, etc.

## Solution: Unified UserAccount Table

All login credentials (staff and patient) now live in a single `UserAccount` table:

```sql
UserAccount (
    UserAccount_ID INT PRIMARY KEY,
    Email VARCHAR(100) UNIQUE,        -- Login identifier
    Password VARCHAR(255),            -- PBKDF2 hash (website) or plain text (FES)
    Role VARCHAR(50),                 -- 'Patient', 'Doctor', 'Receptionist', etc.
    AccountType VARCHAR(20),          -- 'Patient' or 'Staff' (distinguishes type)
    Patient_ID INT UNIQUE FOREIGN KEY,-- References Patient.Patient_ID (null for staff)
    Staff_ID INT UNIQUE FOREIGN KEY,  -- References Staff.Staff_ID (null for patients)
    Is_Active BIT,                    -- Account enabled/disabled
    Is_First_Login BIT,               -- Must change password on next login
    Is_Account_Active BIT,            -- Permission to log in (separate from Is_Active)
    Security_Question VARCHAR(225),   -- For password recovery
    Security_Answer VARCHAR(255),     -- Hashed answer
    Created_Date DATETIME,
    Modified_Date DATETIME
)
```

### Key Design Decisions

1. **Patient_ID and Staff_ID are NOT foreign keys with ON DELETE CASCADE**
   - Patient/Staff records can exist without logins
   - Deleting a patient doesn't delete their historical login records
   - Orphaned logins can be archived rather than deleted

2. **Email is unique across both staff and patients**
   - Prevents duplicate login identifiers
   - Simplifies the login() method

3. **Is_Account_Active is separate from Is_Active**
   - Staff can suspend a specific login without archiving the patient/staff record
   - Patient.Is_Active means the patient is still under care
   - UserAccount.Is_Account_Active means they can access the website

4. **AccountType distinguishes between staff and patients**
   - Makes it clear which FK to follow (Staff_ID vs Patient_ID)
   - Enables query optimization

## Migration Path

### Step 1: Database Migration
Run `06_Migrate_To_Unified_UserAccount.sql`
- Creates the new `UserAccount` table
- Migrates existing patient credentials from Patient table
- Creates a view for backward compatibility (optional)

### Step 2: Code Deployment
Replace `AccountRepository.cs` with `AccountRepository_Secure.cs`

Changes include:
- `Login()` now queries `UserAccount` instead of Staff and Patient tables
- `RegisterPatient()` creates entries in `UserAccount` instead of storing in Patient table
- All password/security question methods query `UserAccount`
- Admin methods (SetPatientAccountActive, IssueTempPassword) updated

### Step 3: Testing
Before step 4, thoroughly test:
- Staff login (from Staff table, credentials in UserAccount)
- Patient login (from Patient table, credentials in UserAccount)
- Patient registration (creates Patient + UserAccount)
- Password reset (Forgot Password flow)
- First login (must change password)
- Admin: Approve/Deny patient registrations
- Admin: Reset password
- Admin: Deactivate account

### Step 4: Cleanup
Run `08_Cleanup_Old_Credentials.sql`
- Drops Password, Is_First_Login, Is_Account_Active, Security_Question, Security_Answer from Patient table
- Patient table becomes a pure data table

## Benefits

| Benefit | Impact |
|---------|--------|
| **Centralized Credentials** | Single source of truth for all logins |
| **Better Access Control** | Can restrict password management without exposing patient data |
| **Audit Trail** | Easier to log who logged in when |
| **GDPR Compliance** | Can purge login records without deleting patient medical data |
| **Security** | Credentials not mixed with sensitive health data |
| **Scalability** | Can add MFA, OAuth, SSO without modifying Patient table |
| **Separation of Concerns** | Credentials ? Business Data |

## Backward Compatibility

The FES (Front-End System) does NOT need to change:
- The FES only queries the `Staff` table
- `Staff.Password` remains in the Staff table (unchanged)
- `Staff.Is_First_Login`, `Staff.Is_Active`, etc. remain unchanged
- The website now also uses `UserAccount` for staff logins (dual-source) during transition

Future: Once FES is retired or updated, `Staff` table credentials can also move to `UserAccount`.

## Rollback Plan

If issues arise:

1. **Don't run step 4** (the cleanup script) - keep old credential columns
2. Revert code changes (restore original AccountRepository.cs)
3. Patient and Staff tables still have their credentials in the old columns
4. App will continue working

## Security Considerations

1. **Password Storage**
   - Website passwords: PBKDF2 hash (salted and iterative)
   - FES passwords: Plain text (FES requirement, temporary during transition)
   - After FES retirement: All passwords hashed

2. **Credential Rotation**
   - Easier to implement password expiry policies
   - Can require password changes on specific dates

3. **Account Lockout**
   - Can track login attempts in UserAccount
   - Implement automatic lockout after N failed attempts

4. **Audit Trail**
   - Consider adding `Last_Login_Date` and `Last_Login_IP` columns
   - Can log password changes

## Database Schema Evolution

```
BEFORE:
???????????????????         ????????????????????????
? Staff           ?         ? Patient              ?
???????????????????         ????????????????????????
? Staff_ID        ?         ? Patient_ID           ?
? Email           ?         ? First_Name           ?
? Password        ???????   ? Last_Name            ?
? Role            ?     ?   ? Email                ?
? Is_Active       ?     ?   ? Password             ?
? Is_First_Login  ?     ?   ? Is_First_Login       ?
? Security_Q      ?     ?   ? Is_Account_Active    ?
?                 ?     ?   ? Security_Q           ?
???????????????????     ?   ? (health data...)     ?
                        ?   ????????????????????????
      ISSUE: Credentials mixed with business data

AFTER:
????????????????????????
? UserAccount          ?  ?????? ALL CREDENTIALS HERE
????????????????????????
? UserAccount_ID       ?
? Email  (unique)      ?
? Password             ?
? Role                 ?
? AccountType          ?
? Staff_ID ???         ?
? Patient_ID ?         ?
?            ?         ?
?????????????????????????
             ?
     ??????????????????
     ?                ?
????????????    ??????????????????????
? Staff     ?    ? Patient            ?
?????????????    ??????????????????????
? Staff_ID  ?    ? Patient_ID         ?
? Name      ?    ? Name               ?
? Role      ?    ? DOB                ?
? (no pwd)  ?    ? (health data...)   ?
?????????????    ? (no credentials)   ?
                 ??????????????????????
     BETTER: Credentials separate from business data
```

## Migration Timeline

- **Phase 1 (Now)**: Database + Code update, parallel operation
  - Both credential sources active
  - New registrations go to UserAccount
  - Existing staff use Staff table

- **Phase 2 (After FES retirement)**: Migrate remaining staff credentials
  - Move Staff.Password ? UserAccount
  - Clean up Staff table

- **Phase 3**: Enhanced security
  - Add MFA support
  - Add OAuth/SSO integration
  - Add password policies

## Questions for Your Mentor

1. Should we also migrate staff credentials to UserAccount now, or wait until FES is retired?
2. Should we add an audit table to log login attempts?
3. Should we add password expiry policies?
4. Should we add account lockout after N failed attempts?
