/* =====================================================================
   STEP 1 - Patient login columns (run first, once). Safe to re-run.
   Patients log in to the website with Patient.Email + Patient.Password.
   * Password          : temporary password from the FES (plain, emailed), then the patient's own
                         password, which the website stores as a PBKDF2 hash.
   * Is_First_Login    : 1 = must create own password at next login (default for every new patient).
   * Is_Account_Active : 1 = may log in to the website. Staff switch this in Manage Accounts.
                         (Separate from Is_Active, which the FES uses to archive a patient.)
   * Security_Question / Security_Answer : for "Forgot password" (set by the patient at first login).
   Existing FES queries keep working: they list their columns explicitly, and new columns have defaults.
   ===================================================================== */
USE [GroupWst6];
GO
IF COL_LENGTH('dbo.Patient', 'Password') IS NULL
    ALTER TABLE dbo.Patient ADD [Password] VARCHAR(255) NULL;
IF COL_LENGTH('dbo.Patient', 'Is_First_Login') IS NULL
    ALTER TABLE dbo.Patient ADD Is_First_Login BIT NOT NULL CONSTRAINT DF_Patient_Is_First_Login DEFAULT (1);
IF COL_LENGTH('dbo.Patient', 'Is_Account_Active') IS NULL
    ALTER TABLE dbo.Patient ADD Is_Account_Active BIT NOT NULL CONSTRAINT DF_Patient_Is_Account_Active DEFAULT (1);
IF COL_LENGTH('dbo.Patient', 'Security_Question') IS NULL
    ALTER TABLE dbo.Patient ADD Security_Question VARCHAR(225) NULL;
IF COL_LENGTH('dbo.Patient', 'Security_Answer') IS NULL
    ALTER TABLE dbo.Patient ADD Security_Answer VARCHAR(225) NULL;
GO

/* Move the one existing patient web account (Joseph Frost, UserAccount role 'patient') onto his Patient record.
   He keeps his password; his 'Denied' status becomes Is_Account_Active = 0 (activate him in Manage Accounts). */
UPDATE p
SET p.[Password]          = ua.[Password],
    p.Is_First_Login      = 0,
    p.Is_Account_Active   = CASE WHEN ua.Account_Status = 'Confirmed' THEN 1 ELSE 0 END,
    p.Security_Question   = NULLIF(ua.Security_Question, 'Not Set'),
    p.Security_Answer     = NULLIF(ua.Security_Answer, 'Not Set')
FROM dbo.Patient p
JOIN dbo.UserAccount ua ON ua.Patient_ID = p.Patient_ID
WHERE ua.[Role] = 'patient' AND p.[Password] IS NULL;
GO

/* Check: email is the patient's login, so it must be unique. Fix any rows listed here in the FES. */
SELECT Email, COUNT(*) AS Patients_Using_It, STRING_AGG(CAST(Patient_ID AS varchar(10)), ', ') AS Patient_IDs
FROM dbo.Patient GROUP BY Email HAVING COUNT(*) > 1;
GO
SELECT 'Step 1 complete' AS Result;
