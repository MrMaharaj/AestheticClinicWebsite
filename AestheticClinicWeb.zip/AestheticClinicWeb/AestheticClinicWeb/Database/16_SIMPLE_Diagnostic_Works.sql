/*
   =====================================================================
   MASTER DIAGNOSTIC & REPAIR - SIMPLIFIED & WORKING VERSION

   Run this to:
   1. See what columns actually exist (database level, not SSMS cache)
   2. Attempt to remove any credential columns still there
   3. Verify results
   ===================================================================== */

USE [GroupWst6];
GO

PRINT '';
PRINT '====================================================================';
PRINT '           CHECKING CREDENTIAL COLUMNS IN DATABASE';
PRINT '====================================================================';
PRINT '';

-- ====================================================================
-- Check Patient Table for Credential Columns
-- ====================================================================
PRINT 'PATIENT TABLE - Credential Column Status:';
PRINT '???????????????????????????????????????';

SELECT 
    'Password' AS [Column],
    CASE WHEN COL_LENGTH('dbo.Patient', 'Password') IS NOT NULL THEN '??  STILL EXISTS' ELSE '? REMOVED' END AS [Status]
UNION ALL SELECT 'Is_First_Login', CASE WHEN COL_LENGTH('dbo.Patient', 'Is_First_Login') IS NOT NULL THEN '??  STILL EXISTS' ELSE '? REMOVED' END
UNION ALL SELECT 'Is_Account_Active', CASE WHEN COL_LENGTH('dbo.Patient', 'Is_Account_Active') IS NOT NULL THEN '??  STILL EXISTS' ELSE '? REMOVED' END
UNION ALL SELECT 'Security_Question', CASE WHEN COL_LENGTH('dbo.Patient', 'Security_Question') IS NOT NULL THEN '??  STILL EXISTS' ELSE '? REMOVED' END
UNION ALL SELECT 'Security_Answer', CASE WHEN COL_LENGTH('dbo.Patient', 'Security_Answer') IS NOT NULL THEN '??  STILL EXISTS' ELSE '? REMOVED' END
UNION ALL SELECT 'Account_Status', CASE WHEN COL_LENGTH('dbo.Patient', 'Account_Status') IS NOT NULL THEN '??  STILL EXISTS' ELSE '? REMOVED' END;

PRINT '';
PRINT 'STAFF TABLE - Credential Column Status:';
PRINT '???????????????????????????????????????';

SELECT 
    'Password' AS [Column],
    CASE WHEN COL_LENGTH('dbo.Staff', 'Password') IS NOT NULL THEN '??  STILL EXISTS' ELSE '? REMOVED' END AS [Status]
UNION ALL SELECT 'Is_First_Login', CASE WHEN COL_LENGTH('dbo.Staff', 'Is_First_Login') IS NOT NULL THEN '??  STILL EXISTS' ELSE '? REMOVED' END
UNION ALL SELECT 'Is_Account_Active', CASE WHEN COL_LENGTH('dbo.Staff', 'Is_Account_Active') IS NOT NULL THEN '??  STILL EXISTS' ELSE '? REMOVED' END
UNION ALL SELECT 'Security_Question', CASE WHEN COL_LENGTH('dbo.Staff', 'Security_Question') IS NOT NULL THEN '??  STILL EXISTS' ELSE '? REMOVED' END
UNION ALL SELECT 'Security_Answer', CASE WHEN COL_LENGTH('dbo.Staff', 'Security_Answer') IS NOT NULL THEN '??  STILL EXISTS' ELSE '? REMOVED' END;

PRINT '';
PRINT '====================================================================';
PRINT '                        ATTEMPTING REMOVAL';
PRINT '====================================================================';
PRINT '';

-- ====================================================================
-- Try to Remove Any Remaining Columns
-- ====================================================================
PRINT 'Attempting to remove credential columns if they still exist...';
PRINT '';

BEGIN TRY
    IF COL_LENGTH('dbo.Patient', 'Password') IS NOT NULL
        ALTER TABLE dbo.Patient DROP COLUMN [Password];

    IF COL_LENGTH('dbo.Patient', 'Is_First_Login') IS NOT NULL
        ALTER TABLE dbo.Patient DROP COLUMN [Is_First_Login];

    IF COL_LENGTH('dbo.Patient', 'Is_Account_Active') IS NOT NULL
        ALTER TABLE dbo.Patient DROP COLUMN [Is_Account_Active];

    IF COL_LENGTH('dbo.Patient', 'Security_Question') IS NOT NULL
        ALTER TABLE dbo.Patient DROP COLUMN [Security_Question];

    IF COL_LENGTH('dbo.Patient', 'Security_Answer') IS NOT NULL
        ALTER TABLE dbo.Patient DROP COLUMN [Security_Answer];

    IF COL_LENGTH('dbo.Patient', 'Account_Status') IS NOT NULL
        ALTER TABLE dbo.Patient DROP COLUMN [Account_Status];

    IF COL_LENGTH('dbo.Staff', 'Password') IS NOT NULL
        ALTER TABLE dbo.Staff DROP COLUMN [Password];

    IF COL_LENGTH('dbo.Staff', 'Is_First_Login') IS NOT NULL
        ALTER TABLE dbo.Staff DROP COLUMN [Is_First_Login];

    IF COL_LENGTH('dbo.Staff', 'Is_Account_Active') IS NOT NULL
        ALTER TABLE dbo.Staff DROP COLUMN [Is_Account_Active];

    IF COL_LENGTH('dbo.Staff', 'Security_Question') IS NOT NULL
        ALTER TABLE dbo.Staff DROP COLUMN [Security_Question];

    IF COL_LENGTH('dbo.Staff', 'Security_Answer') IS NOT NULL
        ALTER TABLE dbo.Staff DROP COLUMN [Security_Answer];

    PRINT '? Removal process completed';
END TRY
BEGIN CATCH
    PRINT '??  Note: ' + ERROR_MESSAGE();
END CATCH

PRINT '';
PRINT '====================================================================';
PRINT '                      FINAL VERIFICATION';
PRINT '====================================================================';
PRINT '';

PRINT 'PATIENT TABLE - Final Status:';
PRINT '?????????????????????????????';

IF COL_LENGTH('dbo.Patient', 'Password') IS NOT NULL OR
   COL_LENGTH('dbo.Patient', 'Is_First_Login') IS NOT NULL OR
   COL_LENGTH('dbo.Patient', 'Is_Account_Active') IS NOT NULL OR
   COL_LENGTH('dbo.Patient', 'Security_Question') IS NOT NULL OR
   COL_LENGTH('dbo.Patient', 'Security_Answer') IS NOT NULL OR
   COL_LENGTH('dbo.Patient', 'Account_Status') IS NOT NULL
    PRINT '? STILL HAS CREDENTIAL COLUMNS'
ELSE
    PRINT '? CLEAN - ALL CREDENTIALS REMOVED'

PRINT '';
PRINT 'STAFF TABLE - Final Status:';
PRINT '????????????????????????????';

IF COL_LENGTH('dbo.Staff', 'Password') IS NOT NULL OR
   COL_LENGTH('dbo.Staff', 'Is_First_Login') IS NOT NULL OR
   COL_LENGTH('dbo.Staff', 'Is_Account_Active') IS NOT NULL OR
   COL_LENGTH('dbo.Staff', 'Security_Question') IS NOT NULL OR
   COL_LENGTH('dbo.Staff', 'Security_Answer') IS NOT NULL
    PRINT '? STILL HAS CREDENTIAL COLUMNS'
ELSE
    PRINT '? CLEAN - ALL CREDENTIALS REMOVED'

PRINT '';
PRINT '====================================================================';
PRINT '                        NEXT STEPS';
PRINT '====================================================================';
PRINT '';
PRINT 'If you see "? CLEAN - ALL CREDENTIALS REMOVED" above:';
PRINT '  1. Columns are actually gone from the database ?';
PRINT '  2. The visual display in SSMS is just a cache';
PRINT '  3. Close SQL Server Management Studio completely';
PRINT '  4. Re-open SQL Server Management Studio';
PRINT '  5. Right-click Patient table ? Refresh';
PRINT '  6. Right-click Staff table ? Refresh';
PRINT '  7. Column list should now be updated ?';
PRINT '';
PRINT 'If you still see "? STILL HAS CREDENTIAL COLUMNS":';
PRINT '  1. Check the error messages above';
PRINT '  2. There may be a constraint preventing removal';
PRINT '  3. Contact support with the error message';
PRINT '';
PRINT '====================================================================';
GO
