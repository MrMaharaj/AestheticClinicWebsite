# ROLE-BASED ACCESS CONTROL (RBAC) IMPLEMENTATION GUIDE

## Overview

This guide explains how to implement and use role-based access control in the AestheticClinic application. After the credential consolidation, access control is now managed purely through **roles** stored in the `UserAccount.Role` column.

---

## Current Architecture

### Before: Mixed Credentials
```
Patient table     -> Had: Password, Email, Role, etc. (mixed)
Staff table       -> Had: Password, Email, Role, etc. (mixed)
UserAccount table -> New credentials location
```

### After: Unified + Role-Based
```
Patient table     -> Pure data ONLY (First_Name, Last_Name, DOB, etc.)
Staff table       -> Pure data ONLY (First_Name, Last_Name, Email, etc.)
UserAccount table -> ONLY credentials + roles (Email, Password, Role, etc.)

Access Control    -> Based ONLY on UserAccount.Role
```

---

## Standard Roles

Define these roles in your database or Web.config:

### 1. Patient
```sql
Role = 'Patient'
AccountType = 'Patient'
Patient_ID = <reference to Patient table>
Staff_ID = NULL
```

**Permissions:**
- ? View own appointments
- ? Book/cancel own appointments
- ? View own invoices
- ? View own treatment results
- ? Update own profile
- ? Change own password
- ? Cannot see other patients' data
- ? Cannot access staff portal

**Access Pages:**
```
/Patient/*.aspx (Dashboard, Appointments, Invoices, Progress, etc.)
```

---

### 2. Receptionist
```sql
Role = 'Receptionist'
AccountType = 'Staff'
Patient_ID = NULL
Staff_ID = <reference to Staff table>
```

**Permissions:**
- ? View all patients (summary)
- ? Manage appointments (book, reschedule, cancel)
- ? Issue temporary passwords to patients
- ? Activate/deactivate patient accounts
- ? View invoices (all patients)
- ? View basic reports
- ? Cannot see clinical notes/treatment details
- ? Cannot manage staff
- ? Cannot see financial reports

**Access Pages:**
```
/Portal/Dashboard.aspx
/Portal/Appointments.aspx
/Portal/Patients.aspx (summary view)
/Portal/Invoices.aspx
/Portal/ManageAccounts.aspx (limited)
```

---

### 3. Doctor (or Main Clinician)
```sql
Role = 'Doctor'
AccountType = 'Staff'
Patient_ID = NULL
Staff_ID = <reference to Staff table>
```

**Permissions:**
- ? View all patients (full details)
- ? View clinical notes and treatment results
- ? Manage appointments
- ? Manage staff (add, edit, remove, reset passwords)
- ? View all reports and metrics
- ? System administration
- ? Access everything

**Access Pages:**
```
/Portal/* (all pages)
/Portal/ManageAccounts.aspx (full access)
/Portal/Patients.aspx (full details)
/Portal/PatientHistory.aspx (clinical data)
/Portal/Reports.aspx (all)
/Portal/Metrics.aspx (all)
```

---

### 4. Therapist (Optional)
```sql
Role = 'Therapist'
AccountType = 'Staff'
Patient_ID = NULL
Staff_ID = <reference to Staff table>
```

**Permissions:**
- ? View patient details for patients they treat
- ? View appointment schedule
- ? View treatment-related information
- ? Book appointments
- ? View progress/results
- ? Cannot see financial data
- ? Cannot manage staff
- ? Cannot see other therapists' patients

**Access Pages:**
```
/Portal/Dashboard.aspx (limited)
/Portal/Appointments.aspx (their own)
/Portal/PatientHistory.aspx (limited, treatment only)
```

---

## How to Use RoleBasedAccess in Code

### 1. Check if user has a role

```csharp
using AestheticClinicWeb.Helpers;

// Check if current user is a Doctor
if (RoleBasedAccess.IsDoctor())
{
    lblMessage.Text = "Full admin access granted";
}

// Check if Receptionist
if (RoleBasedAccess.IsReceptionist())
{
    lblMessage.Text = "Receptionist access granted";
}

// Check if patient
if (RoleBasedAccess.IsPatientRole())
{
    lblMessage.Text = "Patient access only";
}

// Check custom role
if (RoleBasedAccess.HasRole("Therapist"))
{
    lblMessage.Text = "You are a therapist";
}

// Check multiple roles
if (RoleBasedAccess.HasRole("Doctor", "Receptionist"))
{
    lblMessage.Text = "You have staff access";
}
```

---

### 2. Control what users can see

```csharp
// Can current user view this patient's data?
int patientId = 123;

if (RoleBasedAccess.CanViewPatient(patientId))
{
    // Show patient data
    ShowPatientSummary(patientId);
}
else
{
    // Hide it
    lblError.Text = "You cannot access this patient";
}
```

---

### 3. Control sensitive operations

```csharp
// Can current user see clinical data?
if (RoleBasedAccess.CanViewClinicalData(patientId))
{
    // Show treatment notes, results, etc.
    ShowClinicalNotes(patientId);
}
else
{
    // Hide it (receptionists shouldn't see this)
    lblError.Text = "Clinical data is restricted";
}

// Can current user see financial data?
if (RoleBasedAccess.CanViewFinancial(patientId))
{
    // Show invoices
    ShowInvoices(patientId);
}

// Can current user manage accounts?
if (RoleBasedAccess.CanManagePatientAccounts())
{
    btnResetPassword.Enabled = true;
}
else
{
    btnResetPassword.Enabled = false;
}
```

---

### 4. Restrict pages to specific roles

**Option A: Using StaffPage (recommended)**

```csharp
// File: Portal/ManageStaff.aspx.cs
public partial class ManageStaff : StaffPage
{
    // Only Doctor/Admin can access this page
    protected override string[] RequiredRoles 
    { 
        get { return new[] { "Doctor", "Admin" }; }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        // This code only runs if user has one of the required roles
        // Otherwise they're redirected to login
    }
}
```

**Option B: Using AdminOnly property (for backwards compatibility)**

```csharp
public partial class ManageAccounts : StaffPage
{
    protected override bool AdminOnly { get { return true; } }
}
```

**Option C: Using RoleBasedAccess.RequireRole()**

```csharp
public partial class MyPage : BasePage
{
    protected override void OnInit(EventArgs e)
    {
        // Require one of these roles or redirect
        RoleBasedAccess.RequireRole(this, "Doctor", "Receptionist");
        base.OnInit(e);
    }
}
```

---

### 5. Show/hide UI elements based on role

```csharp
protected void Page_Load(object sender, EventArgs e)
{
    // Show management buttons only for doctors
    btnManageStaff.Visible = RoleBasedAccess.IsDoctor();

    // Show financial section only for receptionists and doctors
    pnlFinancial.Visible = RoleBasedAccess.CanViewFinancial(PatientId);

    // Show clinical notes only for doctors and therapists
    pnlClinicalNotes.Visible = RoleBasedAccess.CanViewClinicalData(PatientId);
}
```

---

### 6. Log access control decisions (audit trail)

```csharp
// When you want to track access
if (RoleBasedAccess.CanViewPatient(patientId))
{
    RoleBasedAccess.LogAccess("PatientData", "View", true);
    ShowPatientData(patientId);
}
else
{
    RoleBasedAccess.LogAccess("PatientData", "View", false);
}
```

---

## Implementation Examples

### Example 1: Patient Appointments Page

```csharp
// File: Patient/Appointments.aspx.cs
public partial class Appointments : PatientPage
{
    private int PatientId => Auth.Current?.PatientId ?? 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        // PatientPage already ensures they're a patient and have a valid PatientId
        // Load only their own appointments
        LoadAppointments(PatientId);
    }
}
```

---

### Example 2: Receptionist Appointment Manager

```csharp
// File: Portal/Appointments.aspx.cs
public partial class AppointmentManager : StaffPage
{
    protected override string[] RequiredRoles
    {
        get { return new[] { "Doctor", "Receptionist" }; }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        // Only doctors and receptionists can access

        // Doctors see all details
        if (RoleBasedAccess.IsDoctor())
        {
            LoadAllAppointments();
            btnModifyTreatment.Visible = true;
        }
        // Receptionists see bookings only
        else if (RoleBasedAccess.IsReceptionist())
        {
            LoadAppointmentsForBooking();
            btnModifyTreatment.Visible = false;
        }
    }
}
```

---

### Example 3: Staff Management (Doctor Only)

```csharp
// File: Portal/ManageStaff.aspx.cs
public partial class ManageStaff : StaffPage
{
    protected override string[] RequiredRoles
    {
        get { return new[] { "Doctor", "Admin" }; }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        // Only doctors can access this page
        LoadStaffList();
    }

    protected void btnAddStaff_Click(object sender, EventArgs e)
    {
        if (!RoleBasedAccess.CanManageStaff())
        {
            lblError.Text = "You don't have permission to manage staff";
            return;
        }

        // Add new staff member
    }
}
```

---

### Example 4: Patient History (Different Views by Role)

```csharp
// File: Portal/PatientHistory.aspx.cs
public partial class PatientHistory : StaffPage
{
    protected override string[] RequiredRoles
    {
        get { return new[] { "Doctor", "Therapist" }; }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        int patientId = QueryInt("patientId");

        // Check access
        if (!RoleBasedAccess.CanViewPatient(patientId))
        {
            lblError.Text = "You cannot access this patient";
            return;
        }

        // Show patient name and basic info (everyone sees this)
        ShowPatientBasicInfo(patientId);

        // Show clinical notes only if allowed
        if (RoleBasedAccess.CanViewClinicalData(patientId))
        {
            pnlClinicalNotes.Visible = true;
            LoadClinicalNotes(patientId);
        }

        // Show financial info only if allowed
        if (RoleBasedAccess.CanViewFinancial(patientId))
        {
            pnlFinancial.Visible = true;
            LoadFinancialHistory(patientId);
        }
    }
}
```

---

## Web.config Configuration (Optional)

You can optionally define roles in Web.config for easier management:

```xml
<configuration>
  <appSettings>
    <!-- Role definitions -->
    <add key="Roles:DoctorRole" value="Doctor" />
    <add key="Roles:ReceptionistRole" value="Receptionist" />
    <add key="Roles:TherapistRole" value="Therapist" />
    <add key="Roles:AdminRoles" value="Doctor,Admin,Administrator,Manager" />

    <!-- What each role can access -->
    <add key="Roles:PatientRole" value="Patient" />
    <add key="Roles:StaffRoles" value="Doctor,Receptionist,Therapist,Admin" />

    <!-- Permissions -->
    <add key="Permissions:CanReceptionist_ViewClinical" value="false" />
    <add key="Permissions:CanTherapist_ViewFinancial" value="false" />
  </appSettings>
</configuration>
```

---

## Database Queries for Role-Based Filtering

### Get all patients (Staff access)

```sql
-- Doctors and receptionists can see all patients
SELECT p.Patient_ID, p.First_Name, p.Last_Name, p.Email
FROM Patient p
WHERE p.Is_Active = 1
ORDER BY p.First_Name, p.Last_Name
```

### Get appointments visible to staff

```sql
-- Different staff see different appointment details based on role
SELECT 
    a.Appointment_ID,
    a.Patient_ID,
    p.First_Name + ' ' + p.Last_Name AS PatientName,
    a.Appointment_Date,
    a.Status
FROM Appointment a
INNER JOIN Patient p ON a.Patient_ID = p.Patient_ID
WHERE a.Status != 'Cancelled'
ORDER BY a.Appointment_Date

-- For receptionists: hide clinical details
-- For therapists: show only their appointments
-- For doctors: show all with full details
```

### Get patient's own data (Patient access)

```sql
-- Patients see only their own data
SELECT *
FROM Patient
WHERE Patient_ID = @currentPatientId

SELECT *
FROM Appointment
WHERE Patient_ID = @currentPatientId

SELECT *
FROM Invoice
WHERE Patient_ID = @currentPatientId
```

---

## Security Checklist

- [ ] All credential columns removed from Patient and Staff tables
- [ ] All credentials now ONLY in UserAccount table
- [ ] UserAccount.Role column populated for all users
- [ ] StaffPage requires users to be logged in staff
- [ ] PatientPage requires users to be patients with valid PatientId
- [ ] Sensitive pages use RequiredRoles to restrict access
- [ ] All patient queries include `WHERE PatientId = currentPatientId` for patients
- [ ] All queries that select patients include role-based filtering
- [ ] Clinical data hidden from receptionists
- [ ] Financial data hidden from therapists
- [ ] Staff management only accessible to doctors
- [ ] Access denials logged to audit trail
- [ ] No role information in client-side JavaScript (server-side check required)
- [ ] All database queries respect roles

---

## Common Mistakes to Avoid

### ? Wrong: Checking role in UI only
```csharp
// BAD: User can delete btnDelete.Visible = false from browser console
btnDelete.Visible = RoleBasedAccess.IsDoctor();
```

### ? Right: Checking role server-side too
```csharp
// GOOD: Even if button is visible, server-side check prevents action
protected void btnDelete_Click(object sender, EventArgs e)
{
    if (!RoleBasedAccess.IsDoctor())
        throw new InvalidOperationException("Unauthorized");

    DeleteRecord();
}
```

### ? Wrong: Showing all data and filtering client-side
```csharp
// BAD: All data goes to browser, then filtered
var allPatients = GetAllPatients(); // Includes sensitive data!
gridPatients.DataSource = allPatients.Where(p => p.PatientId == currentId);
```

### ? Right: Filter at database level
```csharp
// GOOD: Only appropriate data retrieved
var patients = GetPatients(currentPatientId, currentUserRole);
```

### ? Wrong: Trusting user input for role checking
```csharp
// BAD: User could fake their role
string userRole = Request.QueryString["role"];
```

### ? Right: Get role from authenticated identity
```csharp
// GOOD: Role comes from secure session/cookie
string userRole = Auth.Current?.DbRole;
```

---

## Testing Your RBAC Implementation

### Test Case 1: Patient Access
```
1. Login as a patient
2. Try to access /Portal/Dashboard.aspx -> Should redirect to login
3. Access /Patient/Dashboard.aspx -> Should work
4. Try to view another patient's data -> Should fail
5. View own data -> Should work
```

### Test Case 2: Receptionist Access
```
1. Login as receptionist
2. Access /Portal/Dashboard.aspx -> Should work
3. Try to manage staff -> Should fail or show limited UI
4. Try to view clinical notes -> Should fail
5. Manage appointments -> Should work
6. Activate patient accounts -> Should work
```

### Test Case 3: Doctor Access
```
1. Login as doctor
2. Access /Portal/Dashboard.aspx -> Should work
3. Manage staff -> Should work
4. View clinical notes -> Should work
5. View financial data -> Should work
6. Access everything -> Should work
```

### Test Case 4: Session/Cookie Security
```
1. Login as patient
2. Open browser console
3. Try to modify auth cookie -> Should not work (encrypted)
4. Try to add "Doctor" role manually -> Should not work
5. Logout -> Cookie destroyed
```

---

## Summary

**Before (Mixed Architecture):**
- Credentials in multiple tables (Patient, Staff)
- Hard to control who can see passwords
- Hard to implement roles

**After (Unified + Role-Based):**
- Credentials ONLY in UserAccount table
- Clear separation of concerns
- Role-based access control from Auth.Current
- Easy to implement complex permissions
- Audit trail of who accessed what
- GDPR compliant (easy to purge credentials)
- Maximum security

**Key Files:**
- `Security/Auth.cs` - Identity and role parsing
- `Helpers/RoleBasedAccess.cs` - Role checking and permissions
- `Helpers/StaffPageRolesBased.cs` - Page-level access control
- `Helpers/BasePage.cs` - Base for all pages
- `Database/10_Finalize_Credentials_To_UserAccount_Only.sql` - Cleanup script

**Next Steps:**
1. Run cleanup SQL script
2. Test thoroughly with different roles
3. Update pages to use RoleBasedAccess
4. Monitor audit logs
5. Deploy to production
