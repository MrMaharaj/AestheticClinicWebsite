# Testing Checklist - Unified UserAccount Architecture

## Pre-Testing Verification

Run this SQL to confirm the migration is complete:

```sql
USE GroupWst6;
GO

-- Should show credentials are now in UserAccount
SELECT 'Credentials in UserAccount:' AS [Status];
SELECT AccountType, COUNT(*) AS Count FROM UserAccount GROUP BY AccountType;

-- Should show how many are still in Patient (should match above patient count)
SELECT 'Credentials still in Patient table (will be removed after testing):' AS [Status];
SELECT COUNT(*) FROM Patient WHERE [Password] IS NOT NULL;
```

---

## Testing Scenarios

### 1. PATIENT LOGIN ?/?

**Test: Register a new patient**
- [ ] Navigate to `/Account/Register.aspx`
- [ ] Fill in registration form with:
  - Name: "Test Patient 1"
  - ID Number: "99999999" (unique)
  - Email: "testpat1@example.com" (unique)
  - Phone, Address, etc.
  - Password: Create strong password
  - Security question & answer
- [ ] Click Register
- [ ] Expected: Patient record created + UserAccount record created
- [ ] Verify: Email is in UserAccount table (not Patient table)

**Test: Login as new patient**
- [ ] Go to `/Account/Login.aspx`
- [ ] Login with: `testpat1@example.com` / password from registration
- [ ] Expected: Login succeeds, redirects to patient dashboard
- [ ] Check: Auth.Current.Kind == AccountKind.Patient

**Test: First-time password change**
- [ ] At first login, should be redirected to `/Account/ChangePassword.aspx?first=1`
- [ ] Patient must create their own strong password
- [ ] Expected: Is_First_Login flag cleared in UserAccount table

**Test: Forgot Password**
- [ ] Login out
- [ ] Click "Forgot Password" on login page
- [ ] Enter patient email
- [ ] Expected: Should display security question from UserAccount
- [ ] Answer security question
- [ ] Expected: Can reset password, new password stored in UserAccount

---

### 2. DOCTOR/STAFF LOGIN ?/?

**Test: Login as existing doctor/staff**
- [ ] Go to `/Account/Login.aspx`
- [ ] Login with existing staff email/password
- [ ] Expected: Should find credentials either in:
  - [ ] UserAccount table (if migrated), OR
  - [ ] Staff table (legacy fallback)
- [ ] Expected: Login succeeds, redirects to portal
- [ ] Check: Auth.Current.Kind == AccountKind.Staff
- [ ] Check: Auth.IsStaff == true
- [ ] Check: Auth.IsAdmin == (correct for this staff member)

**Test: Access staff portal**
- [ ] Should be able to access `/Portal/` pages
- [ ] Should see staff-only content

**Test: Access admin functions (if admin)**
- [ ] If logged in as admin staff:
  - [ ] Can access `/Portal/ManageAccounts.aspx` ? (this was broken, now fixed)
  - [ ] Can add new staff member
  - [ ] Can edit staff member
  - [ ] Can activate/deactivate staff account
  - [ ] Can reset staff password
  - [ ] Can view and manage patient accounts
  - [ ] Can activate/deactivate patient online accounts
  - [ ] Can issue temporary password to patient

---

### 3. MANAGE ACCOUNTS (ADMIN ONLY) ?/?

**Test: View patient accounts list**
- [ ] Login as admin doctor/staff
- [ ] Go to `/Portal/ManageAccounts.aspx`
- [ ] Expected: List of patients with online account status
- [ ] Verify columns shown:
  - [ ] Patient ID
  - [ ] Name
  - [ ] Email (login)
  - [ ] Contact
  - [ ] Online account status (Active, Deactivated, Awaiting first login, No online account)
- [ ] Filter by status:
  - [ ] "All patients" - shows all
  - [ ] "Active" - shows only active
  - [ ] "Awaiting first login" - shows patients with temp password
  - [ ] "Deactivated" - shows deactivated accounts
  - [ ] "No online account" - shows patients without login

**Test: Issue temporary password to patient**
- [ ] Click "Create login" or "Reset password" on a patient
- [ ] Expected: Temporary password generated and displayed
- [ ] Expected: Patient can now log in with temp password
- [ ] Expected: Is_First_Login flag set to 1 (must change password)

**Test: Activate patient account**
- [ ] Find a deactivated patient account
- [ ] Click "Activate"
- [ ] Expected: Account activated, patient can login
- [ ] Verify: Is_Account_Active = 1 in UserAccount

**Test: Deactivate patient account**
- [ ] Find an active patient account
- [ ] Click "Deactivate"
- [ ] Expected: Cannot login, shows error message
- [ ] Verify: Is_Account_Active = 0 in UserAccount

**Test: Search/filter patients**
- [ ] Search by name, email, or patient ID
- [ ] Expected: Results filtered correctly

---

### 4. STAFF ACCOUNTS (ADMIN ONLY) ?/?

**Test: View staff list**
- [ ] In Manage Accounts, scroll to "Staff accounts" section
- [ ] Should list all staff with:
  - [ ] Staff ID
  - [ ] Name
  - [ ] Email (login)
  - [ ] Role (Doctor, Receptionist, etc.)
  - [ ] Status (Active/Inactive)
  - [ ] Temp password indicator (if Is_First_Login = 1)

**Test: Add new staff member**
- [ ] Click "+ Add staff member"
- [ ] Fill in:
  - [ ] First Name: "Test"
  - [ ] Last Name: "Staff"
  - [ ] Email: "teststaff@example.com" (unique)
  - [ ] Role: "Receptionist"
- [ ] Click Save
- [ ] Expected: Staff record created in Staff table
- [ ] Expected: UserAccount record created with:
  - [ ] AccountType = 'Staff'
  - [ ] Staff_ID = new staff ID
  - [ ] Email = provided email
  - [ ] Temporary password generated
  - [ ] Is_First_Login = 1

**Test: Edit staff member**
- [ ] Click "Edit" on a staff member
- [ ] Change name/email/role
- [ ] Click Save
- [ ] Expected: Staff table updated
- [ ] Expected: UserAccount table updated

**Test: Reset staff password**
- [ ] Click "Reset password" on a staff member
- [ ] Expected: New temporary password generated
- [ ] Expected: Is_First_Login = 1 in UserAccount
- [ ] New staff must change password at next login

**Test: Deactivate/Activate staff account**
- [ ] Click "Deactivate" or "Activate" on staff member
- [ ] Expected: Is_Active flag toggled in UserAccount
- [ ] Expected: Staff cannot login if deactivated

**Test: Staff login with new credentials**
- [ ] Logout if logged in
- [ ] Login as new staff member: teststaff@example.com / temp password
- [ ] Expected: Must change password first
- [ ] Change to new strong password
- [ ] Expected: Is_First_Login = 0 in UserAccount
- [ ] Can now access portal

---

### 5. PATIENT REGISTRATION FLOW ?/?

**Test: Register existing patient (link to FES record)**
- [ ] Have a patient record in Patient table with ID_Number
- [ ] Register with same ID_Number in Register.aspx
- [ ] Expected: Links to existing patient record
- [ ] Expected: UserAccount record created for that patient
- [ ] Expected: Email verified or updated

**Test: Register completely new patient**
- [ ] Register with new ID_Number
- [ ] Expected: New Patient record created
- [ ] Expected: New UserAccount record created
- [ ] Expected: Is_First_Login = 0 (or per AutoApprovePatients setting)

---

### 6. ERROR HANDLING ?/?

**Test: Invalid email format**
- [ ] Try to register with invalid email
- [ ] Expected: Error message displayed

**Test: Duplicate email**
- [ ] Try to register with email already in use
- [ ] Expected: Error message: "Email already in use"

**Test: Duplicate ID number (existing patient)**
- [ ] Try to register with ID number of existing patient
- [ ] But with different email/phone
- [ ] Expected: Error message: "Patient record exists but email/phone don't match"

**Test: Database connection error**
- [ ] Temporarily disconnect from database
- [ ] Try to login
- [ ] Expected: Friendly error message (not SQL error)

---

## Sign-Off

Once all tests pass:

- [ ] Patient login works ?
- [ ] Patient registration works ?
- [ ] Patient password change works ?
- [ ] Patient forgot password works ?
- [ ] Doctor/Staff login works ?
- [ ] Admin can manage patient accounts ?
- [ ] Admin can manage staff accounts ?
- [ ] Error handling is graceful ?
- [ ] All roles can access appropriate pages ?

**Date Tested:** _______________

**Tested By:** _______________

**Ready for Cleanup:** ? YES ? NO

---

## After Testing (1-2 weeks)

Once confident everything works, run cleanup script:

```sql
USE GroupWst6;
GO
-- Run: 08_Cleanup_Old_Credentials.sql
-- This removes credential columns from Patient table
```

This is safe because:
- All credentials are now in UserAccount
- Application code only reads from UserAccount
- Patient table becomes pure data storage
- Audit trail is cleaner (credentials separate from patient data)
