## ? SQL Script Fixed

### Error Found
```
Msg 209, Level 16, State 1, Line 123
Ambiguous column name 'Staff_ID'
Ambiguous column name 'First_Name'
Ambiguous column name 'Last_Name'
```

### Root Cause
The SELECT statement in the verification section didn't use table aliases for the columns, causing ambiguity when joining Staff and UserAccount tables.

### What Was Fixed

**File:** `01_REMOVE_CREDENTIALS_FROM_PATIENT_STAFF.sql`

**Before:**
```sql
SELECT '  ? Staff_ID: ' + CAST(Staff_ID AS VARCHAR(10)) + ' (' + First_Name + ' ' + Last_Name + ')'
FROM Staff s
LEFT JOIN UserAccount ua ...
```

**After:**
```sql
SELECT '  ? Staff_ID: ' + CAST(s.Staff_ID AS VARCHAR(10)) + ' (' + s.First_Name + ' ' + s.Last_Name + ')'
FROM Staff s
LEFT JOIN UserAccount ua ...
```

? Added table alias `s.` to all column references

### Additional Fix
Also added `Role` to the list of columns to remove from Staff table (was missing before).

### Try Again
Now run the script again in SSMS:
1. Open `Database/01_REMOVE_CREDENTIALS_FROM_PATIENT_STAFF.sql`
2. Execute it
3. Should complete successfully! ?
