# ? QUICK FIX - Run These 2 SQL Scripts

## Your Issues:
1. ? "Database is missing the patient login columns" error
2. ? Staff list not showing in Portal

## The Fix:

### Step 1: Run 2 SQL Scripts
In SQL Server Management Studio, connect to `GroupWst6` and run:

1. **`Database/01_REMOVE_CREDENTIALS_FROM_PATIENT_STAFF.sql`**
   - Removes credentials from Patient table

2. **`Database/02_FIX_STAFF_TABLE_STRUCTURE.sql`**
   - Fixes Staff table structure
   - Removes credentials from Staff table
   - Removes Role from Staff table

### Step 2: Rebuild App
```
Visual Studio ? Build ? Rebuild Solution
```

### Step 3: Test
- Log in as staff
- Go to Portal ? Manage Staff
- ? Staff list should show
- ? No database errors

---

## What Was Fixed in Code
? AddStaff() - No longer tries to insert credentials in Staff table
? Staff() query - Now reads Role from UserAccount (not Staff table)
? UpdateStaff() - Updates staff info in Staff table, credentials in UserAccount

---

**Full Details:** See `FIX_DATABASE_AND_STAFF_LIST.md`
