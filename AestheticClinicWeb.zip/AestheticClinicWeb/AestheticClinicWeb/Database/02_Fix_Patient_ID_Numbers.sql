/* =====================================================================
   STEP 2 - Replace invalid SA ID numbers with valid ones.
   Rebuilds ONLY IDs that fail the website's rules (13 digits, YYMMDD = Date_Of_Birth, gender digits
   0000-4999 = F / 5000-9999 = M matching Gender, Luhn check digit). Valid IDs are not touched.
   New ID = YYMMDD from Date_Of_Birth + SSSS (F: 0000+Patient_ID, M: 5000+Patient_ID, mod 5000)
            + 0 (citizen) + 8 + Luhn check digit.  Unique because Patient_ID is unique.

   HOW TO RUN:  1) Run as-is (@Apply = 0): PREVIEW only, nothing changes.
                2) Check the list, then set @Apply = 1 and run again.
   Verified: every new ID for the current 15 patients passes the website validator (Check.SaId).
   ===================================================================== */
USE [GroupWst6];
SET NOCOUNT ON;
DECLARE @Apply BIT = 0;          -- <<< change to 1 to apply

IF OBJECT_ID('tempdb..#fix') IS NOT NULL DROP TABLE #fix;
IF OBJECT_ID('tempdb..#luhn') IS NOT NULL DROP TABLE #luhn;

WITH n AS (SELECT v FROM (VALUES (1),(2),(3),(4),(5),(6),(7),(8),(9),(10),(11),(12),(13)) t(v))
SELECT Patient_ID, First_Name, Last_Name, Gender, Date_Of_Birth, ID_Number,
       Base = CONVERT(CHAR(6), Date_Of_Birth, 12)
              + RIGHT('0000' + CAST(CASE WHEN Gender = 'F' THEN 0 ELSE 5000 END + Patient_ID % 5000 AS VARCHAR(4)), 4)
              + '08'
INTO #luhn
FROM dbo.Patient p
WHERE NOT (LEN(ID_Number) = 13 AND ID_Number NOT LIKE '%[^0-9]%'
           AND LEFT(ID_Number, 6) = CONVERT(CHAR(6), Date_Of_Birth, 12)
           AND ((TRY_CAST(SUBSTRING(ID_Number, 7, 4) AS INT) >= 5000 AND Gender = 'M')
             OR (TRY_CAST(SUBSTRING(ID_Number, 7, 4) AS INT) <  5000 AND Gender = 'F')));

SELECT l.Patient_ID, l.First_Name, l.Last_Name, l.Gender, l.Date_Of_Birth, l.ID_Number AS Old_ID_Number,
       New_ID_Number = l.Base + CAST((10 - (SELECT SUM(CASE WHEN n.v % 2 = 0
                                                            THEN 2 * CAST(SUBSTRING(l.Base, n.v, 1) AS INT)
                                                                 - CASE WHEN 2 * CAST(SUBSTRING(l.Base, n.v, 1) AS INT) > 9 THEN 9 ELSE 0 END
                                                            ELSE CAST(SUBSTRING(l.Base, n.v, 1) AS INT) END)
                                            FROM n WHERE n.v <= 12) % 10) % 10 AS CHAR(1)),
       Warning = CASE WHEN l.Date_Of_Birth > CAST(GETDATE() AS DATE) THEN 'DOB is in the future - correct the DOB in the FES, then re-run'
                      WHEN l.Date_Of_Birth > DATEADD(YEAR, -16, CAST(GETDATE() AS DATE)) THEN 'Patient under 16 - check DOB'
                      ELSE '' END
INTO #fix
FROM #luhn l
CROSS JOIN (SELECT v FROM (VALUES (1),(2),(3),(4),(5),(6),(7),(8),(9),(10),(11),(12),(13)) t(v)) n
WHERE n.v <= 1;
DROP TABLE #luhn;

SELECT * FROM #fix ORDER BY Patient_ID;      -- preview

-- safety: a new ID must not clash with another patient's ID
IF EXISTS (SELECT 1 FROM #fix f JOIN dbo.Patient p ON p.ID_Number = f.New_ID_Number AND p.Patient_ID <> f.Patient_ID)
BEGIN
    RAISERROR('A generated ID clashes with an existing patient. Nothing was changed.', 16, 1);
    RETURN;
END

IF @Apply = 1
BEGIN
    BEGIN TRAN;
    UPDATE p SET p.ID_Number = f.New_ID_Number
    FROM dbo.Patient p JOIN #fix f ON f.Patient_ID = p.Patient_ID;
    PRINT CAST(@@ROWCOUNT AS VARCHAR(10)) + ' ID number(s) updated.';
    COMMIT;
END
ELSE PRINT 'PREVIEW ONLY - set @Apply = 1 to update.';
