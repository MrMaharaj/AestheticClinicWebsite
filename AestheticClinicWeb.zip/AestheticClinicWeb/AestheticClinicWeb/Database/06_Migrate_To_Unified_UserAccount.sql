/* =====================================================================
   SECURITY MIGRATION - Adapt existing UserAccount table for unified credentials

   IMPORTANT: This script adapts your EXISTING UserAccount table (which currently 
   stores doctor sign-up requests) to also store all login credentials (staff + patient).

   Your current UserAccount table has:
     - User_ID, Patient_ID, Email, Password, Role
     - Account_Status, Security_Question, Security_Answer, Is_First_Login
     - First_Name, Last_Name (from doctor sign-up)

   This script adds missing columns to make it work with the new architecture:
     - AccountType (distinguishes 'Patient' from 'Staff')
     - Staff_ID (for staff credentials)
     - Is_Active, Is_Account_Active (better status management)
     - Created_Date, Modified_Date (audit trail)

   SAFE TO RE-RUN: Script checks for existing columns before adding
   NO DATA LOSS: Your existing doctor sign-up records and data are preserved
   ===================================================================== */

USE [GroupWst6];
GO

PRINT 'Starting UserAccount table migration...';
PRINT 'Your existing UserAccount table will be enhanced, not replaced.';
GO

-- Step 1: Add missing columns to existing UserAccount table
-- These columns are needed for the new unified credential architecture

IF COL_LENGTH('dbo.UserAccount', 'AccountType') IS NULL
BEGIN
    ALTER TABLE dbo.UserAccount ADD AccountType VARCHAR(20) NULL;
    PRINT 'Added AccountType column';
END

IF COL_LENGTH('dbo.UserAccount', 'Staff_ID') IS NULL
BEGIN
    ALTER TABLE dbo.UserAccount ADD Staff_ID INT NULL;
    PRINT 'Added Staff_ID column';
END

IF COL_LENGTH('dbo.UserAccount', 'Is_Active') IS NULL
BEGIN
    ALTER TABLE dbo.UserAccount ADD Is_Active BIT NOT NULL DEFAULT 1;
    PRINT 'Added Is_Active column (default: 1 = active)';
END

IF COL_LENGTH('dbo.UserAccount', 'Is_Account_Active') IS NULL
BEGIN
    ALTER TABLE dbo.UserAccount ADD Is_Account_Active BIT NOT NULL DEFAULT 1;
    PRINT 'Added Is_Account_Active column (default: 1 = can login)';
END

IF COL_LENGTH('dbo.UserAccount', 'Created_Date') IS NULL
BEGIN
    ALTER TABLE dbo.UserAccount ADD Created_Date DATETIME NOT NULL DEFAULT GETDATE();
    PRINT 'Added Created_Date column';
END

IF COL_LENGTH('dbo.UserAccount', 'Modified_Date') IS NULL
BEGIN
    ALTER TABLE dbo.UserAccount ADD Modified_Date DATETIME NOT NULL DEFAULT GETDATE();
    PRINT 'Added Modified_Date column';
END

GO

-- Step 2: Set AccountType for existing records
-- Existing UserAccount records (doctor sign-ups) default to 'Patient' if they have Patient_ID
-- Records without Patient_ID are left as NULL (will be updated when new code runs)

BEGIN TRAN;
BEGIN TRY
    UPDATE dbo.UserAccount 
    SET AccountType = CASE 
                        WHEN Patient_ID IS NOT NULL THEN 'Patient'
                        ELSE NULL  -- Will be set by application code if needed
                      END,
        Is_Active = 1,
        Is_Account_Active = CASE 
                              WHEN Account_Status = 'Confirmed' THEN 1
                              ELSE 0
                            END
    WHERE AccountType IS NULL;

    PRINT CAST(@@ROWCOUNT AS VARCHAR(10)) + ' existing UserAccount record(s) updated with AccountType.';
    COMMIT;
END TRY
BEGIN CATCH
    ROLLBACK;
    DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
    RAISERROR (@ErrorMessage, 16, 1);
END CATCH
GO

-- Step 3: Add Foreign Key constraint for Staff_ID (if it doesn't exist)
IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS 
              WHERE CONSTRAINT_NAME = 'FK_UserAccount_Staff')
BEGIN
    ALTER TABLE dbo.UserAccount 
    ADD CONSTRAINT FK_UserAccount_Staff 
    FOREIGN KEY (Staff_ID) REFERENCES dbo.Staff(Staff_ID);
    PRINT 'Added Staff_ID foreign key constraint';
END
GO

-- Step 4: Migrate patient credentials from Patient table
-- Only migrate patients who have online accounts (Password IS NOT NULL)
-- and don't already exist in UserAccount

BEGIN TRAN;
BEGIN TRY
    DECLARE @MigratedCount INT = 0;

    INSERT INTO dbo.UserAccount (Patient_ID, Email, [Password], [Role], AccountType, 
                                 Account_Status, Security_Question, Security_Answer, 
                                 Is_First_Login, Is_Active, Is_Account_Active, Created_Date)
    SELECT 
        p.Patient_ID,
        LTRIM(RTRIM(p.Email)) AS Email,
        p.[Password],
        'Patient' AS [Role],
        'Patient' AS AccountType,
        'Confirmed' AS Account_Status,
        ISNULL(p.Security_Question, 'Not Set') AS Security_Question,
        ISNULL(p.Security_Answer, 'Not Set') AS Security_Answer,
        ISNULL(p.Is_First_Login, 0) AS Is_First_Login,
        p.Is_Active,
        ISNULL(p.Is_Account_Active, 1) AS Is_Account_Active,
        GETDATE() AS Created_Date
    FROM dbo.Patient p
    WHERE p.[Password] IS NOT NULL
      AND NOT EXISTS (SELECT 1 FROM dbo.UserAccount ua 
                      WHERE ua.Patient_ID = p.Patient_ID 
                        AND ua.Email = LTRIM(RTRIM(p.Email)));

    SET @MigratedCount = @@ROWCOUNT;

    IF @MigratedCount > 0
    BEGIN
        PRINT CAST(@MigratedCount AS VARCHAR(10)) + ' patient credential(s) migrated from Patient table to UserAccount.';
        COMMIT;
    END
    ELSE
    BEGIN
        PRINT 'No new patient credentials to migrate (all already in UserAccount or no passwords set).';
        COMMIT;
    END
END TRY
BEGIN CATCH
    ROLLBACK;
    DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
    RAISERROR (@ErrorMessage, 16, 1);
END CATCH
GO

-- Step 5: Verify the migration
PRINT '';
PRINT '===============================================================';
PRINT 'MIGRATION VERIFICATION';
PRINT '===============================================================';
GO

SELECT 'Current UserAccount Table Structure:' AS [Status];
GO

SELECT 
    COLUMN_NAME, 
    DATA_TYPE, 
    IS_NULLABLE,
    COLUMN_DEFAULT
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'UserAccount'
ORDER BY ORDINAL_POSITION;
GO

SELECT 'Total UserAccount Records:' AS [Status];
SELECT 'Total Count' = COUNT(*) FROM dbo.UserAccount;
GO

SELECT 'Records by AccountType:' AS [Status];
SELECT 
    AccountType, 
    COUNT(*) AS RecordCount
FROM dbo.UserAccount
GROUP BY AccountType;
GO

SELECT 'Patient credentials still in Patient table (will be removed after testing):' AS [Status];
SELECT 
    Patient_ID, 
    First_Name, 
    Last_Name, 
    Email, 
    'Has Password' = CASE WHEN [Password] IS NOT NULL THEN 'Yes' ELSE 'No' END
FROM dbo.Patient 
WHERE [Password] IS NOT NULL
ORDER BY Patient_ID;
GO

PRINT '';
PRINT '===============================================================';
PRINT 'MIGRATION COMPLETE - NEXT STEPS';
PRINT '===============================================================';
PRINT '1. Review the verification output above to ensure data looks correct';
PRINT '2. Deploy AccountRepository_Secure.cs (replaces AccountRepository.cs)';
PRINT '3. Test thoroughly:';
PRINT '   - Patient login';
PRINT '   - Patient registration';
PRINT '   - Password reset';
PRINT '   - Staff login (should still work)';
PRINT '4. After 1-2 weeks of successful operation, run 08_Cleanup_Old_Credentials.sql';
PRINT '   to remove the old Password columns from Patient table';
PRINT '===============================================================';
GO
