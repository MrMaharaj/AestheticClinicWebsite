/*
   =====================================================================
   DIAGNOSTIC & REPAIR - Why Credentials Weren't Removed

   This script will:
   1. Show current column state
   2. Check for foreign key constraints
   3. Show any errors from previous cleanup attempts
   4. Provide a clean removal process
   ===================================================================== */

USE [GroupWst6];
GO

PRINT '=================================================================';
PRINT 'DIAGNOSTIC: Checking why cleanup script didnt work';
PRINT '=================================================================';
PRINT '';

-- ====================================================================
-- Step 1: Show what columns currently exist
-- ====================================================================

PRINT 'STEP 1: Current Patient Table Columns';
PRINT '????????????????????????????????????';
SELECT 
    COLUMN_NAME, 
    DATA_TYPE, 
    IS_NULLABLE,
    COLUMNPROPERTY(OBJECT_ID('dbo.Patient'), COLUMN_NAME, 'ColumnId') AS ColumnID
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'Patient'
ORDER BY ORDINAL_POSITION
GO

PRINT '';
PRINT 'STEP 2: Current Staff Table Columns';
PRINT '????????????????????????????????????';
SELECT 
    COLUMN_NAME, 
    DATA_TYPE, 
    IS_NULLABLE,
    COLUMNPROPERTY(OBJECT_ID('dbo.Staff'), COLUMN_NAME, 'ColumnId') AS ColumnID
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'Staff'
ORDER BY ORDINAL_POSITION
GO

-- ====================================================================
-- Step 2: Check for foreign keys and indexes that might block deletion
-- ====================================================================

PRINT '';
PRINT 'STEP 3: Check for constraints on Patient table credential columns';
PRINT '????????????????????????????????????????????????????????????????';
SELECT 
    CONSTRAINT_NAME,
    CONSTRAINT_TYPE,
    TABLE_NAME,
    COLUMN_NAME
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE TABLE_NAME = 'Patient'
  AND COLUMN_NAME IN ('Password', 'Is_First_Login', 'Is_Account_Active', 'Security_Question', 'Security_Answer', 'Account_Status')
GO

PRINT '';
PRINT 'STEP 4: Check for indexes on Patient table credential columns';
PRINT '????????????????????????????????????????????????????????????????';
SELECT 
    i.name AS IndexName,
    ic.name AS ColumnName,
    i.is_primary_key,
    i.is_unique,
    i.type_desc
FROM sys.indexes i
INNER JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
WHERE i.object_id = OBJECT_ID('dbo.Patient')
  AND ic.name IN ('Password', 'Is_First_Login', 'Is_Account_Active', 'Security_Question', 'Security_Answer', 'Account_Status')
GO

-- ====================================================================
-- Step 3: Check data integrity
-- ====================================================================

PRINT '';
PRINT 'STEP 5: Patient table credential data status';
PRINT '????????????????????????????????????????????';
SELECT 
    'Patient Table' AS [Table],
    COUNT(*) AS [Total Records],
    COUNT(CASE WHEN COL_LENGTH('dbo.Patient', 'Password') > 0 AND [Password] IS NOT NULL THEN 1 END) AS [Records with Password],
    COUNT(CASE WHEN COL_LENGTH('dbo.Patient', 'Is_First_Login') > 0 AND Is_First_Login = 1 THEN 1 END) AS [First Login=True]
FROM dbo.Patient
GO

PRINT '';
PRINT 'STEP 6: Staff table credential data status';
PRINT '?????????????????????????????????????????';
SELECT 
    'Staff Table' AS [Table],
    COUNT(*) AS [Total Records],
    COUNT(CASE WHEN COL_LENGTH('dbo.Staff', 'Password') > 0 AND [Password] IS NOT NULL THEN 1 END) AS [Records with Password],
    COUNT(CASE WHEN COL_LENGTH('dbo.Staff', 'Is_First_Login') > 0 AND Is_First_Login = 1 THEN 1 END) AS [First Login=True]
FROM dbo.Staff
GO

-- ====================================================================
-- Step 4: Verify UserAccount has all data
-- ====================================================================

PRINT '';
PRINT 'STEP 7: UserAccount table - verify all credentials migrated';
PRINT '??????????????????????????????????????????????????????????';
SELECT 
    'UserAccount' AS [Table],
    COUNT(*) AS [Total Records],
    COUNT(CASE WHEN Email IS NOT NULL THEN 1 END) AS [With Email],
    COUNT(CASE WHEN [Password] IS NOT NULL THEN 1 END) AS [With Password],
    COUNT(CASE WHEN Role IS NOT NULL THEN 1 END) AS [With Role],
    COUNT(CASE WHEN AccountType = 'Patient' THEN 1 END) AS [Patient Records],
    COUNT(CASE WHEN AccountType = 'Staff' THEN 1 END) AS [Staff Records]
FROM dbo.UserAccount
GO

-- ====================================================================
-- Step 5: Show what WILL be deleted (if you proceed)
-- ====================================================================

PRINT '';
PRINT 'STEP 8: What WILL be deleted from Patient table';
PRINT '???????????????????????????????????????????????';
PRINT 'The following columns EXIST in Patient table and WILL be removed:';
PRINT '(If any show "1", they exist and can be safely removed)';
PRINT '';

SELECT 
    CASE WHEN COL_LENGTH('dbo.Patient', 'Password') IS NOT NULL THEN 1 ELSE 0 END AS [Password EXISTS],
    CASE WHEN COL_LENGTH('dbo.Patient', 'Is_First_Login') IS NOT NULL THEN 1 ELSE 0 END AS [Is_First_Login EXISTS],
    CASE WHEN COL_LENGTH('dbo.Patient', 'Is_Account_Active') IS NOT NULL THEN 1 ELSE 0 END AS [Is_Account_Active EXISTS],
    CASE WHEN COL_LENGTH('dbo.Patient', 'Security_Question') IS NOT NULL THEN 1 ELSE 0 END AS [Security_Question EXISTS],
    CASE WHEN COL_LENGTH('dbo.Patient', 'Security_Answer') IS NOT NULL THEN 1 ELSE 0 END AS [Security_Answer EXISTS],
    CASE WHEN COL_LENGTH('dbo.Patient', 'Account_Status') IS NOT NULL THEN 1 ELSE 0 END AS [Account_Status EXISTS]
GO

PRINT '';
PRINT 'STEP 9: What WILL be deleted from Staff table';
PRINT '??????????????????????????????????????????????';
PRINT 'The following columns EXIST in Staff table and WILL be removed:';
PRINT '(If any show "1", they exist and can be safely removed)';
PRINT '';

SELECT 
    CASE WHEN COL_LENGTH('dbo.Staff', 'Password') IS NOT NULL THEN 1 ELSE 0 END AS [Password EXISTS],
    CASE WHEN COL_LENGTH('dbo.Staff', 'Is_First_Login') IS NOT NULL THEN 1 ELSE 0 END AS [Is_First_Login EXISTS],
    CASE WHEN COL_LENGTH('dbo.Staff', 'Is_Account_Active') IS NOT NULL THEN 1 ELSE 0 END AS [Is_Account_Active EXISTS],
    CASE WHEN COL_LENGTH('dbo.Staff', 'Security_Question') IS NOT NULL THEN 1 ELSE 0 END AS [Security_Question EXISTS],
    CASE WHEN COL_LENGTH('dbo.Staff', 'Security_Answer') IS NOT NULL THEN 1 ELSE 0 END AS [Security_Answer EXISTS]
GO

PRINT '';
PRINT '=================================================================';
PRINT 'DIAGNOSTIC COMPLETE';
PRINT '=================================================================';
PRINT '';
PRINT 'Next Steps:';
PRINT '  1. Review the output above';
PRINT '  2. If columns still exist (show 1), run: 11_FORCE_Remove_Credentials.sql';
PRINT '  3. If columns already removed (show 0), cleanup was successful!';
PRINT '';
