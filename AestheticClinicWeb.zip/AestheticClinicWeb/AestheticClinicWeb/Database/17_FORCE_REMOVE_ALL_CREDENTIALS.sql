/*
   =====================================================================
   FORCE REMOVE ALL REMAINING CREDENTIAL COLUMNS

   This script will:
   1. Drop any blocking indexes
   2. Drop all remaining credential columns
   3. Verify they're removed

   Based on diagnostic: These columns still exist and need removal:
   Patient: Password, Is_First_Login, Is_Account_Active, Security_Question, Security_Answer
   Staff: Password, Is_First_Login, Security_Question, Security_Answer
   ===================================================================== */

USE [GroupWst6];
GO

PRINT '';
PRINT '====================================================================';
PRINT '               FORCE REMOVING CREDENTIAL COLUMNS';
PRINT '====================================================================';
PRINT '';

-- ====================================================================
-- STEP 1: Drop any indexes that might block column deletion
-- ====================================================================
PRINT 'STEP 1: Removing blocking indexes...';
PRINT '???????????????????????????????????';

DECLARE @sql NVARCHAR(MAX);

-- Drop indexes on Patient table credential columns
SELECT @sql = STRING_AGG('DROP INDEX [' + name + '] ON dbo.Patient;', ' ')
FROM sys.indexes i
INNER JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
WHERE OBJECT_NAME(i.object_id) = 'Patient'
  AND c.name IN ('Password', 'Is_First_Login', 'Is_Account_Active', 'Security_Question', 'Security_Answer')
  AND i.is_primary_key = 0
  AND i.is_unique_constraint = 0;

IF @sql IS NOT NULL
BEGIN
    EXEC sp_executesql @sql;
    PRINT '? Dropped Patient table indexes';
END
ELSE
BEGIN
    PRINT '? No Patient table indexes to drop';
END

-- Drop indexes on Staff table credential columns
SELECT @sql = STRING_AGG('DROP INDEX [' + name + '] ON dbo.Staff;', ' ')
FROM sys.indexes i
INNER JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
WHERE OBJECT_NAME(i.object_id) = 'Staff'
  AND c.name IN ('Password', 'Is_First_Login', 'Security_Question', 'Security_Answer')
  AND i.is_primary_key = 0
  AND i.is_unique_constraint = 0;

IF @sql IS NOT NULL
BEGIN
    EXEC sp_executesql @sql;
    PRINT '? Dropped Staff table indexes';
END
ELSE
BEGIN
    PRINT '? No Staff table indexes to drop';
END

-- ====================================================================
-- STEP 2: Drop columns from Patient table
-- ====================================================================
PRINT '';
PRINT 'STEP 2: Removing columns from Patient table...';
PRINT '??????????????????????????????????????????????';

BEGIN TRY
    IF COL_LENGTH('dbo.Patient', 'Password') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN [Password];
        PRINT '? Dropped Patient.Password';
    END
END TRY
BEGIN CATCH
    PRINT '? Error dropping Patient.Password: ' + ERROR_MESSAGE();
END CATCH

BEGIN TRY
    IF COL_LENGTH('dbo.Patient', 'Is_First_Login') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN [Is_First_Login];
        PRINT '? Dropped Patient.Is_First_Login';
    END
END TRY
BEGIN CATCH
    PRINT '? Error dropping Patient.Is_First_Login: ' + ERROR_MESSAGE();
END CATCH

BEGIN TRY
    IF COL_LENGTH('dbo.Patient', 'Is_Account_Active') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN [Is_Account_Active];
        PRINT '? Dropped Patient.Is_Account_Active';
    END
END TRY
BEGIN CATCH
    PRINT '? Error dropping Patient.Is_Account_Active: ' + ERROR_MESSAGE();
END CATCH

BEGIN TRY
    IF COL_LENGTH('dbo.Patient', 'Security_Question') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN [Security_Question];
        PRINT '? Dropped Patient.Security_Question';
    END
END TRY
BEGIN CATCH
    PRINT '? Error dropping Patient.Security_Question: ' + ERROR_MESSAGE();
END CATCH

BEGIN TRY
    IF COL_LENGTH('dbo.Patient', 'Security_Answer') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN [Security_Answer];
        PRINT '? Dropped Patient.Security_Answer';
    END
END TRY
BEGIN CATCH
    PRINT '? Error dropping Patient.Security_Answer: ' + ERROR_MESSAGE();
END CATCH

-- ====================================================================
-- STEP 3: Drop columns from Staff table
-- ====================================================================
PRINT '';
PRINT 'STEP 3: Removing columns from Staff table...';
PRINT '??????????????????????????????????????????';

BEGIN TRY
    IF COL_LENGTH('dbo.Staff', 'Password') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN [Password];
        PRINT '? Dropped Staff.Password';
    END
END TRY
BEGIN CATCH
    PRINT '? Error dropping Staff.Password: ' + ERROR_MESSAGE();
END CATCH

BEGIN TRY
    IF COL_LENGTH('dbo.Staff', 'Is_First_Login') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN [Is_First_Login];
        PRINT '? Dropped Staff.Is_First_Login';
    END
END TRY
BEGIN CATCH
    PRINT '? Error dropping Staff.Is_First_Login: ' + ERROR_MESSAGE();
END CATCH

BEGIN TRY
    IF COL_LENGTH('dbo.Staff', 'Security_Question') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN [Security_Question];
        PRINT '? Dropped Staff.Security_Question';
    END
END TRY
BEGIN CATCH
    PRINT '? Error dropping Staff.Security_Question: ' + ERROR_MESSAGE();
END CATCH

BEGIN TRY
    IF COL_LENGTH('dbo.Staff', 'Security_Answer') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN [Security_Answer];
        PRINT '? Dropped Staff.Security_Answer';
    END
END TRY
BEGIN CATCH
    PRINT '? Error dropping Staff.Security_Answer: ' + ERROR_MESSAGE();
END CATCH

-- ====================================================================
-- STEP 4: Verify removal
-- ====================================================================
PRINT '';
PRINT '====================================================================';
PRINT '                      VERIFICATION';
PRINT '====================================================================';
PRINT '';

PRINT 'PATIENT TABLE - Final Status:';
PRINT '?????????????????????????????';
SELECT 
    'Password' AS [Column],
    CASE WHEN COL_LENGTH('dbo.Patient', 'Password') IS NOT NULL THEN '??  STILL EXISTS' ELSE '? REMOVED' END AS [Status]
UNION ALL SELECT 'Is_First_Login', CASE WHEN COL_LENGTH('dbo.Patient', 'Is_First_Login') IS NOT NULL THEN '??  STILL EXISTS' ELSE '? REMOVED' END
UNION ALL SELECT 'Is_Account_Active', CASE WHEN COL_LENGTH('dbo.Patient', 'Is_Account_Active') IS NOT NULL THEN '??  STILL EXISTS' ELSE '? REMOVED' END
UNION ALL SELECT 'Security_Question', CASE WHEN COL_LENGTH('dbo.Patient', 'Security_Question') IS NOT NULL THEN '??  STILL EXISTS' ELSE '? REMOVED' END
UNION ALL SELECT 'Security_Answer', CASE WHEN COL_LENGTH('dbo.Patient', 'Security_Answer') IS NOT NULL THEN '??  STILL EXISTS' ELSE '? REMOVED' END;

PRINT '';
PRINT 'STAFF TABLE - Final Status:';
PRINT '???????????????????????????';
SELECT 
    'Password' AS [Column],
    CASE WHEN COL_LENGTH('dbo.Staff', 'Password') IS NOT NULL THEN '??  STILL EXISTS' ELSE '? REMOVED' END AS [Status]
UNION ALL SELECT 'Is_First_Login', CASE WHEN COL_LENGTH('dbo.Staff', 'Is_First_Login') IS NOT NULL THEN '??  STILL EXISTS' ELSE '? REMOVED' END
UNION ALL SELECT 'Security_Question', CASE WHEN COL_LENGTH('dbo.Staff', 'Security_Question') IS NOT NULL THEN '??  STILL EXISTS' ELSE '? REMOVED' END
UNION ALL SELECT 'Security_Answer', CASE WHEN COL_LENGTH('dbo.Staff', 'Security_Answer') IS NOT NULL THEN '??  STILL EXISTS' ELSE '? REMOVED' END;

PRINT '';
PRINT '====================================================================';
PRINT '                    OVERALL STATUS';
PRINT '====================================================================';
PRINT '';

IF COL_LENGTH('dbo.Patient', 'Password') IS NULL AND
   COL_LENGTH('dbo.Patient', 'Is_First_Login') IS NULL AND
   COL_LENGTH('dbo.Patient', 'Is_Account_Active') IS NULL AND
   COL_LENGTH('dbo.Patient', 'Security_Question') IS NULL AND
   COL_LENGTH('dbo.Patient', 'Security_Answer') IS NULL AND
   COL_LENGTH('dbo.Staff', 'Password') IS NULL AND
   COL_LENGTH('dbo.Staff', 'Is_First_Login') IS NULL AND
   COL_LENGTH('dbo.Staff', 'Security_Question') IS NULL AND
   COL_LENGTH('dbo.Staff', 'Security_Answer') IS NULL
BEGIN
    PRINT '? SUCCESS! All credential columns have been removed!';
    PRINT '';
    PRINT 'Next Steps:';
    PRINT '  1. Close SQL Server Management Studio completely';
    PRINT '  2. Re-open SQL Server Management Studio';
    PRINT '  3. Right-click Patient table ? Refresh';
    PRINT '  4. Right-click Staff table ? Refresh';
    PRINT '  5. Column list should now show updated schema ?';
END
ELSE
BEGIN
    PRINT '??  Some columns are still present. Check error messages above.';
END

PRINT '';
PRINT '====================================================================';
GO
