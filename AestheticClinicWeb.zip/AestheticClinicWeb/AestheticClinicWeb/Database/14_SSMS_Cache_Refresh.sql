/*
   =====================================================================
   SSMS CACHE REFRESH - Force refresh of table schema in Management Studio

   If columns visually still appear in SSMS but database says they're gone,
   run this to clear all caches
   ===================================================================== */

USE [GroupWst6];
GO

PRINT '=================================================================';
PRINT 'CLEARING ALL CACHES AND FORCING REFRESH';
PRINT '=================================================================';
PRINT '';

-- Clear query execution plan cache
DBCC FREEPROCCACHE;
PRINT '? Cleared query plan cache';

-- Clear buffer pool
DBCC DROPCLEANBUFFERS;
PRINT '? Cleared buffer pool';

-- Update statistics
UPDATE STATISTICS dbo.Patient;
PRINT '? Updated Patient table statistics';

UPDATE STATISTICS dbo.Staff;
PRINT '? Updated Staff table statistics';

UPDATE STATISTICS dbo.UserAccount;
PRINT '? Updated UserAccount table statistics';

PRINT '';
PRINT '=================================================================';
PRINT 'CACHE CLEARED - Now:';
PRINT '=================================================================';
PRINT '';
PRINT '1. CLOSE SQL Server Management Studio completely';
PRINT '2. Re-open SQL Server Management Studio';
PRINT '3. Re-connect to your database';
PRINT '4. Expand dbo.Patient ? Columns';
PRINT '5. Right-click Patient table and select REFRESH';
PRINT '6. The column list should now be updated!';
PRINT '';
