# ?? DATABASE SCHEMA - Target Architecture

## Final Database Structure (After Fix)

After running the master fix script, your database will have this clean structure:

---

## ?? Patient Table

### Purpose
Store **ONLY** patient demographic information

### Structure
```sql
CREATE TABLE [dbo].[Patient] (
    [Patient_ID] INT PRIMARY KEY IDENTITY(1,1) NOT NULL,
    [First_Name] VARCHAR(50) NOT NULL,
    [Last_Name] VARCHAR(50) NOT NULL,
    [ID_Number] VARCHAR(13) NOT NULL UNIQUE,
    [Gender] CHAR(1) NOT NULL,
    [Date_Of_Birth] DATETIME NOT NULL,
    [Address] VARCHAR(200),
    [Contact_No] VARCHAR(10),
    [Email] VARCHAR(100),
    [Allergies] TEXT,
    [Extra_Notes] TEXT,
    [Is_Active] BIT NOT NULL DEFAULT 1
)
```

### What's Stored
```
? First_Name        Patient's first name
? Last_Name         Patient's last name
? ID_Number         South African ID (13 digits)
? Gender            M or F
? Date_Of_Birth     Patient's DOB
? Address           Residential address
? Contact_No        Phone number
? Email             Email for contact
? Allergies         Medical allergies
? Extra_Notes       Additional medical notes
? Is_Active         1=active, 0=archived
```

### What's NOT Stored (Moved to UserAccount)
```
? Password              ? UserAccount.Password
? Is_First_Login        ? UserAccount.Is_First_Login
? Is_Account_Active     ? UserAccount.Is_Account_Active
? Security_Question     ? UserAccount.Security_Question
? Security_Answer       ? UserAccount.Security_Answer
```

### Sample Row
```
Patient_ID:       123
First_Name:       John
Last_Name:        Doe
ID_Number:        9001011234567
Gender:           M
Date_Of_Birth:    1990-01-01
Address:          123 Main St, Durban
Contact_No:       0821234567
Email:            john@example.com
Allergies:        Penicillin
Extra_Notes:      Prefers morning appointments
Is_Active:        1
```

---

## ?? Staff Table

### Purpose
Store **ONLY** staff information and employment data

### Structure
```sql
CREATE TABLE [dbo].[Staff] (
    [Staff_ID] INT PRIMARY KEY IDENTITY(1,1) NOT NULL,
    [First_Name] VARCHAR(50) NOT NULL,
    [Last_Name] VARCHAR(50) NOT NULL,
    [Email] VARCHAR(100),
    [Is_Active] BIT NOT NULL DEFAULT 1
)
```

### What's Stored
```
? Staff_ID              Unique staff identifier
? First_Name            Staff member's first name
? Last_Name             Staff member's last name
? Email                 Staff email (for contact)
? Is_Active             1=active, 0=inactive
```

### What's NOT Stored (Moved to UserAccount)
```
? Password              ? UserAccount.Password
? Role                  ? UserAccount.Role
? Is_First_Login        ? UserAccount.Is_First_Login
? Is_Account_Active     ? UserAccount.Is_Account_Active
? Security_Question     ? UserAccount.Security_Question
? Security_Answer       ? UserAccount.Security_Answer
```

### Sample Rows
```
Staff_ID:    1
First_Name:  Dr.
Last_Name:   Sarah
Email:       sarah@clinic.com
Is_Active:   1

Staff_ID:    2
First_Name:  Jane
Last_Name:   Receptionist
Email:       jane@clinic.com
Is_Active:   1

Staff_ID:    3
First_Name:  Bob
Last_Name:   Therapist
Email:       bob@clinic.com
Is_Active:   1
```

---

## ?? UserAccount Table

### Purpose
Store **ALL** authentication credentials and roles (SINGLE SOURCE OF TRUTH)

### Structure
```sql
CREATE TABLE [dbo].[UserAccount] (
    [User_ID] INT PRIMARY KEY IDENTITY(1,1) NOT NULL,
    [Email] VARCHAR(100) NOT NULL UNIQUE,
    [Password] VARCHAR(255) NOT NULL,
    [Role] VARCHAR(50) NOT NULL,
    [AccountType] VARCHAR(20) NOT NULL,
    [Staff_ID] INT FOREIGN KEY REFERENCES Staff(Staff_ID),
    [Patient_ID] INT FOREIGN KEY REFERENCES Patient(Patient_ID),
    [Is_Active] BIT NOT NULL DEFAULT 1,
    [Is_First_Login] BIT NOT NULL DEFAULT 0,
    [Is_Account_Active] BIT NOT NULL DEFAULT 1,
    [Security_Question] VARCHAR(225),
    [Security_Answer] VARCHAR(225)
)
```

### Columns Explained

| Column | Type | Purpose | Example |
|--------|------|---------|---------|
| User_ID | INT PK | Unique identifier | 1, 2, 3 |
| Email | VARCHAR(100) | Login identifier | john@clinic.com |
| Password | VARCHAR(255) | PBKDF2 hash | $2a$11$abcd... |
| Role | VARCHAR(50) | User role | Doctor, Receptionist, Patient |
| AccountType | VARCHAR(20) | Staff or Patient | Staff or Patient |
| Staff_ID | INT FK | Links to Staff table | 1, 2, 3 |
| Patient_ID | INT FK | Links to Patient table | 100, 101, 102 |
| Is_Active | BIT | Account exists | 1 (active), 0 (deleted) |
| Is_First_Login | BIT | Must change password | 1 (yes), 0 (no) |
| Is_Account_Active | BIT | Can log in | 1 (yes), 0 (deactivated) |
| Security_Question | VARCHAR(225) | Forgot password Q | What's your pet's name? |
| Security_Answer | VARCHAR(225) | Forgot password A | PBKDF2 hash of answer |

### Sample Staff Account
```
User_ID:            1
Email:              sarah@clinic.com
Password:           $2a$11$[PBKDF2HASH]...
Role:               Doctor
AccountType:        Staff
Staff_ID:           1 (references Staff.Staff_ID=1)
Patient_ID:         NULL
Is_Active:          1
Is_First_Login:     0
Is_Account_Active:  1
Security_Question:  What was your first car?
Security_Answer:    $2a$11$[PBKDF2HASH]...
```

### Sample Patient Account
```
User_ID:            100
Email:              john@example.com
Password:           $2a$11$[PBKDF2HASH]...
Role:               Patient
AccountType:        Patient
Staff_ID:           NULL
Patient_ID:         123 (references Patient.Patient_ID=123)
Is_Active:          1
Is_First_Login:     0
Is_Account_Active:  1
Security_Question:  Where were you born?
Security_Answer:    $2a$11$[PBKDF2HASH]...
```

---

## ?? Relationships

### Staff ? UserAccount
```
Staff.Staff_ID ?? UserAccount.Staff_ID
(One-to-Many: One staff can only have one account for login)

Example:
Staff (Staff_ID=1) ? UserAccount (Staff_ID=1)
  Staff name: Sarah
  UserAccount: email=sarah@clinic.com, role=Doctor
```

### Patient ? UserAccount
```
Patient.Patient_ID ?? UserAccount.Patient_ID
(One-to-Many: One patient can have one online account)

Example:
Patient (Patient_ID=123) ? UserAccount (Patient_ID=123)
  Patient name: John Doe
  UserAccount: email=john@example.com, role=Patient
```

---

## ?? Security Architecture

### Credential Storage
```
Password Storage (UserAccount.Password)
  ?
Input: Plaintext password from login form
  ?
Hash: PBKDF2 (Password-Based Key Derivation Function 2)
  ?
Stored: $2a$11$[HASH]... (never plaintext)
  ?
Verification: Compare hash(input) with stored hash
```

### Role-Based Access
```
UserAccount.Role ? Determines Access Level
  ?? Doctor      ? Full access (admin)
  ?? Receptionist ? Manage appointments, accounts
  ?? Therapist   ? View treatment data
  ?? Patient     ? View own data, book appointments
```

### Account Status Flags
```
Is_Active           ? Account exists (1) or deleted (0)
Is_Account_Active   ? Can log in (1) or deactivated (0)
Is_First_Login      ? Must change password at next login (1 or 0)
```

---

## ?? Data Flow Examples

### Staff Login Flow
```
1. User enters email: sarah@clinic.com, password: MyPassword123

2. Query: SELECT * FROM UserAccount WHERE Email='sarah@clinic.com'
   Gets: User_ID=1, AccountType=Staff, Staff_ID=1, Role=Doctor, ...

3. Verify password: PBKDF2.Verify('MyPassword123', stored_hash)
   Result: ? Passwords match

4. Check if active:
   - Is_Active = 1 ?
   - Is_Account_Active = 1 ?

5. Get staff name: SELECT First_Name, Last_Name FROM Staff WHERE Staff_ID=1
   Gets: First_Name=Sarah, Last_Name=Johnson

6. Create identity:
   - Email: sarah@clinic.com
   - FullName: Sarah Johnson
   - Role: Doctor
   - AccountType: Staff
   - AccountId: 1

7. Redirect to: Portal/Dashboard.aspx
```

### Patient Registration Flow
```
1. New patient fills form: email, password, name, etc.

2. Create Patient record:
   INSERT INTO Patient (First_Name, Last_Name, ... Email, Is_Active)
   VALUES ('John', 'Doe', ..., 'john@example.com', 1)
   ? Returns: Patient_ID=123

3. Hash password: PBKDF2.Hash('ChosenPassword')
   ? Result: $2a$11$[HASH]...

4. Create UserAccount:
   INSERT INTO UserAccount (Email, Password, Role, AccountType, Patient_ID, ...)
   VALUES ('john@example.com', '[HASH]', 'Patient', 'Patient', 123, ...)

5. Send email with confirmation

6. Patient can now log in with their credentials
```

---

## ? Verification Queries

After the fix is applied, you can verify:

### Check Patient Table Structure
```sql
EXEC sp_columns @table_name = 'Patient';
-- Should NOT have: Password, Is_First_Login, Security_Question, Security_Answer
```

### Check Staff Table Structure
```sql
EXEC sp_columns @table_name = 'Staff';
-- Should NOT have: Password, Role, Is_First_Login, Security_Question, Security_Answer
```

### Check UserAccount Table Structure
```sql
EXEC sp_columns @table_name = 'UserAccount';
-- Should have: User_ID, Email, Password, Role, AccountType, Staff_ID, Patient_ID, etc.
```

### Check Staff with Accounts
```sql
SELECT s.Staff_ID, s.First_Name, s.Last_Name, ua.Email, ua.Role
FROM Staff s
LEFT JOIN UserAccount ua ON s.Staff_ID = ua.Staff_ID
ORDER BY s.Last_Name;
```

### Check Patients with Accounts
```sql
SELECT p.Patient_ID, p.First_Name, p.Last_Name, ua.Email, ua.Role, p.Is_Active
FROM Patient p
LEFT JOIN UserAccount ua ON p.Patient_ID = ua.Patient_ID
WHERE p.Is_Active = 1
ORDER BY p.Last_Name;
```

---

## ?? Benefits of This Schema

### ? Security
- Single credential storage
- No duplication = no inconsistency
- Easier to audit
- Easier to implement account controls

### ? Maintainability
- Clear separation of concerns
- Demographics ? Credentials
- Easier to understand
- Easier to debug

### ? Scalability
- Can add new auth methods (OAuth, SAML)
- Can add account lockouts
- Can add session tracking
- Can add IP whitelisting

### ? Compliance
- GDPR: Can purge credentials separately
- HIPAA: Clear audit trail
- SOC 2: Centralized auth management

---

**This is your target database schema! All credential issues will be resolved once the master script runs.** ?
