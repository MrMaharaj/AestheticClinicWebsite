# Quick Testing Guide - What You Need to Verify

## ?? Your Current Situation

? **Fixed:** Manage Accounts page now works
?? **TODO:** Verify it works for ALL roles and scenarios

---

## ?? Quick Verification Queries

Before testing, run these in SQL to confirm the migration:

```sql
USE GroupWst6;
GO

-- How many patient credentials are in UserAccount?
SELECT 'Patient Credentials in UserAccount:' AS [Status];
SELECT COUNT(*) FROM UserAccount WHERE AccountType = 'Patient';

-- How many are still in Patient table?
SELECT 'Still in Patient Table (as backup):' AS [Status];
SELECT COUNT(*) FROM Patient WHERE [Password] IS NOT NULL;

-- Show me the patient accounts
SELECT 'Patients with Online Accounts:' AS [Status];
SELECT Patient_ID, First_Name, Last_Name, Email, AccountType, Is_First_Login, Is_Account_Active 
FROM Patient p LEFT JOIN UserAccount ua ON ua.Patient_ID = p.Patient_ID 
WHERE ua.Patient_ID IS NOT NULL;

-- Show me staff credentials
SELECT 'Staff in UserAccount:' AS [Status];
SELECT Staff_ID, Email, AccountType, Is_Active, Is_First_Login FROM UserAccount WHERE AccountType = 'Staff';
```

---

## ?? Roles to Test

### 1?? **Patient** (Most Important)
- [ ] Can register new account
- [ ] Can login with email/password
- [ ] Can change password
- [ ] Can use forgot password
- [ ] Credentials come from UserAccount (not Patient table)

### 2?? **Doctor/Admin** (Most Important)
- [ ] Can login
- [ ] Can access Manage Accounts page ? **THIS WAS BROKEN, NOW FIXED**
- [ ] Can manage patient accounts
- [ ] Can manage staff accounts

### 3?? **Receptionist** (If Available)
- [ ] Can login
- [ ] Can access their role's features
- [ ] Cannot access admin-only pages

### 4?? **Other Staff** (If Any)
- [ ] Can login
- [ ] Can access appropriate features

---

## ?? Minimal Testing Checklist

**Test these 5 things to confirm everything works:**

### Test 1: Patient Login ?/?
```
1. Go to /Account/Login.aspx
2. Login with existing patient email/password
3. Should redirect to patient dashboard
4. Check User_ID = existing patient ID
```

### Test 2: New Patient Registration ?/?
```
1. Go to /Account/Register.aspx
2. Register with new email
3. Should create Patient record + UserAccount record
4. Verify email is in UserAccount table (SELECT from SQL)
```

### Test 3: Doctor/Admin Login ?/?
```
1. Go to /Account/Login.aspx
2. Login as doctor/admin
3. Should redirect to staff portal
4. Check User_ID = staff ID
```

### Test 4: Manage Accounts Page ?/?
```
1. Login as admin
2. Go to /Portal/ManageAccounts.aspx
3. Page should load WITHOUT error (was showing error before)
4. Should see patient list with online account status
```

### Test 5: Account Management ?/?
```
1. In Manage Accounts, click "Create login" for a patient
2. Should generate temporary password
3. Logout and login as that patient with temp password
4. Should be forced to change password
5. After changing password, should be able to login normally
```

---

## ? Success Criteria

Once you've confirmed these work, you're good:

- ? Patient can register
- ? Patient can login
- ? Doctor/admin can login
- ? Manage Accounts page loads (no errors)
- ? Admin can manage patient accounts
- ? Admin can manage staff accounts

---

## ?? If Something Breaks

**Patient Can't Login:**
```sql
-- Check if email is in UserAccount
SELECT * FROM UserAccount WHERE Email = 'patient@email.com'

-- Check if they have AccountType = 'Patient'
SELECT AccountType FROM UserAccount WHERE Email = 'patient@email.com'

-- Check if Is_Active = 1 and Is_Account_Active = 1
SELECT Is_Active, Is_Account_Active FROM UserAccount WHERE Email = 'patient@email.com'
```

**Doctor Can't Login:**
```sql
-- Check if email is in UserAccount or Staff table
SELECT * FROM UserAccount WHERE Email = 'doctor@email.com'
SELECT * FROM Staff WHERE Email = 'doctor@email.com'

-- Check if Is_Active = 1
SELECT Is_Active FROM UserAccount WHERE Email = 'doctor@email.com'
```

**Manage Accounts Page Shows Error:**
```sql
-- Check UserAccount table structure
SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'UserAccount'
ORDER BY ORDINAL_POSITION

-- Should include: User_ID, Patient_ID, Staff_ID, AccountType, 
--                 Is_Active, Is_Account_Active, Email, Password, etc.
```

---

## ?? Timeline

- **Now:** Do minimal testing (5 tests above)
- **This Week:** Test all roles and features (see TESTING_CHECKLIST.md)
- **1-2 Weeks:** Let system run, monitor logs
- **After 1-2 Weeks:** Run cleanup script (08_Cleanup_Old_Credentials.sql)

---

## ?? Full Documentation

For detailed testing: `TESTING_CHECKLIST.md`
For cleanup info: `CLEANUP_READINESS_GUIDE.md`
For exact SQL: `CLEANUP_READY_TO_EXECUTE.md`
For status: `MIGRATION_STATUS_SUMMARY.md`

---

**What's the first test you want to run?** ??
