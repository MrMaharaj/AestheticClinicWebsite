/* =====================================================================
   FIX STAFF TABLE STRUCTURE

   Staff table should ONLY contain:
   - Staff_ID (PK)
   - First_Name
   - Last_Name
   - Email
   - Is_Active

   ALL credentials (Password, Is_First_Login, Security_Question, 
   Security_Answer, Role) must be stored in UserAccount table only.

   This script:
   1. Removes credential columns from Staff table
   2. Removes Role column from Staff table (now in UserAccount)
   3. Adds Email and Is_Active columns if missing
   4. Verifies the final structure

   Safe to run multiple times.
   ===================================================================== */

USE [GroupWst6];
GO

PRINT '';
PRINT '====================================================================';
PRINT '          FIXING STAFF TABLE STRUCTURE';
PRINT '====================================================================';
PRINT '';

-- =====================================================================
-- STEP 1: Remove credential columns from Staff table
-- =====================================================================
PRINT 'STEP 1: Removing credential columns from Staff table...';
PRINT '???????????????????????????????????????????????????????';

BEGIN TRY
    IF COL_LENGTH('dbo.Staff', 'Password') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN [Password];
        PRINT '? Dropped Staff.Password';
    END
    ELSE
        PRINT '� Staff.Password does not exist';
END TRY
BEGIN CATCH
    PRINT '? Error dropping Staff.Password: ' + ERROR_MESSAGE();
END CATCH

BEGIN TRY
    IF COL_LENGTH('dbo.Staff', 'Is_First_Login') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN [Is_First_Login];
        PRINT '? Dropped Staff.Is_First_Login';
    END
    ELSE
        PRINT '� Staff.Is_First_Login does not exist';
END TRY
BEGIN CATCH
    PRINT '? Error dropping Staff.Is_First_Login: ' + ERROR_MESSAGE();
END CATCH

BEGIN TRY
    IF COL_LENGTH('dbo.Staff', 'Security_Question') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN [Security_Question];
        PRINT '? Dropped Staff.Security_Question';
    END
    ELSE
        PRINT '� Staff.Security_Question does not exist';
END TRY
BEGIN CATCH
    PRINT '? Error dropping Staff.Security_Question: ' + ERROR_MESSAGE();
END CATCH

BEGIN TRY
    IF COL_LENGTH('dbo.Staff', 'Security_Answer') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN [Security_Answer];
        PRINT '? Dropped Staff.Security_Answer';
    END
    ELSE
        PRINT '� Staff.Security_Answer does not exist';
END TRY
BEGIN CATCH
    PRINT '? Error dropping Staff.Security_Answer: ' + ERROR_MESSAGE();
END CATCH

BEGIN TRY
    IF COL_LENGTH('dbo.Staff', 'Role') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN [Role];
        PRINT '? Dropped Staff.Role (now managed in UserAccount)';
    END
    ELSE
        PRINT '� Staff.Role does not exist';
END TRY
BEGIN CATCH
    PRINT '? Error dropping Staff.Role: ' + ERROR_MESSAGE();
END CATCH

-- =====================================================================
-- STEP 2: Ensure required columns exist
-- =====================================================================
PRINT '';
PRINT 'STEP 2: Ensuring required columns exist...';
PRINT '??????????????????????????????????????????';

BEGIN TRY
    IF COL_LENGTH('dbo.Staff', 'Email') IS NULL
    BEGIN
        ALTER TABLE dbo.Staff ADD [Email] VARCHAR(100) NULL;
        PRINT '? Added Staff.Email column';
    END
    ELSE
        PRINT '� Staff.Email already exists';
END TRY
BEGIN CATCH
    PRINT '? Error adding Staff.Email: ' + ERROR_MESSAGE();
END CATCH

BEGIN TRY
    IF COL_LENGTH('dbo.Staff', 'Is_Active') IS NULL
    BEGIN
        ALTER TABLE dbo.Staff ADD [Is_Active] BIT NOT NULL DEFAULT 1;
        PRINT '? Added Staff.Is_Active column';
    END
    ELSE
        PRINT '� Staff.Is_Active already exists';
END TRY
BEGIN CATCH
    PRINT '? Error adding Staff.Is_Active: ' + ERROR_MESSAGE();
END CATCH

-- =====================================================================
-- STEP 3: Verify structure
-- =====================================================================
PRINT '';
PRINT 'STEP 3: Verifying Staff table structure...';
PRINT '??????????????????????????????????????????';

SELECT 
    COLUMN_NAME, 
    DATA_TYPE, 
    IS_NULLABLE,
    CASE WHEN COLUMN_DEFAULT IS NOT NULL THEN COLUMN_DEFAULT ELSE 'none' END AS DEFAULT_VALUE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'Staff'
ORDER BY ORDINAL_POSITION;

-- =====================================================================
-- STEP 4: Check for staff with no UserAccount
-- =====================================================================
PRINT '';
PRINT 'STEP 4: Checking staff without UserAccount entries...';
PRINT '???????????????????????????????????????????????????????';

DECLARE @orphanedCount INT = (
    SELECT COUNT(*) 
    FROM Staff s
    LEFT JOIN UserAccount ua ON s.Staff_ID = ua.Staff_ID AND ua.AccountType = 'Staff'
    WHERE ua.User_ID IS NULL
);

IF @orphanedCount > 0
BEGIN
    PRINT '? WARNING: ' + CAST(@orphanedCount AS VARCHAR(10)) + ' staff members have no UserAccount entry!';
    PRINT '';
    PRINT 'Staff IDs without UserAccount:';
    SELECT 
        '  ? Staff_ID: ' + CAST(s.Staff_ID AS VARCHAR(10)) + ' | ' + s.First_Name + ' ' + s.Last_Name + ' | Email: ' + ISNULL(s.Email, 'NO EMAIL')
    FROM Staff s
    LEFT JOIN UserAccount ua ON s.Staff_ID = ua.Staff_ID AND ua.AccountType = 'Staff'
    WHERE ua.User_ID IS NULL;

    PRINT '';
    PRINT 'ACTION: Create UserAccount entries for these staff before they can log in.';
END
ELSE
BEGIN
    PRINT '? All staff members have UserAccount entries';
END

PRINT '';
PRINT '====================================================================';
PRINT '                    STAFF TABLE FIXED';
PRINT '====================================================================';
PRINT '';
