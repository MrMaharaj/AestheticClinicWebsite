# RBAC QUICK REFERENCE

## One-Minute Overview

After credential consolidation, **all access control is role-based**:

```
Patient  ? Can see only their own data
Doctor   ? Can see everything, manage staff
Receptionist ? Can see patients, manage appointments, handle accounts
Therapist ? Can see treatment-related data only
```

---

## Quick Code Snippets

### Check User Role
```csharp
// What am I?
RoleBasedAccess.IsDoctor()        // true if Doctor/Admin
RoleBasedAccess.IsReceptionist()  // true if Receptionist
RoleBasedAccess.IsTherapist()     // true if Therapist
RoleBasedAccess.IsPatientRole()   // true if Patient

// Do I have role X?
RoleBasedAccess.HasRole("Doctor")                    // Single role
RoleBasedAccess.HasRole("Doctor", "Receptionist")   // Multiple roles
```

### Check Permissions
```csharp
// Can I see this patient?
RoleBasedAccess.CanViewPatient(patientId)

// Can I see clinical data?
RoleBasedAccess.CanViewClinicalData(patientId)

// Can I see financial data?
RoleBasedAccess.CanViewFinancial(patientId)

// Can I manage accounts?
RoleBasedAccess.CanManagePatientAccounts()

// Can I manage staff?
RoleBasedAccess.CanManageStaff()

// Can I book appointments?
RoleBasedAccess.CanBookAppointmentFor(patientId)
```

### Restrict Pages
```csharp
// Option 1: In class definition
public partial class ManageStaff : StaffPage
{
    protected override string[] RequiredRoles => new[] { "Doctor", "Admin" };
}

// Option 2: In OnInit
protected override void OnInit(EventArgs e)
{
    RoleBasedAccess.RequireRole(this, "Doctor", "Receptionist");
    base.OnInit(e);
}
```

### Show/Hide UI
```csharp
btnManageStaff.Visible = RoleBasedAccess.IsDoctor();
pnlClinicalNotes.Visible = RoleBasedAccess.CanViewClinicalData(patientId);
pnlInvoices.Visible = RoleBasedAccess.CanViewFinancial(patientId);
```

---

## Database Roles

Add these roles to your `UserAccount.Role` column:

| Role | Staff/Patient | Can Do |
|------|---------------|--------|
| **Patient** | Patient | View own data only |
| **Receptionist** | Staff | Book appointments, manage accounts, see patient list |
| **Therapist** | Staff | See treatment data, book appointments |
| **Doctor** | Staff | Everything (admin) |
| **Admin** | Staff | Everything (alias for Doctor) |

```sql
-- Example: Create a receptionist account
INSERT INTO UserAccount (Email, Password, Role, AccountType, Staff_ID, Is_Active, Is_Account_Active, ...)
VALUES ('sarah@clinic.com', 'hashed_password', 'Receptionist', 'Staff', 3, 1, 1, ...)

-- Example: Promote to Doctor
UPDATE UserAccount SET Role = 'Doctor' WHERE Email = 'sarah@clinic.com'
```

---

## Access Matrix

|  | Patient | Receptionist | Therapist | Doctor |
|---|---------|--------------|-----------|--------|
| View own appointments | ? | - | - | - |
| View all patients | ? | ? | ?* | ? |
| View clinical notes | ?** | ? | ? | ? |
| View invoices | ?** | ? | ? | ? |
| Manage appointments | ?** | ? | ? | ? |
| Reset password | ? | ? | ? | ? |
| Manage staff | ? | ? | ? | ? |
| View reports | ? | ? | ? | ? |

\* Therapists see only their patients  
\** Only their own data

---

## Web.config Settings (Optional)

Add to appSettings to customize roles:

```xml
<add key="Roles:DoctorRole" value="Doctor" />
<add key="Roles:ReceptionistRole" value="Receptionist" />
<add key="Roles:TherapistRole" value="Therapist" />
<add key="Roles:PatientRole" value="Patient" />
<add key="Roles:AdminRoles" value="Doctor,Admin,Administrator,Manager" />
<add key="Roles:StaffRoles" value="Doctor,Receptionist,Therapist,Admin" />
```

---

## Implementation Steps

### Step 1: Run Cleanup SQL
```sql
-- File: Database/10_Finalize_Credentials_To_UserAccount_Only.sql
-- This removes all password columns from Patient and Staff tables
-- (keep this for 1-2 weeks before running)
```

### Step 2: Add RoleBasedAccess to Your Pages
```csharp
using AestheticClinicWeb.Helpers;

// In page class
if (RoleBasedAccess.CanViewClinicalData(patientId))
{
    ShowClinicalData(patientId);
}
```

### Step 3: Update Page Base Classes
```csharp
// Portal pages
public partial class MyPage : StaffPage
{
    protected override string[] RequiredRoles 
        => new[] { "Doctor", "Receptionist" };
}

// Patient pages (already secure, just make sure PatientId matches)
public partial class MyPatientPage : PatientPage
{
    // PatientPage ensures it's a patient and has valid PatientId
}
```

### Step 4: Test Each Role
- Login as Patient ? Can see only own data
- Login as Receptionist ? Can see patients, manage appointments
- Login as Therapist ? Can see treatment data
- Login as Doctor ? Can see everything

---

## Files Reference

| File | Purpose |
|------|---------|
| `Security/Auth.cs` | Handles login and identity parsing |
| `Helpers/RoleBasedAccess.cs` | **Main RBAC class - use this!** |
| `Helpers/StaffPageRolesBased.cs` | Base class for staff pages with roles |
| `Helpers/PatientPage.cs` | Base class for patient pages (already secure) |
| `Database/10_Finalize_Credentials_To_UserAccount_Only.sql` | Cleanup script (remove cred columns) |
| `Database/RBAC_IMPLEMENTATION_GUIDE.md` | Full detailed guide |

---

## Common Tasks

### "Make this page Doctor-only"
```csharp
public partial class ManageStaff : StaffPage
{
    protected override string[] RequiredRoles => new[] { "Doctor", "Admin" };
}
```

### "Show button only to receptionists"
```csharp
btnManageAccounts.Visible = RoleBasedAccess.IsReceptionist();
```

### "Hide clinical data from receptionists"
```csharp
if (!RoleBasedAccess.CanViewClinicalData(patientId))
    pnlClinicalNotes.Visible = false;
```

### "Ensure patient sees only their own data"
```csharp
// PatientPage already does this!
public partial class PatientAppointments : PatientPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // PatientId is automatically set to current patient
        LoadAppointments(PatientId);
    }
}
```

### "Prevent unprivileged users from calling an API"
```csharp
if (!RoleBasedAccess.CanManageStaff())
    throw new InvalidOperationException("Unauthorized");

AddNewStaff(staffData);
```

---

## Troubleshooting

### "User can still see data they shouldn't"
1. Check that role is set in UserAccount table
2. Check that RoleBasedAccess check is server-side (not just UI)
3. Check that ALL queries filter by role

### "Role checks in StaffPage aren't working"
1. Make sure page inherits from `StaffPage` not `BasePage`
2. Make sure `RequiredRoles` or `AdminOnly` is set
3. Check that user is actually logged in as staff

### "Patient can see other patients' data"
1. Check that patient page inherits from `PatientPage`
2. Check that all queries filter by `PatientId`
3. Make sure you're using `Auth.Current.PatientId` not user input

---

## Next Steps

1. **Immediately:** Run cleanup SQL script (10_Finalize_Credentials_To_UserAccount_Only.sql)
2. **This week:** Add RoleBasedAccess to your main pages
3. **Next week:** Test with each role
4. **Monitor:** Watch logs for access denied errors
5. **Refine:** Adjust roles/permissions as needed

---

## Support

See `Database/RBAC_IMPLEMENTATION_GUIDE.md` for:
- Detailed examples
- Complete API reference
- Implementation best practices
- Security checklist
- Testing procedures
