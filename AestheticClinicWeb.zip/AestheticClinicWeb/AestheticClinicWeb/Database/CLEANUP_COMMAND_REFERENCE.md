# ??? Cleanup Command - Reference Card

Keep this handy. Run AFTER 1-2 weeks of successful testing.

---

## Status Check

Run this FIRST to confirm you're ready:

```sql
USE GroupWst6;
GO

-- How many patient credentials in UserAccount?
PRINT 'Patient credentials in UserAccount:';
SELECT COUNT(*) AS PatientCount FROM UserAccount WHERE AccountType = 'Patient';

-- How many still in Patient table (backup)?
PRINT 'Patient credentials in Patient table (will be deleted):';
SELECT COUNT(*) AS PatientCount FROM Patient WHERE [Password] IS NOT NULL;

-- List patients with credentials still in Patient table
PRINT 'These patients will have their backup credentials deleted:';
SELECT Patient_ID, First_Name, Last_Name, Email 
FROM Patient 
WHERE [Password] IS NOT NULL;
```

---

## Cleanup Command

**Option A: PowerShell (Recommended)**

```powershell
sqlcmd -S 146.230.177.46 -U GroupWst6 -P h2e8j -d GroupWst6 -i "C:\Users\Ashto\OneDrive\Desktop\ISTN3SI\AestheticClinicWeb_M4\AestheticClinicWeb\AestheticClinicWeb\Database\08_Cleanup_Old_Credentials.sql"
```

**Option B: SQL Server Management Studio**
1. Open: `08_Cleanup_Old_Credentials.sql`
2. Click Execute (F5)
3. Review output

---

## What Will Be Deleted

From the `Patient` table:

- ? `Password` column
- ? `Is_First_Login` column
- ? `Is_Account_Active` column
- ? `Security_Question` column
- ? `Security_Answer` column

**Note:** Patient.Email will remain (it's used for contact, not login)

---

## After Cleanup - Verify

```sql
USE GroupWst6;
GO

PRINT 'Patient table final structure:';
SELECT COLUMN_NAME, DATA_TYPE 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'Patient' 
ORDER BY ORDINAL_POSITION;

-- Should NOT see: Password, Is_First_Login, Is_Account_Active, Security_Question, Security_Answer
```

---

## If Cleanup Fails

**Common issues:**

### "Column does not exist"
- This is OK - script checks for this
- Script will skip it and continue

### "Cannot drop column, it's used by..."
- Another object references it
- Check for CHECK constraints, defaults, etc.
- Script handles this automatically

### "Access denied"
- User doesn't have permission
- Use admin account for SQL Server
- Verify login is correct

---

## Rollback Plan

**If something goes wrong after cleanup:**

```sql
-- Re-run the migration script:
08_Cleanup_Old_Credentials.sql

-- Or re-run:
06_Migrate_To_Unified_UserAccount.sql

-- This will recreate the columns
-- But UserAccount is now the source of truth
-- So manual sync may be needed

-- Better to be careful and test thoroughly first!
```

---

## Timeline Reminder

```
Today ?????????? Week 1 ?????????? Week 2 ?????????? Week 3
 ?              ? Monitor        ? Monitor        ??? Cleanup
Database OK     System works     System stable    Ready
Code fixed      Test passing     No errors        Execute cleanup
Manage Accounts                                   Columns gone
 works
```

---

## Pre-Cleanup Checklist

Before running cleanup, verify:

- [ ] Manage Accounts page works ?
- [ ] Patient can login ?
- [ ] Doctor/staff can login ?
- [ ] Password changes work ?
- [ ] Forgot password works ?
- [ ] Admin functions work ?
- [ ] No errors in application logs ?
- [ ] 1-2 weeks have passed ?
- [ ] All roles have been tested ?
- [ ] You're confident everything works ?

---

## Commands to Keep

**Pre-cleanup verification:**
```powershell
sqlcmd -S 146.230.177.46 -U GroupWst6 -P h2e8j -d GroupWst6 -Q "SELECT 'Patients in UserAccount:' AS [Status]; SELECT COUNT(*) FROM UserAccount WHERE AccountType = 'Patient'"
```

**Run cleanup:**
```powershell
sqlcmd -S 146.230.177.46 -U GroupWst6 -P h2e8j -d GroupWst6 -i "C:\Users\Ashto\OneDrive\Desktop\ISTN3SI\AestheticClinicWeb_M4\AestheticClinicWeb\AestheticClinicWeb\Database\08_Cleanup_Old_Credentials.sql"
```

**Post-cleanup verification:**
```powershell
sqlcmd -S 146.230.177.46 -U GroupWst6 -P h2e8j -d GroupWst6 -Q "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Patient' ORDER BY ORDINAL_POSITION"
```

---

**When ready: Come back here and run the commands above** ??
