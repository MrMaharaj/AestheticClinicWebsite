# UPDATED: Migration Plan for YOUR Existing UserAccount Table

## Your Current Situation

You already have a `UserAccount` table that was designed for doctor sign-ups, with this structure:

```
User_ID (PK)
?? Patient_ID (FK to Patient)
?? Email
?? Password
?? Role
?? First_Name, Last_Name (from doctor sign-ups)
?? Account_Status
?? Security_Question, Security_Answer
?? Is_First_Login
```

## What the Updated Migration Script Does

Instead of creating a new table, the **updated migration script adapts your existing UserAccount table** by:

### Step 1: Add Missing Columns
```sql
AccountType           -- 'Patient' or 'Staff'
Staff_ID              -- FK to Staff table (for future use)
Is_Active             -- Account enabled/disabled
Is_Account_Active     -- Permission to login (separate from Is_Active)
Created_Date          -- Audit trail
Modified_Date         -- Audit trail
```

### Step 2: Populate New Columns
- Sets `AccountType = 'Patient'` for existing records that have `Patient_ID`
- Sets `Is_Account_Active` based on existing `Account_Status`
- Adds audit dates

### Step 3: Migrate Patient Credentials
- Copies patient login credentials from Patient table into UserAccount
- Only migrates if not already there (no duplicates)

### Step 4: Preserve Your Data
- ? All doctor sign-up records stay intact
- ? All existing patient credentials stay intact
- ? No data is deleted (only columns added)

---

## Simple Implementation Plan

### Step 1: Run the Migration Script (5 minutes)

```sql
-- In SQL Server Management Studio
USE GroupWst6;
GO
-- Run the entire script from:
-- AestheticClinicWeb\Database\06_Migrate_To_Unified_UserAccount.sql
```

**Result:**
- Your UserAccount table gains new columns
- Patient credentials are copied in (not moved from Patient table yet)
- Table is now ready for the new code

### Step 2: Deploy the New C# Code (5 minutes)

```bash
# In Visual Studio
# Backup current file
cp AestheticClinicWeb\Data\AccountRepository.cs AccountRepository_BACKUP.cs

# Replace with new version
# Delete: AccountRepository.cs
# Rename: AccountRepository_Secure.cs ? AccountRepository.cs

# Rebuild solution
```

### Step 3: Test (1-2 hours)

Run these critical tests:

```
? Patient login works
? Patient registration works
? First login password change works
? Staff login still works
? Forgot password works
? Admin account approval works
```

### Step 4: Cleanup (Optional, after 1-2 weeks)

```sql
-- Only after testing succeeds
-- Run: AestheticClinicWeb\Database\08_Cleanup_Old_Credentials.sql
```

This removes the old credential columns from Patient table (optional but recommended).

---

## Before & After

### BEFORE (Current - Insecure)
```
Patient Table                    UserAccount Table
?? Patient_ID                   ?? User_ID
?? First_Name, Last_Name        ?? Patient_ID
?? Email ????? Credential       ?? Email ????? Login (for doctor sign-ups)
?? Password ?? Credential       ?? Password
?? Is_First_Login               ?? Is_First_Login
?? Is_Account_Active            ?? Account_Status
?? Security_Question            ?? Security_Question
?? Security_Answer              ?? Security_Answer
?? (health data)                ?? First_Name, Last_Name
                                ?? Role

PROBLEM: Patient table mixes credentials with health data
```

### AFTER (Secure - After Migration & Cleanup)
```
UserAccount Table (ALL CREDENTIALS)
?? User_ID
?? Email ????? SINGLE LOGIN
?? Password ?? CENTRALIZED CREDENTIALS
?? Role
?? AccountType ('Patient' or 'Staff')
?? Patient_ID (links to patient data)
?? Staff_ID (links to staff data)
?? Account_Status, Is_First_Login
?? Security_Question, Security_Answer
?? Is_Active, Is_Account_Active
?? Created_Date, Modified_Date

Patient Table (PURE DATA ONLY)      Staff Table (PURE DATA ONLY)
?? Patient_ID                        ?? Staff_ID
?? First_Name, Last_Name            ?? First_Name, Last_Name
?? DOB, Gender                       ?? Role
?? Address                           ?? (no credentials)
?? (health data only, NO CREDS)

BENEFIT: Credentials completely separate from patient/staff data
```

---

## Key Points

### ? Safe to Run
- Script checks for existing columns before adding
- Won't duplicate data
- Can be re-run without issues

### ? No Data Loss
- All existing doctor sign-up records preserved
- All patient data preserved
- Only new columns added

### ? Backward Compatible
- Your existing User_ID primary key unchanged
- Your existing Patient_ID foreign key unchanged
- All existing columns remain

### ? Incremental Rollout
- Step 1: Database changes (safe)
- Step 2: Code deployment (testable)
- Step 3: Full testing (1-2 weeks)
- Step 4: Cleanup (optional, after confirmation)

---

## What to Verify After Running Migration

### Query 1: Check Column Structure
```sql
SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'UserAccount'
ORDER BY ORDINAL_POSITION;
```

You should see these new columns:
- `AccountType`
- `Staff_ID`
- `Is_Active`
- `Is_Account_Active`
- `Created_Date`
- `Modified_Date`

### Query 2: Check Records
```sql
SELECT COUNT(*) as TotalUserAccounts FROM UserAccount;
SELECT COUNT(*) as PatientAccounts FROM UserAccount WHERE AccountType = 'Patient';
```

Should show your existing records plus any migrated patient credentials.

### Query 3: Check for Duplicates
```sql
SELECT Email, COUNT(*) as Count FROM UserAccount 
GROUP BY Email HAVING COUNT(*) > 1;
```

Should return **no rows** (no duplicate emails).

---

## Rollback Plan

If anything goes wrong:

### Before Cleanup (Step 4)
1. Revert the C# code: `cp AccountRepository_BACKUP.cs AccountRepository.cs`
2. Restart the app
3. No data lost (old Patient.Password still exists)

### After Cleanup
You need a database backup to restore.

---

## Questions to Ask Your Mentor

1. ? Can I proceed with Step 1 (run migration script)?
2. ? Should I test locally first or in staging environment?
3. ? After testing, should I run the cleanup (Step 4)?
4. ? Should we also migrate Staff credentials to UserAccount, or keep them in Staff table for now?

---

## Timeline

- **Now**: Run migration script (5 min)
- **Today**: Deploy new code (5 min)
- **This week**: Test thoroughly (2-5 hours)
- **Next week**: Monitor logs, ensure no issues
- **Week 2+**: If all good, run cleanup script (5 min)

---

## Next Action

**You can now safely run the migration script!**

```sql
USE GroupWst6;
GO
-- Copy-paste and run: 06_Migrate_To_Unified_UserAccount.sql
```

The script will:
1. Add missing columns to your UserAccount table
2. Populate AccountType and other fields
3. Migrate patient credentials from Patient table
4. Show verification output

After running, share the verification output to confirm everything looks good!
