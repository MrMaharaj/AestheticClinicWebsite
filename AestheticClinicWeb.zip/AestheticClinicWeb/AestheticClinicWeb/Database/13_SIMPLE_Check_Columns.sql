/*
   =====================================================================
   SIMPLE DIAGNOSTIC - What columns actually exist RIGHT NOW

   This script uses simple, reliable methods to show what's actually there
   ===================================================================== */

USE [GroupWst6];
GO

PRINT '=================================================================';
PRINT 'SIMPLE COLUMN CHECK - What Really Exists';
PRINT '=================================================================';
PRINT '';

-- ====================================================================
-- Patient Table: List ALL columns that exist
-- ====================================================================
PRINT 'PATIENT TABLE - ALL CURRENT COLUMNS:';
PRINT '???????????????????????????????????';

SELECT 
    ROW_NUMBER() OVER (ORDER BY ORDINAL_POSITION) AS [#],
    COLUMN_NAME AS [Column Name],
    DATA_TYPE AS [Type],
    IS_NULLABLE AS [Nullable]
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'Patient'
ORDER BY ORDINAL_POSITION;

PRINT '';

-- ====================================================================
-- Staff Table: List ALL columns that exist
-- ====================================================================
PRINT 'STAFF TABLE - ALL CURRENT COLUMNS:';
PRINT '??????????????????????????????????';

SELECT 
    ROW_NUMBER() OVER (ORDER BY ORDINAL_POSITION) AS [#],
    COLUMN_NAME AS [Column Name],
    DATA_TYPE AS [Type],
    IS_NULLABLE AS [Nullable]
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'Staff'
ORDER BY ORDINAL_POSITION;

PRINT '';

-- ====================================================================
-- Check specifically for credential columns
-- ====================================================================
PRINT 'CREDENTIAL COLUMNS CHECK:';
PRINT '????????????????????????';
PRINT '';
PRINT 'Patient Table:';

IF COL_LENGTH('dbo.Patient', 'Password') IS NOT NULL
    PRINT '  ??  Password STILL EXISTS'
ELSE
    PRINT '  ? Password removed'

IF COL_LENGTH('dbo.Patient', 'Is_First_Login') IS NOT NULL
    PRINT '  ??  Is_First_Login STILL EXISTS'
ELSE
    PRINT '  ? Is_First_Login removed'

IF COL_LENGTH('dbo.Patient', 'Is_Account_Active') IS NOT NULL
    PRINT '  ??  Is_Account_Active STILL EXISTS'
ELSE
    PRINT '  ? Is_Account_Active removed'

IF COL_LENGTH('dbo.Patient', 'Security_Question') IS NOT NULL
    PRINT '  ??  Security_Question STILL EXISTS'
ELSE
    PRINT '  ? Security_Question removed'

IF COL_LENGTH('dbo.Patient', 'Security_Answer') IS NOT NULL
    PRINT '  ??  Security_Answer STILL EXISTS'
ELSE
    PRINT '  ? Security_Answer removed'

IF COL_LENGTH('dbo.Patient', 'Account_Status') IS NOT NULL
    PRINT '  ??  Account_Status STILL EXISTS'
ELSE
    PRINT '  ? Account_Status removed'

PRINT ''
PRINT 'Staff Table:';

IF COL_LENGTH('dbo.Staff', 'Password') IS NOT NULL
    PRINT '  ??  Password STILL EXISTS'
ELSE
    PRINT '  ? Password removed'

IF COL_LENGTH('dbo.Staff', 'Is_First_Login') IS NOT NULL
    PRINT '  ??  Is_First_Login STILL EXISTS'
ELSE
    PRINT '  ? Is_First_Login removed'

IF COL_LENGTH('dbo.Staff', 'Is_Account_Active') IS NOT NULL
    PRINT '  ??  Is_Account_Active STILL EXISTS'
ELSE
    PRINT '  ? Is_Account_Active removed'

IF COL_LENGTH('dbo.Staff', 'Security_Question') IS NOT NULL
    PRINT '  ??  Security_Question STILL EXISTS'
ELSE
    PRINT '  ? Security_Question removed'

IF COL_LENGTH('dbo.Staff', 'Security_Answer') IS NOT NULL
    PRINT '  ??  Security_Answer STILL EXISTS'
ELSE
    PRINT '  ? Security_Answer removed'

PRINT '';
PRINT '=================================================================';
PRINT 'END OF DIAGNOSTIC';
PRINT '=================================================================';
