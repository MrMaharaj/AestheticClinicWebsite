/* OPTIONAL demo data (run after steps 1-3). Safe to re-run; only inserts missing rows.
   Adds a receptionist login and two demo patients with online accounts:
     thandeka.demo@gmail.com / Patient@123  (active, with visit history, payments and weight metrics)
     rowan.demo@gmail.com    / Patient@123  (account DEACTIVATED - demo activation in Manage Accounts) */
USE [GroupWst6];
SET NOCOUNT ON;
BEGIN TRAN;
DECLARE @svc INT, @svcName VARCHAR(50), @price DECIMAL(6,2), @dur INT;
SELECT TOP 1 @svc = Service_ID, @svcName = Service_Name, @price = Price, @dur = Duration
FROM Service ORDER BY CASE WHEN Service_Name LIKE 'Weight Loss%' THEN 0 ELSE 1 END, Service_ID;
IF @svc IS NULL BEGIN RAISERROR('No rows in Service.', 16, 1); ROLLBACK; RETURN; END
IF @dur IS NULL OR @dur < 15 SET @dur = 30;

IF NOT EXISTS (SELECT 1 FROM Staff WHERE Email = 'reception.demo@aestheticflow.co.za')
    INSERT INTO Staff (First_Name, Last_Name, Email, Password, Role, Security_Question, Security_Answer, Is_Active, Is_First_Login)
    VALUES ('Nomsa', 'Dlamini', 'reception.demo@aestheticflow.co.za', 'Recept@123', 'Receptionist',
            'What was the first thing you bought with your own money?', 'bicycle', 1, 0);

IF NOT EXISTS (SELECT 1 FROM Patient WHERE ID_Number = '9203140123085')
    INSERT INTO Patient (First_Name, Last_Name, ID_Number, Gender, Date_Of_Birth, Address, Contact_No, Email, Allergies, Is_Active,
                         [Password], Is_First_Login, Is_Account_Active, Security_Question, Security_Answer)
    VALUES ('Thandeka', 'Mkhize', '9203140123085', 'F', '1992-03-14', '12 Ridge Road, Durban', '0821112233', 'thandeka.demo@gmail.com', 'None', 1,
            'Patient@123', 0, 1, 'What city were you born in?', 'durban');
IF NOT EXISTS (SELECT 1 FROM Patient WHERE ID_Number = '8807225123082')
    INSERT INTO Patient (First_Name, Last_Name, ID_Number, Gender, Date_Of_Birth, Address, Contact_No, Email, Allergies, Is_Active,
                         [Password], Is_First_Login, Is_Account_Active, Security_Question, Security_Answer)
    VALUES ('Rowan', 'Peters', '8807225123082', 'M', '1988-07-22', '4 Marine Parade, Durban', '0834445566', 'rowan.demo@gmail.com', 'Penicillin', 1,
            'Patient@123', 0, 0, 'What city were you born in?', 'cape town');

DECLARE @p1 INT = (SELECT Patient_ID FROM Patient WHERE ID_Number = '9203140123085');
DECLARE @p2 INT = (SELECT Patient_ID FROM Patient WHERE ID_Number = '8807225123082');

IF NOT EXISTS (SELECT 1 FROM Appointment WHERE Patient_ID = @p1)
BEGIN
    DECLARE @i INT = 6, @d DATE, @a INT, @w DECIMAL(5,2) = 92.40;
    WHILE @i >= 1
    BEGIN
        SET @d = DATEADD(WEEK, -@i, CAST(GETDATE() AS DATE));
        INSERT INTO Appointment (Patient_ID, Patient_FirstName, Patient_LastName, Service_ID, Service_Name, Date, Start_Time, End_Time, Status, Is_Paid)
        VALUES (@p1, 'Thandeka', 'Mkhize', @svc, @svcName, @d, '07:00', DATEADD(MINUTE, @dur, CAST('07:00' AS TIME)), 'Completed', 1);
        SET @a = SCOPE_IDENTITY();
        INSERT INTO Payment (Appointment_ID, Patient_ID, Patient_FirstName, Patient_LastName, Date, Service_ID, Service_Description, Amount)
        VALUES (@a, @p1, 'Thandeka', 'Mkhize', @d, @svc, @svcName, @price);
        INSERT INTO HealthMetrics (Appointment_ID, Patient_ID, Date_Recorded, Weight_kg, Abdominal_Circumference_cm, Height_cm, Blood_Pressure, Notes)
        VALUES (@a, @p1, @d, @w, 104 - (6 - @i) * 1.5, 165, '122/80', 'Weekly check-in');
        SET @w = @w - 1.15;  SET @i = @i - 1;
    END
    INSERT INTO Results (Appointment_ID, Patient_ID, Patient_FirstName, Patient_LastName, Result_Date, Service, Result, Notes)
    VALUES (@a, @p1, 'Thandeka', 'Mkhize', @d, @svcName, 'Lost 5.8 kg over 6 weeks', 'On track - continue weekly programme.');
END
COMMIT;
SELECT 'Demo data ready' AS Result;
