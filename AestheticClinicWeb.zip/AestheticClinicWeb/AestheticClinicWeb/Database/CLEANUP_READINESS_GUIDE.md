# When to Clean Up Patient Credentials

## Current State (After Migration)

? **Already Done:**
- Database migration script ran (06_Migrate_To_Unified_UserAccount.sql)
- All credentials are now in UserAccount table
- AccountRepository.cs code is working correctly
- Manage Accounts page works for all roles

?? **Still To Do:**
- Test all scenarios (see TESTING_CHECKLIST.md)
- Clean up Patient table credential columns (08_Cleanup_Old_Credentials.sql)

---

## Data Redundancy (Right Now)

**Patient table still has:**
- Password (2 patients have this)
- Is_First_Login
- Is_Account_Active
- Security_Question
- Security_Answer

**UserAccount table has:**
- Password (all patient credentials)
- Is_First_Login
- Is_Account_Active
- Security_Question
- Security_Answer
- Plus: AccountType, Staff_ID, Created_Date, Modified_Date

---

## Why Wait 1-2 Weeks?

1. **Time to find bugs** - If there's an issue with the new architecture, you'll discover it
2. **Backup in Patient table** - If something goes wrong, credentials are still there
3. **Failback option** - Can revert to using Patient table if needed
4. **Production confidence** - Staff and patients using system successfully

---

## When to Run Cleanup Script

**Wait until ALL of these are true:**

- ? Manage Accounts page works (it does now!)
- ? Patient login/registration works
- ? Doctor/Staff login works
- ? Password changes work
- ? Admin functions work (manage patient/staff accounts)
- ? No errors in web app logs for 1-2 weeks
- ? Multiple users have logged in successfully
- ? You've tested all roles

**Then:**

```sql
-- Run this script:
USE GroupWst6;
GO
-- Run file: 08_Cleanup_Old_Credentials.sql
```

---

## After Cleanup

**Patient table will only have:**
- Patient_ID
- First_Name, Last_Name
- ID_Number
- Gender, Date_Of_Birth
- Address, Contact_No
- Email (just for contact, not login)
- Allergies, Extra_Notes
- Is_Active (FES uses this for archiving)

**All login credentials moved to UserAccount:**
- Email (used for login)
- Password (PBKDF2 hash for web, plain for FES)
- Security_Question / Security_Answer
- Is_First_Login
- Is_Account_Active
- Plus metadata: Created_Date, Modified_Date

---

## Benefits After Cleanup

? **Cleaner architecture** - Credentials separate from patient data
? **Better security** - Easier to audit access, revoke credentials
? **GDPR compliance** - Easier to purge credentials without losing patient records
? **Reduced redundancy** - Single source of truth for credentials
? **Simpler schema** - Patient table is pure data
? **FES integration** - Existing FES queries still work (they list columns explicitly)

---

## Rollback Plan (If Needed)

If something goes wrong after cleanup and you need to rollback:

```sql
-- Re-run: 06_Migrate_To_Unified_UserAccount.sql
-- It will safely recreate the Patient columns
-- (but UserAccount is source of truth now, so manual sync needed)
```

Better to test thoroughly first!

---

## Current Testing Status

See: TESTING_CHECKLIST.md

Once you complete testing and mark items ?, you're ready for cleanup.
