# Code Changes Made - AccountRepository.cs

## What Was Changed

### 1. AddStaff() Method - FIXED ?

**BEFORE (Line 322-323):**
```csharp
INSERT INTO Staff (First_Name, Last_Name, Email, Password, Role, 
                   Security_Question, Security_Answer, Is_Active, Is_First_Login)
VALUES (@f,@l,@e,@p,@r,'unknown','unknown',1,1)
```
? Was trying to insert credentials into Staff table

**AFTER:**
```csharp
INSERT INTO Staff (First_Name, Last_Name, Email, Is_Active)
VALUES (@f, @l, @e, 1)
```
? Staff table only stores name and email
? Credentials go to UserAccount table only

---

### 2. Staff() Method - FIXED ?

**BEFORE (Line 302):**
```sql
SELECT ... s.Role ...
FROM UserAccount ua
JOIN Staff s
WHERE ... OR s.Role LIKE @like
```
? Was trying to read Role from Staff table

**AFTER:**
```sql
SELECT ... ua.Role ...
FROM UserAccount ua
JOIN Staff s
WHERE ... OR ua.Role LIKE @like
```
? Now reads Role from UserAccount (correct location)
? Staff list will now show correctly

---

### 3. UpdateStaff() Method - FIXED ?

**BEFORE:**
```csharp
// Tried to update Role in Staff table
Execute("UPDATE Staff SET ..., Role=@r WHERE Staff_ID=@i", ...)

// Then also updated Role in UserAccount
Execute("UPDATE UserAccount SET Email=@e, [Role]=@r WHERE Staff_ID=@i", ...)
```
? Was updating Role in both tables (confusing)

**AFTER:**
```csharp
// Update ONLY name and email in Staff table
Execute("UPDATE Staff SET First_Name=@f, Last_Name=@l, Email=@e WHERE Staff_ID=@i", ...)

// Update email and role in UserAccount (credentials location)
Execute("UPDATE UserAccount SET Email=@e, [Role]=@r WHERE Staff_ID=@i", ...)
```
? Clear separation: Staff table = info, UserAccount = credentials

---

## Why These Changes Were Needed

The application was **modified to use a unified credentials model** (everything in UserAccount), but some queries and inserts still referenced old credential columns in Staff/Patient tables.

The fixes ensure:
1. ? No more attempts to access non-existent columns
2. ? Staff list queries work
3. ? Adding new staff works
4. ? Editing staff works
5. ? All credentials in one place (UserAccount)

---

## Files Affected

- ? `AestheticClinicWeb\Data\AccountRepository.cs` - 3 methods fixed

---

## Compilation

? **Result:** Build successful (no compilation errors)

---

## Database Scripts Also Needed

After running the code changes, run these database scripts:
1. `Database/01_REMOVE_CREDENTIALS_FROM_PATIENT_STAFF.sql`
2. `Database/02_FIX_STAFF_TABLE_STRUCTURE.sql`

These will clean up the database schema to match the updated code.
