/* =====================================================================
   FINAL CLEANUP - Remove All Credential Columns from Patient & Staff

   This script removes all credential-related columns from Patient and Staff tables.
   All credentials are now EXCLUSIVELY in the UserAccount table.

   IMPORTANT: This assumes you have tested for 1-2 weeks and verified everything works.

   SAFE: Backup columns only (UserAccount has all active credentials)
   NO DATA LOSS: Credentials are all in UserAccount
   ===================================================================== */

USE [GroupWst6];
GO

PRINT '======================================================';
PRINT 'REMOVING CREDENTIAL COLUMNS FROM PATIENT & STAFF';
PRINT '======================================================';
PRINT '';
PRINT 'Starting cleanup at: ' + CAST(GETDATE() AS VARCHAR(30));
PRINT '';
PRINT 'IMPORTANT: This removes BACKUP columns only!';
PRINT 'All active credentials are in UserAccount table.';
PRINT '';

-- =====================================================================
-- PHASE 1: PRE-CLEANUP VERIFICATION
-- =====================================================================

PRINT '======================================================';
PRINT 'PHASE 1: PRE-CLEANUP VERIFICATION';
PRINT '======================================================';
PRINT '';

PRINT 'Verifying all credentials are in UserAccount:';
SELECT 
    'Staff in UserAccount' AS [Check],
    COUNT(*) AS [Count]
FROM UserAccount
WHERE AccountType = 'Staff'
UNION ALL
SELECT 
    'Patients in UserAccount',
    COUNT(*)
FROM UserAccount
WHERE AccountType = 'Patient';

GO

-- =====================================================================
-- PHASE 2: REMOVE PATIENT CREDENTIAL COLUMNS
-- =====================================================================

PRINT '';
PRINT '======================================================';
PRINT 'PHASE 2: REMOVING PATIENT CREDENTIAL COLUMNS';
PRINT '======================================================';
PRINT '';

BEGIN TRAN RemovePatientCreds
BEGIN TRY
    -- Drop Password column
    IF COL_LENGTH('dbo.Patient', 'Password') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN [Password];
        PRINT '? Dropped Patient.Password column';
    END
    ELSE
        PRINT '? Patient.Password already dropped or does not exist';

    -- Drop Is_First_Login column
    IF COL_LENGTH('dbo.Patient', 'Is_First_Login') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN Is_First_Login;
        PRINT '? Dropped Patient.Is_First_Login column';
    END
    ELSE
        PRINT '? Patient.Is_First_Login already dropped or does not exist';

    -- Drop Is_Account_Active column
    IF COL_LENGTH('dbo.Patient', 'Is_Account_Active') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN Is_Account_Active;
        PRINT '? Dropped Patient.Is_Account_Active column';
    END
    ELSE
        PRINT '? Patient.Is_Account_Active already dropped or does not exist';

    -- Drop Security_Question column
    IF COL_LENGTH('dbo.Patient', 'Security_Question') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN Security_Question;
        PRINT '? Dropped Patient.Security_Question column';
    END
    ELSE
        PRINT '? Patient.Security_Question already dropped or does not exist';

    -- Drop Security_Answer column
    IF COL_LENGTH('dbo.Patient', 'Security_Answer') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Patient DROP COLUMN Security_Answer;
        PRINT '? Dropped Patient.Security_Answer column';
    END
    ELSE
        PRINT '? Patient.Security_Answer already dropped or does not exist';

    COMMIT TRAN RemovePatientCreds;
    PRINT '';
    PRINT 'Patient credential columns removed successfully.';
END TRY
BEGIN CATCH
    ROLLBACK TRAN RemovePatientCreds;
    PRINT 'ERROR during Patient cleanup: ' + ERROR_MESSAGE();
    RAISERROR('Patient cleanup failed', 16, 1);
END CATCH

GO

-- =====================================================================
-- PHASE 3: REMOVE STAFF CREDENTIAL COLUMNS
-- =====================================================================

PRINT '';
PRINT '======================================================';
PRINT 'PHASE 3: REMOVING STAFF CREDENTIAL COLUMNS';
PRINT '======================================================';
PRINT '';

BEGIN TRAN RemoveStaffCreds
BEGIN TRY
    -- Drop Password column
    IF COL_LENGTH('dbo.Staff', 'Password') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN [Password];
        PRINT '? Dropped Staff.Password column';
    END
    ELSE
        PRINT '? Staff.Password already dropped or does not exist';

    -- Drop Is_First_Login column
    IF COL_LENGTH('dbo.Staff', 'Is_First_Login') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN Is_First_Login;
        PRINT '? Dropped Staff.Is_First_Login column';
    END
    ELSE
        PRINT '? Staff.Is_First_Login already dropped or does not exist';

    -- Drop Security_Question column
    IF COL_LENGTH('dbo.Staff', 'Security_Question') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN Security_Question;
        PRINT '? Dropped Staff.Security_Question column';
    END
    ELSE
        PRINT '? Staff.Security_Question already dropped or does not exist';

    -- Drop Security_Answer column
    IF COL_LENGTH('dbo.Staff', 'Security_Answer') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.Staff DROP COLUMN Security_Answer;
        PRINT '? Dropped Staff.Security_Answer column';
    END
    ELSE
        PRINT '? Staff.Security_Answer already dropped or does not exist';

    COMMIT TRAN RemoveStaffCreds;
    PRINT '';
    PRINT 'Staff credential columns removed successfully.';
END TRY
BEGIN CATCH
    ROLLBACK TRAN RemoveStaffCreds;
    PRINT 'ERROR during Staff cleanup: ' + ERROR_MESSAGE();
    RAISERROR('Staff cleanup failed', 16, 1);
END CATCH

GO

-- =====================================================================
-- PHASE 4: FINAL VERIFICATION
-- =====================================================================

PRINT '';
PRINT '======================================================';
PRINT 'PHASE 4: FINAL VERIFICATION';
PRINT '======================================================';
PRINT '';

PRINT 'Patient table final structure:';
SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'Patient'
ORDER BY ORDINAL_POSITION;

GO

PRINT '';
PRINT 'Staff table final structure:';
SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'Staff'
ORDER BY ORDINAL_POSITION;

GO

PRINT '';
PRINT 'UserAccount table structure (source of truth):';
SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'UserAccount'
ORDER BY ORDINAL_POSITION;

GO

-- =====================================================================
-- PHASE 5: SUMMARY
-- =====================================================================

PRINT '';
PRINT '======================================================';
PRINT 'CLEANUP COMPLETE';
PRINT '======================================================';
PRINT '';
PRINT 'Summary:';
PRINT '? All credential columns removed from Patient table';
PRINT '? All credential columns removed from Staff table';
PRINT '? UserAccount remains as single source of truth';
PRINT '? Data integrity maintained';
PRINT '';
PRINT 'Database is now fully optimized:';
PRINT '  - Patient table: Pure patient data only';
PRINT '  - Staff table: Pure staff data only';
PRINT '  - UserAccount table: All credentials (passwords, security Q&A)';
PRINT '';
PRINT 'Completed at: ' + CAST(GETDATE() AS VARCHAR(30));
PRINT '======================================================';
GO
