# Cleanup Command - Ready to Execute

When you're ready to remove the credential columns from the Patient table, run this:

## Prerequisites Check

Before running cleanup, verify these conditions:

```sql
-- Check 1: All patient credentials are in UserAccount
USE GroupWst6;
GO

SELECT 'Patient Credentials in UserAccount:' AS [Check];
SELECT COUNT(*) AS PatientCount FROM UserAccount WHERE AccountType = 'Patient';

-- Check 2: Verify how many are still in Patient table (they should match above)
SELECT 'Patient Credentials Still in Patient Table:' AS [Check];
SELECT COUNT(*) AS PatientCount FROM Patient WHERE [Password] IS NOT NULL;

-- These counts should be the same or Patient count should be 0
```

---

## Run the Cleanup Script

**When you're confident (after 1-2 weeks of testing):**

```powershell
# PowerShell command:
sqlcmd -S 146.230.177.46 -U GroupWst6 -P h2e8j -d GroupWst6 -i "C:\Users\Ashto\OneDrive\Desktop\ISTN3SI\AestheticClinicWeb_M4\AestheticClinicWeb\AestheticClinicWeb\Database\08_Cleanup_Old_Credentials.sql"
```

Or in SSMS:
1. Open `08_Cleanup_Old_Credentials.sql`
2. Execute (F5)

---

## What Gets Deleted

The script will drop these columns from the Patient table:

- ? Password
- ? Is_First_Login
- ? Is_Account_Active
- ? Security_Question
- ? Security_Answer

---

## After Cleanup

Verify the Patient table structure:

```sql
USE GroupWst6;
GO

SELECT COLUMN_NAME, DATA_TYPE 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'Patient' 
ORDER BY ORDINAL_POSITION;

-- Should NOT see: Password, Is_First_Login, Is_Account_Active, Security_Question, Security_Answer
```

---

## Current Status

?? **Current:** Migration complete, testing phase
?? **Next:** Complete testing checklist (TESTING_CHECKLIST.md)
?? **Then:** Wait 1-2 weeks
?? **Finally:** Run cleanup script (08_Cleanup_Old_Credentials.sql)

---

## Timeline

- ? Database migration: Complete
- ? Code fix (UserAccount_ID ? User_ID): Complete
- ? Testing: Start now (see TESTING_CHECKLIST.md)
- ? Wait 1-2 weeks: Monitor for issues
- ? Cleanup: Run 08_Cleanup_Old_Credentials.sql

**Do not rush cleanup.** The extra columns don't hurt, and having them as a backup is valuable during testing.
