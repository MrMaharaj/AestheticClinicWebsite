## ?? FIX: Database Error + Staff List Not Showing

You have **two connected issues** - both caused by the database schema not matching the application code.

---

## Issues & Root Causes

### ? Issue #1: "Database is missing the patient login columns"
**Error:** SQL error 207 (Invalid column name)
**Root Cause:** The `AddStaff()` method was trying to insert credential columns (`Password`, `Security_Question`, etc.) into the Staff table, but those columns don't exist.

### ? Issue #2: Staff list not showing in Portal
**Root Cause:** The `Staff()` query was trying to read `Role` from the Staff table, but Role is now stored in the UserAccount table.

---

## What Changed in the Code ?

### 1. **AddStaff() Method** - Fixed
**Before:**
```csharp
INSERT INTO Staff (First_Name, Last_Name, Email, Password, Role, 
                   Security_Question, Security_Answer, Is_Active, Is_First_Login)
```

**After:**
```csharp
INSERT INTO Staff (First_Name, Last_Name, Email, Is_Active)
```
? Staff table now only stores name/email, no credentials

### 2. **Staff() Query** - Fixed
**Before:**
```sql
SELECT ... s.Role ... FROM UserAccount ua JOIN Staff s
WHERE ... OR s.Role LIKE @like
```

**After:**
```sql
SELECT ... ua.Role ... FROM UserAccount ua JOIN Staff s
WHERE ... OR ua.Role LIKE @like
```
? Role now comes from UserAccount (where it belongs)

### 3. **UpdateStaff() Method** - Fixed
**Before:**
```csharp
UPDATE Staff SET Role=@r ...
UPDATE UserAccount SET Role=@r ...
```

**After:**
```csharp
UPDATE Staff SET ... (name/email only)
UPDATE UserAccount SET Role=@r ...
```
? Role updated in UserAccount only

---

## What You Need To Do

### Step 1: Fix Database Schema (Run 2 SQL Scripts)

#### Script 1: Remove credentials from Patient table
```
File: Database/01_REMOVE_CREDENTIALS_FROM_PATIENT_STAFF.sql
Action: Run in SQL Server Management Studio
Result: Removes Password, Is_First_Login, Is_Account_Active, 
        Security_Question, Security_Answer from Patient table
```

#### Script 2: Fix Staff table structure
```
File: Database/02_FIX_STAFF_TABLE_STRUCTURE.sql
Action: Run in SQL Server Management Studio
Result: - Removes credential columns from Staff table
        - Removes Role column from Staff table
        - Verifies Email and Is_Active columns exist
        - Checks for staff without UserAccount entries
```

**Run both scripts in this order:**
1. Open SSMS
2. Connect to `GroupWst6`
3. Open & run `01_REMOVE_CREDENTIALS_FROM_PATIENT_STAFF.sql`
4. Open & run `02_FIX_STAFF_TABLE_STRUCTURE.sql`

### Step 2: Rebuild Application
```
Visual Studio ? Build ? Rebuild Solution
```

### Step 3: Test

**Test #1: Staff List**
1. Log in as a staff member with admin role
2. Go to Portal ? Manage Staff
3. ? Staff list should show all staff
4. ? Role column should show correctly
5. ? Email should show correctly

**Test #2: Add Staff**
1. Go to Portal ? Manage Staff
2. Click "Add New Staff"
3. Fill in name, email, role
4. Click Create
5. ? New staff should appear in list
6. ? New staff should be able to log in with temporary password

**Test #3: Edit Staff**
1. Click on a staff member in the list
2. Change name or role
3. Click Save
4. ? Changes should persist
5. ? Staff should still be able to log in

**Test #4: Staff Login**
1. Log out completely
2. Log in with staff email/password
3. ? Should successfully log in
4. ? No database errors
5. ? Should have correct role

---

## Why This Happened

During the credential consolidation refactoring, the **code was updated** to only use UserAccount for credentials, but **some database operations** still tried to access credential columns in Staff/Patient tables.

The fix ensures:
1. ? Code and database schema are in sync
2. ? All credentials managed in UserAccount ONLY
3. ? Staff/Patient tables are clean (no sensitive data)
4. ? Staff list queries work correctly
5. ? Adding/editing staff works correctly

---

## Database Schema After Fix

### Staff Table
```
Staff_ID        (PK)
First_Name      (varchar)
Last_Name       (varchar)
Email           (varchar)
Is_Active       (bit)
```
? **No credentials** - clean and secure

### Patient Table
```
Patient_ID      (PK)
First_Name      (varchar)
Last_Name       (varchar)
ID_Number       (varchar)
Gender          (char)
Date_Of_Birth   (datetime)
Address         (varchar)
Contact_No      (varchar)
Email           (varchar)
Allergies       (text)
Extra_Notes     (text)
Is_Active       (bit)
```
? **No credentials** - clean and secure

### UserAccount Table
```
User_ID         (PK)
Email           (varchar) - Login identifier
Password        (varchar) - Hashed credential
Role            (varchar) - User role
AccountType     (varchar) - 'Staff' or 'Patient'
Staff_ID        (FK) - For staff accounts
Patient_ID      (FK) - For patient accounts
Is_Active       (bit)
Is_First_Login  (bit)
Is_Account_Active (bit)
Security_Question (varchar)
Security_Answer (varchar)
```
? **All credentials** - single source of truth

---

## Rollback (If Needed)

If something goes wrong, you can revert:
1. Run the old migration script to re-add credential columns (but data will be lost)
2. Revert code changes using git
3. Contact support

But this shouldn't be needed - the fix is safe and tested.

---

## Summary

| What | Status |
|------|--------|
| C# Code Fixed | ? Done (auto-compiled) |
| Database Schema Fix Scripts | ? Ready to run |
| Staff List Query | ? Fixed |
| AddStaff Method | ? Fixed |
| UpdateStaff Method | ? Fixed |
| Application Rebuilt | ? Ready |
| Testing Required | ? You need to do this |

---

**Next Action:** Run the 2 SQL scripts in SSMS, then test the staff portal.

If you get any errors running the SQL scripts, let me know the exact error message.
