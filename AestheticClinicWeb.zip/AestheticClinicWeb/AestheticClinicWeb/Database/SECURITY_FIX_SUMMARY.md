# Security Fix Summary: Unified Login Credentials

## Executive Summary

**Problem:** Login credentials were stored in two places:
- Staff passwords: `Staff` table
- Patient passwords: `Patient` table

This violates security best practices by mixing sensitive credentials with business data.

**Solution:** Centralize all credentials in a unified `UserAccount` table.

**Result:** Better security, access control, audit trail, and compliance.

---

## What Was Delivered

### 1. Database Migration Script
**File:** `06_Migrate_To_Unified_UserAccount.sql`

- Creates new `UserAccount` table with proper schema
- Automatically migrates existing patient credentials
- Includes validation queries to verify migration
- Safe to re-run (won't duplicate data)

**Key Design:**
```
UserAccount (
  UserAccount_ID PRIMARY KEY,
  Email UNIQUE,              -- Single login identifier
  Password,                  -- Hashed
  Role, AccountType,
  Patient_ID / Staff_ID,     -- FK to Patient or Staff
  Is_Active, Is_First_Login, Is_Account_Active,
  Security_Question, Security_Answer
)
```

### 2. Updated C# Code
**File:** `AccountRepository_Secure.cs`

Complete rewrite of `AccountRepository` to use unified table:

- `Login()` - Single query to UserAccount (instead of Staff + Patient)
- `RegisterPatient()` - Creates UserAccount entry (not Patient.Password)
- `SetPassword()` - Updates UserAccount (not Staff/Patient tables)
- `GetSecurityQuestion()` - Reads from UserAccount
- `CheckSecurityAnswer()` - Reads from UserAccount
- `IssueTempPassword()` - Creates/updates UserAccount
- Admin methods updated accordingly

**Benefits:**
- Single source of truth for credentials
- Easier to secure (credentials ? patient data)
- Cleaner code (no more "check Staff OR check Patient" logic)
- Easier to add features (MFA, OAuth, account lockout, etc.)

### 3. Cleanup Script
**File:** `08_Cleanup_Old_Credentials.sql`

Removes deprecated credential columns from Patient table:
- `Patient.Password`
- `Patient.Is_First_Login`
- `Patient.Is_Account_Active`
- `Patient.Security_Question`
- `Patient.Security_Answer`

(Run only after testing confirms new code works)

### 4. Documentation
**Files:** 
- `SECURITY_MIGRATION_GUIDE.md` - Technical overview
- `IMPLEMENTATION_STEPS.md` - Step-by-step guide

---

## Security Improvements

| Issue | Before | After |
|-------|--------|-------|
| **Credential Location** | Patient table + Staff table | UserAccount table only |
| **Data Sensitivity** | Credentials mixed with health data | Separated |
| **Access Control** | Can't restrict password changes without exposing full patient record | Can give limited access to credential management |
| **Audit Trail** | No central log | Can easily add login attempt logging |
| **Compliance (GDPR)** | Hard to purge credentials | Can delete old logins without deleting patient data |
| **Code Complexity** | "Check Staff OR check Patient" | Single query |
| **Scalability** | Hard to add MFA/OAuth | Straightforward to add new auth features |

---

## Architectural Changes

### Before
```
???????????????????              ????????????????????????
? Staff           ?              ? Patient              ?
???????????????????              ????????????????????????
? Email ???????   ?              ? Email ??????????    ?
? Password ???????????? LOGIN LOGIC ??????????????    ?
? Role        ?   ?              ? Password ???????    ?
?             ?   ?              ? Security_Question   ?
?             ?   ?              ? + Patient Data      ?
???????????????   ?              ????????????????????????
                  ?                         ?
                  ???????????????????????????
              Credentials scattered, hard to manage
```

### After
```
????????????????????????????????????????????
? UserAccount (Single Credential Store)    ?
????????????????????????????????????????????
? Email  ???? LOGIN LOGIC ?????????????    ?
? Password                                 ?
? Security_Question                        ?
? Staff_ID ??????????                      ?
? Patient_ID ??????????????????????        ?
????????????????????????????????????????????
                                   ?
                     ??????????????????????????
                     ?                        ?
        ?????????????????         ????????????????????????
        ? Staff         ?         ? Patient              ?
        ?????????????????         ????????????????????????
        ? Email         ?         ? Email                ?
        ? Name, Role    ?         ? Name, DOB            ?
        ? (no pwd)      ?         ? (health data)        ?
        ?               ?         ? (no credentials)     ?
        ?????????????????         ????????????????????????

Clean separation: Credentials ? Business Data
```

---

## Implementation Roadmap

### Phase 1: Deploy with Patient Credentials Only
1. Run `06_Migrate_To_Unified_UserAccount.sql`
2. Replace `AccountRepository.cs` with `AccountRepository_Secure.cs`
3. Test thoroughly (1-2 weeks)
4. Run `08_Cleanup_Old_Credentials.sql`

**Impact:** Patient credentials now centralized, FES continues working unchanged

### Phase 2: Future - Migrate Staff Credentials (After FES Retirement)
- Move `Staff.Password` ? `UserAccount`
- Staff table becomes pure data table
- Complete isolation of credentials from business data

### Phase 3: Enhanced Security Features
- Add account lockout after N failed attempts
- Add login attempt logging
- Add password expiry policies
- Add MFA support
- Add OAuth/SSO integration

---

## Data Integrity

### Relationships
- `UserAccount.Patient_ID` ? `Patient.Patient_ID` (1:1, optional)
- `UserAccount.Staff_ID` ? `Staff.Staff_ID` (1:1, optional)

### Constraints
- `Email` is UNIQUE (no duplicate logins)
- `Patient_ID` is UNIQUE (patient has at most 1 login)
- `Staff_ID` is UNIQUE (staff has at most 1 login)
- No CASCADE DELETE (historical data preserved)

### Validation
- `AccountType = 'Patient'` means `Patient_ID` is NOT NULL
- `AccountType = 'Staff'` means `Staff_ID` is NOT NULL
- At least one of `Patient_ID` or `Staff_ID` is NOT NULL

---

## Backward Compatibility

**During Transition:**
- Patient table keeps old Password columns (until cleanup)
- Staff table unchanged (FES can continue using)
- Code checks UserAccount first (new path)
- If UserAccount doesn't exist, can fall back to legacy (optional)

**No Breaking Changes:**
- Existing staff logins continue working
- Patient login endpoints unchanged
- API contracts unchanged
- Database views can be created for compatibility (if needed)

---

## Risk Mitigation

### Before Going Live

**Testing Checklist:**
- [ ] Patient registration ? creates UserAccount
- [ ] Patient login ? succeeds from UserAccount
- [ ] New patient password change ? updates UserAccount
- [ ] Forgot password ? reads from UserAccount
- [ ] Staff login ? still works (from Staff table or UserAccount)
- [ ] Admin account approval ? updates UserAccount
- [ ] Admin deactivate account ? updates UserAccount
- [ ] Admin reset password ? updates UserAccount
- [ ] No duplicate emails in UserAccount
- [ ] No orphaned UserAccount records

**Rollback Plan:**
- Don't run cleanup script (Step 4) until confident
- If issues arise: Revert code change, use original AccountRepository.cs
- Patient data is safe (credentials still in Patient table)

---

## Performance Impact

### Before
```
Login(email, password)
  - Query Staff table (10 records)
  - Query Patient table (100+ records with password)
  - Two separate queries, two indexes needed
```

### After
```
Login(email, password)
  - Query UserAccount table (single source)
  - Single query to indexed Email column
  - Can optimize with materialized view if needed
  - Could add index on (Email, AccountType)
```

**Expected:** Slight performance improvement (single query vs. two)

---

## Compliance & Security Standards

### Addressed
- ? **OWASP**: Credential storage best practices
- ? **GDPR**: Easier to purge credentials
- ? **PCI DSS**: Separation of sensitive data
- ? **SOC 2**: Centralized access logging capability
- ? **ISO 27001**: Data classification (credentials ? records)

### Future (Post-Migration)
- Account lockout policies
- Password expiry enforcement
- Login attempt logging/audit trail
- MFA support
- OAuth/SSO integration

---

## Files Included

1. **SQL Scripts:**
   - `06_Migrate_To_Unified_UserAccount.sql` - Main migration
   - `08_Cleanup_Old_Credentials.sql` - Remove legacy columns

2. **C# Code:**
   - `AccountRepository_Secure.cs` - Updated implementation

3. **Documentation:**
   - `SECURITY_MIGRATION_GUIDE.md` - Technical deep dive
   - `IMPLEMENTATION_STEPS.md` - Step-by-step instructions
   - This file - Executive summary

---

## Next Steps

1. **Review** this document and `SECURITY_MIGRATION_GUIDE.md` with your mentor
2. **Schedule** migration during maintenance window
3. **Run** Step 1: Database migration script
4. **Run** Step 2: Deploy new code
5. **Test** thoroughly using checklist in IMPLEMENTATION_STEPS.md
6. **Run** Step 3: Cleanup script (after 1-2 weeks)
7. **Monitor** logs for login errors

---

## Questions for Your Mentor

1. Should staff credentials also move to UserAccount now or later?
2. Should we add password expiry policies?
3. Should we implement account lockout?
4. Should we add login attempt audit logging?
5. Timeline for FES retirement (affects staff password strategy)?
