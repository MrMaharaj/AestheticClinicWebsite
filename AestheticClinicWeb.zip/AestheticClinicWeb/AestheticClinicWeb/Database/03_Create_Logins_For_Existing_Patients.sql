/* =====================================================================
   STEP 3 - Give every existing patient an online account.
   For active patients with no Password yet and a usable, unique email:
     Password = random temporary password, Is_First_Login = 1, Is_Account_Active = 1.
   The result list (name, email, temporary password) is what you email to each patient.
   On first website login they must create their own password (stored hashed).
   Patients that can't get an account are listed with the reason - fix them in the FES and re-run.

   HOW TO RUN: @Apply = 0 shows who WOULD get an account. Set @Apply = 1 to create them.
   Safe to re-run: patients who already have a password are skipped.
   ===================================================================== */
USE [GroupWst6];
SET NOCOUNT ON;
DECLARE @Apply BIT = 0;          -- <<< change to 1 to create the accounts

IF OBJECT_ID('tempdb..#c') IS NOT NULL DROP TABLE #c;

SELECT p.Patient_ID, p.First_Name, p.Last_Name, LTRIM(RTRIM(p.Email)) AS Email,
       Reason = CASE
            WHEN p.Is_Active = 0 THEN 'Archived patient'
            WHEN p.Email IS NULL OR p.Email NOT LIKE '%_@_%._%' OR p.Email LIKE '% %' THEN 'No valid email'
            WHEN (SELECT COUNT(*) FROM dbo.Patient x WHERE x.Email = p.Email) > 1 THEN 'Email shared with another patient'
            WHEN EXISTS (SELECT 1 FROM dbo.Staff s WHERE s.Email = p.Email) THEN 'Email belongs to a staff login'
            ELSE '' END,
       -- e.g. Af3b9c27!  (upper, lower, digits, symbol)
       TempPassword = 'Af' + LOWER(LEFT(REPLACE(CONVERT(VARCHAR(36), NEWID()), '-', ''), 4))
                    + RIGHT('0' + CAST(ABS(CHECKSUM(NEWID())) % 100 AS VARCHAR(2)), 2) + '!'
INTO #c
FROM dbo.Patient p
WHERE p.[Password] IS NULL;

SELECT Patient_ID, First_Name, Last_Name, Email, Reason AS Cannot_Create_Because
FROM #c WHERE Reason <> '' ORDER BY Patient_ID;

IF @Apply = 1
BEGIN
    BEGIN TRAN;
    UPDATE p SET p.[Password] = c.TempPassword, p.Is_First_Login = 1, p.Is_Account_Active = 1
    FROM dbo.Patient p JOIN #c c ON c.Patient_ID = p.Patient_ID
    WHERE c.Reason = '' AND p.[Password] IS NULL;
    COMMIT;
    -- EMAIL THESE to the patients (keep this list private, then close the query window)
    SELECT Patient_ID, First_Name + ' ' + Last_Name AS Patient, Email AS Login_Email, TempPassword AS Temporary_Password
    FROM #c WHERE Reason = '' ORDER BY Patient_ID;
END
ELSE
    SELECT Patient_ID, First_Name + ' ' + Last_Name AS Patient, Email AS Would_Get_Account
    FROM #c WHERE Reason = '' ORDER BY Patient_ID;
