<%@ Page Title="Help & FAQ" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="Help.aspx.cs" Inherits="AestheticClinicWeb.Help" %>

<asp:Content ID="c1" ContentPlaceHolderID="MainContent" runat="server">
    <section class="hero" style="padding:56px 0;">
        <div class="container">
            <h1>Help &amp; FAQ</h1>
            <p>Quick answers on using the website. Can't find it? Ask our assistant &mdash; the &#128172; Help button is on every page.</p>
            <div class="cta"><button type="button" class="btn btn-primary" onclick="window.openHelpBot && openHelpBot()">Ask the assistant</button></div>
        </div>
    </section>

    <section>
        <div class="container narrow">
            <h2 class="h-sec">For patients</h2>
            <details class="faq" open><summary>How do I register?</summary>
                <p>Click <a href="<%= ResolveUrl("~/Account/Register.aspx") %>">Register</a>. Enter your name and South African ID number exactly as on your ID &mdash;
                   your date of birth and gender are filled in from the ID automatically. Choose a strong password and a security question
                   (used if you forget your password). If you have visited us before, your web account is linked to your existing clinic record.
                   New accounts are activated by the clinic, usually within one working day.</p></details>
            <details class="faq"><summary>How do I book an appointment?</summary>
                <p>Log in, open <strong>Book Appointment</strong>, choose a treatment and a date. Only time slots that are still free are shown, so
                   there is no risk of a double booking. Click a time, review the summary and press <strong>Confirm booking</strong>. A confirmation
                   page opens that you can print or save as PDF.</p></details>
            <details class="faq"><summary>Can I cancel or move an appointment?</summary>
                <p>Yes &mdash; under <strong>My Appointments</strong>, click <strong>Cancel</strong> next to a booked appointment, up to
                   <%= CancelHours %> hours before it starts. To move an appointment, cancel it and book a new slot. Inside <%= CancelHours %> hours, please phone us.</p></details>
            <details class="faq"><summary>Where do I see my results and progress?</summary>
                <p><strong>My Progress &amp; Results</strong> shows the before/after photos, treatment results and measurements (weight, abdominal
                   circumference, BMI, blood pressure) captured by your practitioner.</p></details>
            <details class="faq"><summary>How do I get an invoice or receipt?</summary>
                <p><strong>Invoices &amp; Receipts</strong> lists your outstanding balances and all payments. Click <strong>Receipt</strong> to open a
                   printable receipt.</p></details>
            <details class="faq"><summary>How do I update my contact details?</summary>
                <p>Open <strong>My Profile</strong>. You can change your address, phone number, email and allergies. Name and ID number changes must
                   be done by reception for security reasons.</p></details>
            <details class="faq"><summary>I forgot my password</summary>
                <p>Use <a href="<%= ResolveUrl("~/Account/ForgotPassword.aspx") %>">Forgot password</a>: enter your email, answer your security question and
                   set a new password. After 5 wrong attempts, login is locked for 5 minutes to protect your account.</p></details>

            <h2 class="h-sec">For clinic staff</h2>
            <details class="faq"><summary>Is the website linked to the desktop (front-end) system?</summary>
                <p>Yes. The website and the front-end system share one SQL Server database. A patient, appointment or payment captured in either
                   system appears in the other immediately &mdash; just refresh the screen.</p></details>
            <details class="faq"><summary>How do I book for a walk-in or phone patient?</summary>
                <p><strong>Appointments</strong> &rarr; select the patient, treatment and date &rarr; pick a free slot &rarr; <strong>Book</strong>.
                   Add new patients first under <strong>Patients</strong>.</p></details>
            <details class="faq"><summary>How do I record a payment?</summary>
                <p><strong>Payments &amp; Invoices</strong> lists unpaid appointments. Click <strong>Record payment</strong>; the amount defaults to the
                   treatment price. The appointment is marked as paid and a printable receipt is available.</p></details>
            <details class="faq"><summary>Where are the business reports?</summary>
                <p><strong>BI Reports</strong> offers 9 reports covering revenue, treatment mix, cancellations, peak times, top patients, retention,
                   debtors and patient progress. Choose a date range, then view as a table or chart, export to Excel, or print / save as PDF.</p></details>
            <details class="faq"><summary>Who can manage staff accounts and prices?</summary>
                <p>Only managers/administrators. They can add staff (who must set their own password on first login), deactivate accounts,
                   approve patient web accounts and change treatment prices.</p></details>
        </div>
    </section>
</asp:Content>
