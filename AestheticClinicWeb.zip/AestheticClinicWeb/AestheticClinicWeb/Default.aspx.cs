using System;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;

namespace AestheticClinicWeb
{
    public partial class Default : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            try
            {
                var dt = ServiceRepository.Popular(3);
                rptPopular.DataSource = dt; rptPopular.DataBind();
                phFallback.Visible = dt.Rows.Count == 0;
            }
            catch (Exception ex)
            {
                // Public page must never break: show static content if the DB is unreachable.
                ErrorLog.Write(ex);
                phFallback.Visible = true;
            }
        }
    }
}
