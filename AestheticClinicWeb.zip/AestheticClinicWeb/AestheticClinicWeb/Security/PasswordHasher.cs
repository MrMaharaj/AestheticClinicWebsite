using System;
using System.Security.Cryptography;

namespace AestheticClinicWeb.Security
{
    /// <summary>
    /// PBKDF2 password hashing. Format: PBKDF2$iterations$saltBase64$hashBase64.
    /// Verify() also accepts legacy plain-text values (as written by the Front-End System),
    /// so existing FES accounts keep working on the website.
    /// </summary>
    public static class PasswordHasher
    {
        const string Prefix = "PBKDF2$";
        const int Iterations = 10000;

        public static string Hash(string password)
        {
            var salt = new byte[16];
            using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(salt);
            using (var kdf = new Rfc2898DeriveBytes(password, salt, Iterations))
            {
                return Prefix + Iterations + "$" + Convert.ToBase64String(salt) + "$" +
                       Convert.ToBase64String(kdf.GetBytes(32));
            }
        }

        public static bool IsHashed(string stored)
        {
            return stored != null && stored.StartsWith(Prefix, StringComparison.Ordinal);
        }

        public static bool Verify(string password, string stored)
        {
            if (password == null || string.IsNullOrEmpty(stored)) return false;
            if (!IsHashed(stored)) return SlowEquals(password, stored.TrimEnd()); // legacy plain text

            var parts = stored.Split('$');
            if (parts.Length != 4) return false;
            int iter;
            if (!int.TryParse(parts[1], out iter)) return false;
            try
            {
                var salt = Convert.FromBase64String(parts[2]);
                var expected = Convert.FromBase64String(parts[3]);
                using (var kdf = new Rfc2898DeriveBytes(password, salt, iter))
                {
                    var actual = kdf.GetBytes(expected.Length);
                    int diff = 0;
                    for (int i = 0; i < expected.Length; i++) diff |= expected[i] ^ actual[i];
                    return diff == 0;
                }
            }
            catch (FormatException) { return false; }
        }

        /// <summary>Value to store for a new password, honouring Accounts:HashPasswords.</summary>
        public static string ForStorage(string password)
        {
            return Helpers.ClinicSettings.HashPasswords ? Hash(password) : password;
        }

        static bool SlowEquals(string a, string b)
        {
            int diff = a.Length ^ b.Length;
            for (int i = 0; i < a.Length && i < b.Length; i++) diff |= a[i] ^ b[i];
            return diff == 0;
        }

        /// <summary>Same rule as the desktop app: 8+ chars, upper, digit, special.</summary>
        public static bool IsStrong(string password)
        {
            if (string.IsNullOrEmpty(password) || password.Length < 8) return false;
            bool up = false, dig = false, sp = false;
            foreach (char c in password)
            {
                if (char.IsUpper(c)) up = true;
                else if (char.IsDigit(c)) dig = true;
                else if (!char.IsLetterOrDigit(c)) sp = true;
            }
            return up && dig && sp;
        }

        public const string StrengthMessage =
            "Password must be at least 8 characters and contain an uppercase letter, a number and a special character.";
    }
}
