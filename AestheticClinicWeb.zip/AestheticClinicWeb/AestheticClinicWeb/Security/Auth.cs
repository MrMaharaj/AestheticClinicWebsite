using System;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Caching;
using System.Web.Security;
using AestheticClinicWeb.Helpers;

namespace AestheticClinicWeb.Security
{
    public enum AccountKind { Staff, Patient }

    /// <summary>The logged-in user, rebuilt from the encrypted Forms-auth ticket on every request.</summary>
    public class ClinicIdentity
    {
        public AccountKind Kind;
        public int AccountId;      // Staff_ID, or Patient_ID for patients
        public int PatientId;      // Patient_ID (patients only)
        public string Email;
        public string FullName;
        public string DbRole;      // raw Role column value
        public bool IsAdmin;
        public bool MustChangePassword;
    }

    public static class Auth
    {
        // Ticket UserData: kind|accountId|patientId|dbRole|isAdmin|fullName|mustChange
        public static void SignIn(ClinicIdentity id)
        {
            string data = string.Join("|", new[] {
                id.Kind.ToString(), id.AccountId.ToString(), id.PatientId.ToString(),
                Clean(id.DbRole), id.IsAdmin ? "1" : "0", Clean(id.FullName), id.MustChangePassword ? "1" : "0" });

            var ticket = new FormsAuthenticationTicket(2, id.Email, DateTime.Now,
                DateTime.Now.Add(FormsAuthentication.Timeout), false, data, FormsAuthentication.FormsCookiePath);
            var cookie = new HttpCookie(FormsAuthentication.FormsCookieName, FormsAuthentication.Encrypt(ticket))
            {
                HttpOnly = true,
                Secure = FormsAuthentication.RequireSSL || HttpContext.Current.Request.IsSecureConnection,
                Path = FormsAuthentication.FormsCookiePath
            };
            HttpContext.Current.Response.Cookies.Add(cookie);
        }

        static string Clean(string s) { return (s ?? "").Replace("|", " ").Trim(); }

        public static void SignOut()
        {
            FormsAuthentication.SignOut();
            var ctx = HttpContext.Current;
            if (ctx.Session != null) { ctx.Session.Clear(); ctx.Session.Abandon(); }
        }

        /// <summary>Called from Global.asax: attaches roles (Staff/Admin/Patient) to the request.</summary>
        public static void AttachPrincipal(HttpContext ctx)
        {
            var fid = ctx.User == null ? null : ctx.User.Identity as FormsIdentity;
            if (fid == null || !fid.IsAuthenticated) return;
            var id = Parse(fid.Ticket);
            if (id == null) return;

            string[] roles = id.Kind == AccountKind.Patient
                ? new[] { "Patient" }
                : (id.IsAdmin ? new[] { "Staff", "Admin" } : new[] { "Staff" });
            ctx.User = new GenericPrincipal(fid, roles);
            ctx.Items["ClinicIdentity"] = id;
        }

        static ClinicIdentity Parse(FormsAuthenticationTicket t)
        {
            var p = (t.UserData ?? "").Split('|');
            if (p.Length < 7) return null;
            AccountKind kind;
            if (!Enum.TryParse(p[0], out kind)) return null;
            int acc, pat;
            int.TryParse(p[1], out acc); int.TryParse(p[2], out pat);
            return new ClinicIdentity
            {
                Kind = kind, AccountId = acc, PatientId = pat, DbRole = p[3],
                IsAdmin = p[4] == "1", FullName = p[5], MustChangePassword = p[6] == "1", Email = t.Name
            };
        }

        public static ClinicIdentity Current
        {
            get { var c = HttpContext.Current; return c == null ? null : c.Items["ClinicIdentity"] as ClinicIdentity; }
        }

        public static bool IsStaff { get { var c = Current; return c != null && c.Kind == AccountKind.Staff; } }
        public static bool IsPatient { get { var c = Current; return c != null && c.Kind == AccountKind.Patient; } }
        public static bool IsAdmin { get { var c = Current; return c != null && c.IsAdmin; } }

        public static bool IsAdminRole(string dbRole)
        {
            return ClinicSettings.AdminRoles.Any(r => string.Equals(r, (dbRole ?? "").Trim(), StringComparison.OrdinalIgnoreCase));
        }

        // ---------- brute-force protection: 5 failures => 5 minute lock per email ----------
        const int MaxAttempts = 5;
        static readonly TimeSpan LockTime = TimeSpan.FromMinutes(5);

        public static bool IsLockedOut(string email)
        {
            var n = HttpRuntime.Cache["login:" + (email ?? "").ToLowerInvariant()] as int?;
            return n.HasValue && n.Value >= MaxAttempts;
        }

        public static void RegisterFailure(string email)
        {
            string key = "login:" + (email ?? "").ToLowerInvariant();
            int n = (HttpRuntime.Cache[key] as int?) ?? 0;
            HttpRuntime.Cache.Insert(key, n + 1, null, DateTime.UtcNow.Add(LockTime), Cache.NoSlidingExpiration);
        }

        public static void ClearFailures(string email)
        {
            HttpRuntime.Cache.Remove("login:" + (email ?? "").ToLowerInvariant());
        }
    }
}
