using System;
using System.Web.UI.WebControls;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;
using AestheticClinicWeb.Security;

namespace AestheticClinicWeb
{
    public partial class Services : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            Safe(lblMsg, () =>
            {
                ddlCategory.Items.Clear();
                ddlCategory.Items.Add(new ListItem("All categories", ""));
                foreach (System.Data.DataRow r in ServiceRepository.Categories().Rows)
                    ddlCategory.Items.Add(Convert.ToString(r["Category"]));
            });
            Bind();
        }

        protected void Filter_Changed(object sender, EventArgs e) { Bind(); }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtSearch.Text = ""; if (ddlCategory.Items.Count > 0) ddlCategory.SelectedIndex = 0; Bind();
        }

        void Bind()
        {
            Safe(lblMsg, () =>
            {
                var dt = ServiceRepository.All(ddlCategory.SelectedValue, txtSearch.Text);
                rptServices.DataSource = dt; rptServices.DataBind();
                phEmpty.Visible = dt.Rows.Count == 0;
                litCount.Text = "<p class=\"hint\">" + dt.Rows.Count + " treatment(s) shown.</p>";
            });
        }

        protected string BookUrl(object serviceId)
        {
            if (Auth.IsPatient) return ResolveUrl("~/Patient/Book.aspx?service=" + serviceId);
            if (Auth.IsStaff) return ResolveUrl("~/Portal/Appointments.aspx");
            return ResolveUrl("~/Account/Login.aspx?ReturnUrl=" + Server.UrlEncode(ResolveUrl("~/Patient/Book.aspx?service=" + serviceId)));
        }
    }
}
