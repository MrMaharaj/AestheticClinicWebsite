using System;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;
using AestheticClinicWeb.Security;

namespace AestheticClinicWeb.Print
{
    public partial class Appointment : BasePage
    {
        protected string BackUrl { get { return ResolveUrl(Auth.IsPatient ? "~/Patient/Appointments.aspx" : "~/Portal/Appointments.aspx"); } }

        protected void Page_Load(object sender, EventArgs e)
        {
            int id = QueryInt("id");
            Safe(lblMsg, () =>
            {
                var a = AppointmentRepository.Get(id);
                // Authorisation: a patient may only see their own appointment.
                if (a == null || (Auth.IsPatient && Db.I(a, "Patient_ID") != Auth.Current.PatientId))
                {
                    pnlDoc.Visible = false; Fail(lblMsg, "Appointment not found."); return;
                }
                phNew.Visible = Request.QueryString["new"] == "1";
                litId.Text = id.ToString("00000");
                litPatient.Text = Server.HtmlEncode(Db.S(a, "Patient_FirstName") + " " + Db.S(a, "Patient_LastName") + " (Patient #" + Db.I(a, "Patient_ID") + ")");
                litService.Text = Server.HtmlEncode(Db.S(a, "Service_Name"));
                litDate.Text = Ui.LongDate(a["Date"]);
                litTime.Text = Ui.Time(a["Start_Time"]) + " &ndash; " + Ui.Time(a["End_Time"]);
                litPrice.Text = Ui.Money(a["Price"]);
                litStatus.Text = Ui.StatusPill(a["Status"]);
                litPaid.Text = Ui.PaidPill(a["Is_Paid"]);
            });
        }
    }
}
