<%@ Page Title="Receipt" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="Receipt.aspx.cs" Inherits="AestheticClinicWeb.Print.Receipt" %>
<asp:Content ID="c1" ContentPlaceHolderID="MainContent" runat="server">
    <section class="print-page">
        <div class="container narrow">
            <asp:Label ID="lblMsg" runat="server" Visible="false" />
            <asp:Panel ID="pnlDoc" runat="server" CssClass="doc">
                <div class="doc-head">
                    <div><span class="mark">A</span> <strong>AestheticFlow</strong><br /><small>Newlands City Shopping Centre, Durban &middot; +27 31 260 8124</small></div>
                    <div class="doc-title">RECEIPT<br /><small>#<asp:Literal ID="litNo" runat="server" /></small></div>
                </div>
                <div class="grid grid-2">
                    <dl class="kv">
                        <dt>Received from</dt><dd><asp:Literal ID="litPatient" runat="server" /></dd>
                        <dt>Patient #</dt><dd><asp:Literal ID="litPid" runat="server" /></dd>
                        <dt>Contact</dt><dd><asp:Literal ID="litContact" runat="server" /></dd>
                    </dl>
                    <dl class="kv">
                        <dt>Payment date</dt><dd><asp:Literal ID="litDate" runat="server" /></dd>
                        <dt>Appointment</dt><dd>APT-<asp:Literal ID="litAppt" runat="server" /></dd>
                        <dt>Visit date</dt><dd><asp:Literal ID="litVisit" runat="server" /></dd>
                    </dl>
                </div>
                <table class="data">
                    <thead><tr><th>Description</th><th style="text-align:right;">Amount</th></tr></thead>
                    <tbody><tr><td><asp:Literal ID="litDesc" runat="server" /></td><td style="text-align:right;"><asp:Literal ID="litAmt" runat="server" /></td></tr></tbody>
                    <tfoot><tr><th>Total paid</th><th style="text-align:right;"><asp:Literal ID="litTotal" runat="server" /></th></tr></tfoot>
                </table>
                <p class="hint" style="margin-top:14px;">Thank you for choosing AestheticFlow. Printed <%= DateTime.Now.ToString("yyyy-MM-dd HH:mm") %>.</p>
            </asp:Panel>
            <div class="toolbar no-print" style="margin-top:18px;">
                <button type="button" class="btn btn-primary" onclick="window.print()">&#128424; Print / Save as PDF</button>
                <a class="btn btn-outline" href="<%= BackUrl %>">Back</a>
            </div>
        </div>
    </section>
</asp:Content>
