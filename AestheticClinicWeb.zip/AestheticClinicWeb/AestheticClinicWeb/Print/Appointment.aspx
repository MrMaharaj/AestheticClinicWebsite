<%@ Page Title="Appointment Confirmation" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="Appointment.aspx.cs" Inherits="AestheticClinicWeb.Print.Appointment" %>
<asp:Content ID="c1" ContentPlaceHolderID="MainContent" runat="server">
    <section class="print-page">
        <div class="container narrow">
            <asp:Label ID="lblMsg" runat="server" Visible="false" />
            <asp:Panel ID="pnlDoc" runat="server" CssClass="doc">
                <asp:PlaceHolder ID="phNew" runat="server" Visible="false">
                    <div class="msg msg-ok no-print">&#10004; Your appointment is booked and saved. It is now visible to the clinic's staff system.</div>
                </asp:PlaceHolder>
                <div class="doc-head">
                    <div><span class="mark">A</span> <strong>AestheticFlow</strong><br /><small>Newlands City Shopping Centre, Durban &middot; +27 31 260 8124</small></div>
                    <div class="doc-title">APPOINTMENT<br />CONFIRMATION</div>
                </div>
                <dl class="kv big">
                    <dt>Reference</dt><dd>APT-<asp:Literal ID="litId" runat="server" /></dd>
                    <dt>Patient</dt><dd><asp:Literal ID="litPatient" runat="server" /></dd>
                    <dt>Treatment</dt><dd><asp:Literal ID="litService" runat="server" /></dd>
                    <dt>Date</dt><dd><asp:Literal ID="litDate" runat="server" /></dd>
                    <dt>Time</dt><dd><asp:Literal ID="litTime" runat="server" /></dd>
                    <dt>Price</dt><dd><asp:Literal ID="litPrice" runat="server" /></dd>
                    <dt>Status</dt><dd><asp:Literal ID="litStatus" runat="server" /></dd>
                    <dt>Payment</dt><dd><asp:Literal ID="litPaid" runat="server" /></dd>
                </dl>
                <p class="hint">Please arrive 10 minutes early and bring your ID. Cancellations: at least <%= ClinicSettings.MinHoursNoticeToCancel %> hours' notice.</p>
                <p class="hint">Printed <%= DateTime.Now.ToString("yyyy-MM-dd HH:mm") %></p>
            </asp:Panel>
            <div class="toolbar no-print" style="margin-top:18px;">
                <button type="button" class="btn btn-primary" onclick="window.print()">&#128424; Print / Save as PDF</button>
                <a class="btn btn-outline" href="<%= BackUrl %>">Back</a>
            </div>
        </div>
    </section>
</asp:Content>
