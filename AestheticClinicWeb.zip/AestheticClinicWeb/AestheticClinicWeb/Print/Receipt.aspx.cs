using System;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;
using AestheticClinicWeb.Security;

namespace AestheticClinicWeb.Print
{
    public partial class Receipt : BasePage
    {
        protected string BackUrl { get { return ResolveUrl(Auth.IsPatient ? "~/Patient/Invoices.aspx" : "~/Portal/Invoices.aspx"); } }

        protected void Page_Load(object sender, EventArgs e)
        {
            int id = QueryInt("id");
            Safe(lblMsg, () =>
            {
                var p = PaymentRepository.Get(id);
                if (p == null || (Auth.IsPatient && Db.I(p, "Patient_ID") != Auth.Current.PatientId))
                {
                    pnlDoc.Visible = false; Fail(lblMsg, "Receipt not found."); return;
                }
                litNo.Text = id.ToString("00000");
                litPatient.Text = Server.HtmlEncode(Db.S(p, "Patient_FirstName") + " " + Db.S(p, "Patient_LastName"));
                litPid.Text = Db.I(p, "Patient_ID").ToString();
                litContact.Text = Server.HtmlEncode(Db.S(p, "Contact_No") + " / " + Db.S(p, "Email"));
                litDate.Text = Ui.Date(p["Date"]);
                litAppt.Text = Db.I(p, "Appointment_ID").ToString("00000");
                litVisit.Text = Ui.Date(p["Appointment_Date"]) + " " + Ui.Time(p["Start_Time"]);
                litDesc.Text = Server.HtmlEncode(Db.S(p, "Service_Description"));
                litAmt.Text = litTotal.Text = Ui.Money(p["Amount"]);
            });
        }
    }
}
