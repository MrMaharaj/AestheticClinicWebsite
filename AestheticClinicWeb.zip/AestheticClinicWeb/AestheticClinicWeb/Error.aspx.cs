using System;

namespace AestheticClinicWeb
{
    public partial class ErrorPage : System.Web.UI.Page
    {
        protected string Heading = "Sorry, something went wrong";
        protected string Detail = "The problem has been logged. Your data is safe - please try again.";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["code"] == "404")
            {
                Response.StatusCode = 404;
                Heading = "Page not found";
                Detail = "The page you are looking for does not exist or has moved.";
            }
            else Response.StatusCode = 500;
            Response.TrySkipIisCustomErrors = true;
        }
    }
}
