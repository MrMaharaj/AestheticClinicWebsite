/* AestheticFlow help assistant - tiny vanilla JS widget (no libraries, ~2 KB) */
(function () {
    var toggle = document.getElementById('hb-toggle');
    if (!toggle) return;
    var panel = document.getElementById('hb-panel'), log = document.getElementById('hb-log'),
        text = document.getElementById('hb-text'), started = false;

    function add(who, msg, links) {
        var d = document.createElement('div');
        d.className = 'hb-msg ' + who;
        d.textContent = msg;
        (links || []).forEach(function (l) {
            var a = document.createElement('a');
            a.href = l.url; a.textContent = l.text + ' \u2192'; a.className = 'hb-link';
            d.appendChild(document.createElement('br')); d.appendChild(a);
        });
        log.appendChild(d); log.scrollTop = log.scrollHeight;
    }
    function open(show) {
        panel.hidden = !show; toggle.setAttribute('aria-expanded', show);
        if (show && !started) { started = true; add('bot', 'Hi! I\u2019m the AestheticFlow assistant. Ask me about bookings, prices, hours, results or your account.'); }
        if (show) text.focus();
    }
    function ask(q) {
        q = (q || '').trim(); if (!q) return;
        add('me', q); text.value = '';
        var x = new XMLHttpRequest();
        x.open('POST', window.HELPBOT_URL, true);
        x.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        x.onload = function () {
            try { var r = JSON.parse(x.responseText); add('bot', r.reply, r.links); }
            catch (e) { add('bot', 'Sorry, I could not answer right now. Please see the Help page.'); }
        };
        x.onerror = function () { add('bot', 'Connection problem - please try again.'); };
        x.send('q=' + encodeURIComponent(q));
    }
    toggle.addEventListener('click', function () { open(panel.hidden); });
    document.getElementById('hb-close').addEventListener('click', function () { open(false); });
    document.getElementById('hb-send').addEventListener('click', function () { ask(text.value); });
    text.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); ask(text.value); } });
    Array.prototype.forEach.call(document.querySelectorAll('.hb-quick button'), function (b) {
        b.addEventListener('click', function () { ask(b.getAttribute('data-q')); });
    });
    window.openHelpBot = function (q) { open(true); if (q) ask(q); };
})();
