<%@ Application Codebehind="Global.asax.cs" Inherits="AestheticClinicWeb.Global" Language="C#" %>
