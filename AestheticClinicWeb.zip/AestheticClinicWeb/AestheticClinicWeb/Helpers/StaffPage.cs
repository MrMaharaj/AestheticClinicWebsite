using System;
using AestheticClinicWeb.Security;

namespace AestheticClinicWeb.Helpers
{
    /// <summary>
    /// Base for /Portal pages (staff only with optional role restrictions).
    /// 
    /// Usage:
    ///   1. For Doctor-only pages:
    ///      public partial class ManageStaff : StaffPage { 
    ///          protected override string[] RequiredRoles => new[] { "Doctor", "Admin" };
    ///      }
    /// 
    ///   2. For pages accessible to multiple roles:
    ///      public partial class Appointments : StaffPage {
    ///          protected override string[] RequiredRoles => new[] { "Doctor", "Receptionist", "Therapist" };
    ///      }
    /// 
    ///   3. For any staff (default):
    ///      public partial class Dashboard : StaffPage {
    ///          // RequiredRoles defaults to null (any staff member)
    ///      }
    /// </summary>
    public class StaffPage : BasePage
    {
        /// <summary>
        /// Override this property to require specific roles.
        /// Return null to allow any staff member.
        /// Example: new[] { "Doctor", "Receptionist" }
        /// </summary>
        protected virtual string[] RequiredRoles { get { return null; } }

        /// <summary>
        /// Override this property to require admin role.
        /// This is a shortcut for RequiredRoles = new[] { "Doctor", "Admin" }
        /// </summary>
        protected virtual bool AdminOnly { get { return false; } }

        protected override void OnInit(EventArgs e)
        {
            // Check: User must be staff
            if (!Auth.IsStaff)
            {
                Response.Redirect("~/Account/Login.aspx", true);
                return;
            }

            // Check: If AdminOnly is true, require admin role
            if (AdminOnly && !Auth.IsAdmin)
            {
                Response.Redirect("~/Account/Login.aspx", true);
                return;
            }

            // Check: If specific roles required, verify user has one
            if (RequiredRoles != null && RequiredRoles.Length > 0)
            {
                if (!RoleBasedAccess.HasRole(RequiredRoles))
                {
                    // Access denied - log and redirect
                    RoleBasedAccess.LogAccess("StaffPage", "Init", false);
                    Response.Redirect("~/Account/Login.aspx", true);
                    return;
                }
            }

            base.OnInit(e);
        }
    }
}
