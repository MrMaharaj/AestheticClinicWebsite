using System;
using System.Linq;
using AestheticClinicWeb.Security;

namespace AestheticClinicWeb.Helpers
{
    /// <summary>
    /// ROLE-BASED ACCESS CONTROL (RBAC)
    /// 
    /// This class provides role-specific access checks for the clinic.
    /// Roles are determined by the Role column in the UserAccount table.
    /// 
    /// Standard Roles:
    ///   - "Patient"      : Patient/client accessing their own data
    ///   - "Doctor"       : Main clinician with full access (admin)
    ///   - "Receptionist" : Front desk staff, limited access
    ///   - "Therapist"    : Treatment provider (can view patient info, book appointments)
    ///   - "Admin"        : System administrator (equivalent to Doctor)
    /// 
    /// Access Rules (configured in Web.config):
    ///   Patients:
    ///     ? View only their own data
    ///     ? Book/cancel their own appointments
    ///     ? View their own invoices
    ///     ? View their own progress/results
    ///     ? Cannot see other patients
    ///     ? Cannot see staff data
    /// 
    ///   Receptionists:
    ///     ? View all patients (summary)
    ///     ? Manage appointments
    ///     ? Issue temporary passwords
    ///     ? Activate/deactivate patient accounts
    ///     ? View invoices (all patients)
    ///     ? Cannot see clinical notes
    ///     ? Cannot modify staff
    /// 
    ///   Doctors:
    ///     ? View all patients (full details)
    ///     ? View clinical notes/results
    ///     ? Manage appointments
    ///     ? Manage staff (if admin role)
    ///     ? View reports
    ///     ? System administration
    ///     ? See everything
    /// 
    ///   Therapists (if defined):
    ///     ? View patient details
    ///     ? View appointments
    ///     ? View treatment-related info
    ///     ? Book appointments
    ///     ? Cannot see financial data
    ///     ? Cannot manage staff
    /// </summary>
    public static class RoleBasedAccess
    {
        /// <summary>Get the friendly role name from UserAccount.Role (e.g., "Doctor", "Receptionist").</summary>
        public static string GetCurrentRole()
        {
            var id = Auth.Current;
            return id == null ? null : (id.DbRole ?? "").Trim();
        }

        /// <summary>Check if current user has any of the specified roles (case-insensitive).</summary>
        public static bool HasRole(params string[] roles)
        {
            var currentRole = GetCurrentRole();
            if (currentRole == null) return false;
            return roles.Any(r => string.Equals(currentRole, r, StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>Check if current user is a Doctor or admin-level staff.</summary>
        public static bool IsDoctor()
        {
            var id = Auth.Current;
            return id != null && id.IsAdmin;
        }

        /// <summary>Check if current user is a Receptionist.</summary>
        public static bool IsReceptionist()
        {
            return HasRole("Receptionist", "Reception");
        }

        /// <summary>Check if current user is a Therapist.</summary>
        public static bool IsTherapist()
        {
            return HasRole("Therapist", "Treatment Specialist");
        }

        /// <summary>Check if current user is a Patient.</summary>
        public static bool IsPatientRole()
        {
            return Auth.IsPatient;
        }

        /// <summary>
        /// Check if current user can view patient data.
        /// 
        /// Rules:
        ///   - Patient: can only see their own data (patientId must match)
        ///   - Doctor/Admin: can see all
        ///   - Receptionist: can see all (summary)
        ///   - Therapist: can see all
        /// </summary>
        public static bool CanViewPatient(int patientId)
        {
            var id = Auth.Current;
            if (id == null) return false;

            // Patients can only see their own data
            if (Auth.IsPatient)
                return id.PatientId == patientId;

            // Staff (all roles) can see any patient
            return Auth.IsStaff;
        }

        /// <summary>
        /// Check if current user can view clinical/sensitive patient data.
        /// 
        /// Rules:
        ///   - Patient: can see their own clinical data
        ///   - Doctor/Admin: can see all
        ///   - Receptionist: NO
        ///   - Therapist: YES (they provide treatment)
        /// </summary>
        public static bool CanViewClinicalData(int patientId)
        {
            var id = Auth.Current;
            if (id == null) return false;

            // Patient can see their own
            if (Auth.IsPatient)
                return id.PatientId == patientId;

            // Doctor/Admin can see all
            if (IsDoctor())
                return true;

            // Therapists can see (they do treatments)
            if (IsTherapist())
                return true;

            // Receptionists cannot see clinical data
            return false;
        }

        /// <summary>
        /// Check if current user can view financial data.
        /// 
        /// Rules:
        ///   - Patient: can see their own invoices
        ///   - Doctor/Admin: can see all
        ///   - Receptionist: YES (they manage invoices)
        ///   - Therapist: NO
        /// </summary>
        public static bool CanViewFinancial(int patientId)
        {
            var id = Auth.Current;
            if (id == null) return false;

            // Patient can see their own
            if (Auth.IsPatient)
                return id.PatientId == patientId;

            // Doctor/Admin can see all
            if (IsDoctor())
                return true;

            // Receptionist can see all (they manage billing)
            if (IsReceptionist())
                return true;

            // Therapists cannot
            return false;
        }

        /// <summary>
        /// Check if current user can manage patient accounts (activate/deactivate/reset password).
        /// 
        /// Rules:
        ///   - Patient: NO
        ///   - Doctor/Admin: YES (all)
        ///   - Receptionist: YES (limited, only activate/deactivate)
        ///   - Therapist: NO
        /// </summary>
        public static bool CanManagePatientAccounts()
        {
            // Patients cannot manage accounts
            if (Auth.IsPatient)
                return false;

            // Doctors and admins can
            if (IsDoctor())
                return true;

            // Receptionists can
            if (IsReceptionist())
                return true;

            return false;
        }

        /// <summary>
        /// Check if current user can reset patient passwords.
        /// 
        /// Rules:
        ///   - Patient: NO
        ///   - Doctor/Admin: YES
        ///   - Receptionist: YES
        ///   - Therapist: NO
        /// </summary>
        public static bool CanResetPasswords()
        {
            return CanManagePatientAccounts();
        }

        /// <summary>
        /// Check if current user can view reports/analytics.
        /// 
        /// Rules:
        ///   - Patient: NO
        ///   - Doctor/Admin: YES
        ///   - Receptionist: LIMITED (basic reports only)
        ///   - Therapist: LIMITED (their own metrics)
        /// </summary>
        public static bool CanViewReports()
        {
            // Patients cannot view reports
            if (Auth.IsPatient)
                return false;

            // Doctors and admins can
            return Auth.IsStaff;
        }

        /// <summary>
        /// Check if current user can manage staff (add/edit/remove).
        /// 
        /// Rules:
        ///   - Only Doctor/Admin can manage staff
        /// </summary>
        public static bool CanManageStaff()
        {
            return IsDoctor();
        }

        /// <summary>
        /// Check if current user can book/modify appointments for others.
        /// 
        /// Rules:
        ///   - Patient: can only book their own
        ///   - Doctor/Admin: can book for anyone
        ///   - Receptionist: can book for anyone (via phone)
        ///   - Therapist: can book for anyone they treat
        /// </summary>
        public static bool CanBookAppointmentFor(int patientId)
        {
            var id = Auth.Current;
            if (id == null) return false;

            // Patient can only book own
            if (Auth.IsPatient)
                return id.PatientId == patientId;

            // All staff can book for anyone
            return Auth.IsStaff;
        }

        /// <summary>
        /// Enforce access control and redirect if denied.
        /// Use this in page OnInit() to check access.
        /// </summary>
        public static void RequireRole(System.Web.UI.Page page, params string[] roles)
        {
            if (!HasRole(roles))
                page.Response.Redirect("~/Account/Login.aspx", true);
        }

        /// <summary>
        /// Log access control decisions for audit trail.
        /// Call this when you want to track who accessed what.
        /// </summary>
        public static void LogAccess(string resource, string action, bool allowed)
        {
            var id = Auth.Current;
            if (id == null) return;

            string message = string.Format(
                "[RBAC] User: {0} ({1}), Role: {2}, Resource: {3}, Action: {4}, Allowed: {5}",
                id.Email, id.FullName, GetCurrentRole(), resource, action, allowed);

            System.Diagnostics.Debug.WriteLine(message);
            ErrorLog.Write(new System.Exception(message));
        }
    }
}
