using System;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Web;

namespace AestheticClinicWeb.Helpers
{
    /// <summary>Formatting helpers used from markup (namespace is registered in Web.config).</summary>
    public static class Ui
    {
        static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

        public static string Money(object v)
        {
            if (v == null || v == DBNull.Value) return "R 0.00";
            return "R " + Convert.ToDecimal(v).ToString("#,##0.00", Inv).Replace(",", " ");
        }

        public static string Date(object v)
        {
            return v == null || v == DBNull.Value ? "" : Convert.ToDateTime(v).ToString("yyyy-MM-dd", Inv);
        }

        public static string LongDate(object v)
        {
            return v == null || v == DBNull.Value ? "" : Convert.ToDateTime(v).ToString("dddd, d MMMM yyyy", Inv);
        }

        public static string Time(object v)
        {
            if (v == null || v == DBNull.Value) return "";
            if (v is TimeSpan) return ((TimeSpan)v).ToString(@"hh\:mm");
            return Convert.ToDateTime(v).ToString("HH:mm", Inv);
        }

        public static string StatusPill(object status)
        {
            string s = Convert.ToString(status).Trim();
            string css = "pill-wait";
            if (s == ClinicSettings.StatusCompleted || s.Equals("Active", StringComparison.OrdinalIgnoreCase) || s.Equals("Confirmed", StringComparison.OrdinalIgnoreCase) || s == "Paid") css = "pill-ok";
            else if (s == "Deactivated") css = "pill-no";
            else if (s == "Awaiting first login") css = "pill-info";
            else if (s == ClinicSettings.StatusCancelled || s == ClinicSettings.StatusNoShow || s.Equals("Suspended", StringComparison.OrdinalIgnoreCase) || s.Equals("Denied", StringComparison.OrdinalIgnoreCase)
                     || s.Equals("Rejected", StringComparison.OrdinalIgnoreCase) || s == "Unpaid" || s == "Inactive") css = "pill-no";
            else if (s == ClinicSettings.StatusBooked) css = "pill-info";
            return "<span class=\"pill " + css + "\">" + HttpUtility.HtmlEncode(s) + "</span>";
        }

        public static string PaidPill(object isPaid)
        {
            bool paid = isPaid != null && isPaid != DBNull.Value && Convert.ToBoolean(isPaid);
            return StatusPill(paid ? "Paid" : "Unpaid");
        }

        public static string Gender(object g)
        {
            string s = Convert.ToString(g).Trim().ToUpperInvariant();
            return s == "M" ? "Male" : s == "F" ? "Female" : s;
        }

        /// <summary>Server-rendered horizontal bar chart (pure HTML/CSS - no plugins, loads instantly).</summary>
        public static string BarChart(DataTable dt, string labelCol, string valueCol, bool money)
        {
            if (dt == null || dt.Rows.Count == 0 || !dt.Columns.Contains(labelCol) || !dt.Columns.Contains(valueCol)) return "";
            var rows = dt.AsEnumerable()
                .Select(r => new { L = Convert.ToString(r[labelCol]), V = r.IsNull(valueCol) ? 0m : Convert.ToDecimal(r[valueCol]) })
                .Take(20).ToList();
            decimal max = rows.Max(r => Math.Abs(r.V));
            if (max == 0) max = 1;
            var sb = new StringBuilder("<div class=\"chart\" role=\"img\" aria-label=\"Bar chart of " + HttpUtility.HtmlAttributeEncode(valueCol) + "\">");
            foreach (var r in rows)
            {
                int pct = (int)Math.Round(Math.Abs(r.V) / max * 100m);
                string val = money ? Money(r.V) : r.V.ToString("#,##0.##", Inv);
                sb.Append("<div class=\"bar-row\"><div class=\"bar-label\" title=\"").Append(HttpUtility.HtmlAttributeEncode(r.L)).Append("\">")
                  .Append(HttpUtility.HtmlEncode(r.L)).Append("</div><div class=\"bar-track\"><div class=\"bar")
                  .Append(r.V < 0 ? " neg" : "").Append("\" style=\"width:").Append(Math.Max(pct, 1)).Append("%\"></div></div><div class=\"bar-val\">")
                  .Append(HttpUtility.HtmlEncode(val)).Append("</div></div>");
            }
            return sb.Append("</div>").ToString();
        }

        /// <summary>Renders a DataTable as an HTML table (money columns formatted).</summary>
        public static string HtmlTable(DataTable dt)
        {
            if (dt == null || dt.Rows.Count == 0) return "<div class=\"empty\">No data for the selected period.</div>";
            var sb = new StringBuilder("<div class=\"table-wrap\"><table class=\"data\"><thead><tr>");
            foreach (DataColumn c in dt.Columns) sb.Append("<th>").Append(HttpUtility.HtmlEncode(c.ColumnName)).Append("</th>");
            sb.Append("</tr></thead><tbody>");
            foreach (DataRow r in dt.Rows)
            {
                sb.Append("<tr>");
                foreach (DataColumn c in dt.Columns) sb.Append("<td>").Append(HttpUtility.HtmlEncode(Cell(r, c))).Append("</td>");
                sb.Append("</tr>");
            }
            return sb.Append("</tbody></table></div>").ToString();
        }

        public static string Cell(DataRow r, DataColumn c)
        {
            if (r.IsNull(c)) return "";
            object v = r[c];
            if (v is DateTime) return ((DateTime)v).ToString("yyyy-MM-dd", Inv);
            if (c.ColumnName.Contains("(R)")) return Money(v);
            if (v is decimal || v is double) return Convert.ToDecimal(v).ToString("0.##", Inv);
            return Convert.ToString(v, Inv);
        }

        /// <summary>CSV (opens directly in Excel) - RFC 4180 quoting, formula-injection safe.</summary>
        public static string Csv(DataTable dt)
        {
            var sb = new StringBuilder();
            sb.AppendLine(string.Join(",", dt.Columns.Cast<DataColumn>().Select(c => Q(c.ColumnName))));
            foreach (DataRow r in dt.Rows)
                sb.AppendLine(string.Join(",", dt.Columns.Cast<DataColumn>().Select(c =>
                    Q(r.IsNull(c) ? "" : (r[c] is DateTime ? ((DateTime)r[c]).ToString("yyyy-MM-dd", Inv) : Convert.ToString(r[c], Inv))))));
            return sb.ToString();
        }

        static string Q(string s)
        {
            if (s.Length > 0 && "=+-@".IndexOf(s[0]) >= 0 && !decimal.TryParse(s, NumberStyles.Number, Inv, out _)) s = "'" + s;
            return "\"" + s.Replace("\"", "\"\"") + "\"";
        }
    }
}
