using System;
using System.Configuration;
using System.Linq;

namespace AestheticClinicWeb.Helpers
{
    /// <summary>Strongly-typed access to the appSettings in Web.config.</summary>
    public static class ClinicSettings
    {
        static string Get(string key, string fallback)
        {
            var v = ConfigurationManager.AppSettings[key];
            return string.IsNullOrWhiteSpace(v) ? fallback : v.Trim();
        }
        static int GetInt(string key, int fallback)
        {
            int v; return int.TryParse(Get(key, ""), out v) ? v : fallback;
        }
        static bool GetBool(string key, bool fallback)
        {
            bool v; return bool.TryParse(Get(key, ""), out v) ? v : fallback;
        }
        static TimeSpan GetTime(string key, string fallback)
        {
            TimeSpan t; return TimeSpan.TryParse(Get(key, fallback), out t) ? t : TimeSpan.Parse(fallback);
        }

        public static string ClinicName { get { return Get("Clinic:Name", "AestheticFlow"); } }
        public static int SlotMinutes { get { return Math.Max(5, GetInt("Clinic:SlotMinutes", 30)); } }
        public static int MaxConcurrent { get { return Math.Max(1, GetInt("Clinic:MaxConcurrentAppointments", 1)); } }
        public static int MinHoursNoticeToCancel { get { return GetInt("Clinic:MinHoursNoticeToCancel", 24); } }

        public static string StatusBooked { get { return Get("Status:Booked", "Scheduled"); } }
        public static string StatusCompleted { get { return Get("Status:Completed", "Completed"); } }
        public static string StatusCancelled { get { return Get("Status:Cancelled", "Cancelled"); } }
        public static string StatusNoShow { get { return Get("Status:NoShow", "No Show"); } }
        public static string[] AllStatuses
        {
            get { return new[] { StatusBooked, StatusCompleted, StatusCancelled, StatusNoShow }; }
        }

        public static string PatientRole { get { return Get("Roles:PatientRole", "Patient"); } }
        public static string[] AdminRoles
        {
            get
            {
                return Get("Roles:AdminRoles", "Doctor,Admin,Administrator,Manager")
                    .Split(',').Select(s => s.Trim()).Where(s => s.Length > 0).ToArray();
            }
        }
        public static string DoctorRole { get { return Get("Roles:DoctorRole", "Doctor"); } }
        public static string ReceptionistRole { get { return Get("Roles:ReceptionistRole", "Receptionist"); } }
        public static string TherapistRole { get { return Get("Roles:TherapistRole", "Therapist"); } }
        public static string[] StaffRoles
        {
            get
            {
                return Get("Roles:StaffRoles", "Doctor,Receptionist,Therapist,Admin,Administrator,Manager")
                    .Split(',').Select(s => s.Trim()).Where(s => s.Length > 0).ToArray();
            }
        }
        public static bool AutoApprovePatients { get { return GetBool("Accounts:AutoApprovePatients", false); } }
        public static bool HashPasswords { get { return GetBool("Accounts:HashPasswords", false); } }

        /// <summary>Opening hours for a date; returns false when the clinic is closed.</summary>
        public static bool TryGetHours(DateTime date, out TimeSpan open, out TimeSpan close)
        {
            open = close = TimeSpan.Zero;
            if (date.DayOfWeek == DayOfWeek.Sunday) return false;
            if (date.DayOfWeek == DayOfWeek.Saturday)
            {
                open = GetTime("Clinic:SaturdayOpen", "09:00");
                close = GetTime("Clinic:SaturdayClose", "14:00");
            }
            else
            {
                open = GetTime("Clinic:WeekdayOpen", "08:00");
                close = GetTime("Clinic:WeekdayClose", "18:00");
            }
            return close > open;
        }
    }
}
