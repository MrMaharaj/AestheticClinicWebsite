using System;
using System.Diagnostics;
using System.IO;
using System.Web;

namespace AestheticClinicWeb.Helpers
{
    /// <summary>Writes unexpected errors to App_Data/errors.log (and Trace) for SQA review.</summary>
    public static class ErrorLog
    {
        static readonly object Gate = new object();

        public static void Write(Exception ex)
        {
            try
            {
                string url = HttpContext.Current != null ? HttpContext.Current.Request.RawUrl : "";
                string line = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " | " + url + " | " + ex.GetType().Name + ": " + ex.Message;
                Trace.TraceError(line);
                string dir = HttpContext.Current != null ? HttpContext.Current.Server.MapPath("~/App_Data") : null;
                if (dir == null) return;
                lock (Gate)
                {
                    Directory.CreateDirectory(dir);
                    File.AppendAllText(Path.Combine(dir, "errors.log"), line + Environment.NewLine + ex + Environment.NewLine + Environment.NewLine);
                }
            }
            catch { /* logging must never break the page */ }
        }
    }
}
