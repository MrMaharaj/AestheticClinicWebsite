using System;
using System.Text.RegularExpressions;

namespace AestheticClinicWeb.Helpers
{
    /// <summary>Server-side validation rules shared by all forms (mirrors the client-side validators).</summary>
    public static class Check
    {
        public static readonly Regex EmailRx = new Regex(@"^[^@\s]+@[^@\s]+\.[^@\s]{2,}$", RegexOptions.Compiled);
        public static readonly Regex PhoneRx = new Regex(@"^0\d{9}$", RegexOptions.Compiled);
        public const string EmailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]{2,}$";
        public const string PhonePattern = @"^0\d{9}$";
        public const string IdPattern = @"^\d{13}$";

        public static bool Email(string s) { return !string.IsNullOrWhiteSpace(s) && s.Length <= 50 && EmailRx.IsMatch(s.Trim()); }
        public static bool Phone(string s) { return !string.IsNullOrWhiteSpace(s) && PhoneRx.IsMatch(s.Trim()); }

        /// <summary>
        /// Validates a South African ID number (13 digits, valid date, Luhn checksum)
        /// and extracts date of birth and gender (digits 7-10: 0000-4999 = F, 5000-9999 = M).
        /// </summary>
        public static bool SaId(string id, out DateTime dob, out char gender, out string error)
        {
            dob = DateTime.MinValue; gender = 'U'; error = null;
            id = (id ?? "").Trim();
            if (!Regex.IsMatch(id, IdPattern)) { error = "ID number must be exactly 13 digits."; return false; }

            int yy = int.Parse(id.Substring(0, 2)), mm = int.Parse(id.Substring(2, 2)), dd = int.Parse(id.Substring(4, 2));
            int century = (yy + 2000) > DateTime.Today.Year ? 1900 : 2000;
            try { dob = new DateTime(century + yy, mm, dd); }
            catch { error = "The first six digits of the ID number are not a valid date (YYMMDD)."; return false; }

            gender = int.Parse(id.Substring(6, 4)) >= 5000 ? 'M' : 'F';

            int sum = 0; bool dbl = false;
            for (int i = id.Length - 1; i >= 0; i--)
            {
                int d = id[i] - '0';
                if (dbl) { d *= 2; if (d > 9) d -= 9; }
                sum += d; dbl = !dbl;
            }
            if (sum % 10 != 0) { error = "ID number checksum is invalid - please check for typing errors."; return false; }
            return true;
        }

        public static string Trunc(string s, int max)
        {
            s = (s ?? "").Trim();
            return s.Length > max ? s.Substring(0, max) : s;
        }
    }
}
