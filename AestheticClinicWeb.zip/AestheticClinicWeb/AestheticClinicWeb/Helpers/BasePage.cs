using System;
using System.Data.SqlClient;
using System.Globalization;
using System.Web.UI;
using System.Web.UI.WebControls;
using AestheticClinicWeb.Security;

namespace AestheticClinicWeb.Helpers
{
    /// <summary>
    /// Base class for every data page. Provides consistent confirmation / error messages
    /// (system visibility) and turns any exception into a friendly, recoverable message
    /// instead of a crash (error handling).
    /// </summary>
    public class BasePage : Page
    {
        protected static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

        protected override void OnLoad(EventArgs e)
        {
            // Staff created by an admin, and patients whose account was created in the FES with an emailed
            // temporary password (Is_First_Login = 1), must set their own strong password first.
            var id = Auth.Current;
            string path = Request.AppRelativeCurrentExecutionFilePath ?? "";
            if (id != null && id.MustChangePassword &&
                !path.EndsWith("ChangePassword.aspx", StringComparison.OrdinalIgnoreCase) &&
                !path.EndsWith("Login.aspx", StringComparison.OrdinalIgnoreCase))      // so they can still log out
            {
                Response.Redirect("~/Account/ChangePassword.aspx?first=1", true);
            }
            base.OnLoad(e);
        }

        protected void Ok(Label lbl, string message)
        {
            lbl.CssClass = "msg msg-ok"; lbl.Text = "&#10004; " + Server.HtmlEncode(message); lbl.Visible = true;
        }

        protected void Fail(Label lbl, string message)
        {
            lbl.CssClass = "msg msg-err"; lbl.Text = "&#9888; " + Server.HtmlEncode(message); lbl.Visible = true;
        }

        /// <summary>Runs an action; any error becomes a friendly message and the page keeps working.</summary>
        protected bool Safe(Label lbl, Action action)
        {
            try { action(); return true; }
            catch (InvalidOperationException ex) { Fail(lbl, ex.Message); }
            catch (SqlException ex) { Fail(lbl, FriendlySql(ex)); ErrorLog.Write(ex); }
            catch (System.Configuration.ConfigurationErrorsException ex) { Fail(lbl, ex.Message); ErrorLog.Write(ex); }
            catch (Exception ex) { Fail(lbl, "Something went wrong and nothing was saved. Please try again. (" + ex.GetType().Name + ")"); ErrorLog.Write(ex); }
            return false;
        }

        public static string FriendlySql(SqlException ex)
        {
            switch (ex.Number)
            {
                case -2: return "The database took too long to respond. Please try again.";
                case 0: case -1: case 2: case 40: case 53: case 233: case 4060: case 10053: case 10054: case 10060: case 10061: case 11001: case 18456:
                    return "The clinic database is currently unavailable. Please try again shortly.";
                case 207: return "The database is missing the patient login columns. Run Database/01_Add_Patient_Login_Columns.sql.";
                case 547: return "This record is linked to other records and cannot be changed or removed.";
                case 2601: case 2627: return "A record with the same details already exists.";
                case 8152: case 2628: return "One of the values is too long for the database. Please shorten it.";
                case 1205: return "Another user was saving at the same moment. Please try again.";
                default: return "A database error occurred (code " + ex.Number + "). Nothing was saved.";
            }
        }

        protected int QueryInt(string key)
        {
            int v; return int.TryParse(Request.QueryString[key], out v) ? v : 0;
        }

        protected static decimal? ParseDec(string s)
        {
            decimal d;
            if (string.IsNullOrWhiteSpace(s)) return null;
            return decimal.TryParse(s.Trim().Replace(',', '.'), NumberStyles.Number, Inv, out d) ? d : (decimal?)null;
        }

        protected static DateTime? ParseDate(string s)
        {
            DateTime d;
            return DateTime.TryParseExact((s ?? "").Trim(), "yyyy-MM-dd", Inv, DateTimeStyles.None, out d) ? d : (DateTime?)null;
        }

        /// <summary>Reads an uploaded image (jpg/png/gif/webp, max 2 MB) or returns null.</summary>
        protected static byte[] ReadImage(FileUpload fu, out string error)
        {
            error = null;
            if (fu == null || !fu.HasFile) return null;
            string ext = System.IO.Path.GetExtension(fu.FileName ?? "").ToLowerInvariant();
            if (ext != ".jpg" && ext != ".jpeg" && ext != ".png" && ext != ".gif" && ext != ".webp")
            { error = "Images must be JPG, PNG, GIF or WEBP."; return null; }
            if (fu.PostedFile.ContentLength > 2 * 1024 * 1024) { error = "Images must be 2 MB or smaller."; return null; }
            return fu.FileBytes;
        }
    }
}
