using System;
using AestheticClinicWeb.Security;

namespace AestheticClinicWeb.Helpers
{
    /// <summary>Base for /Patient pages. Every query is scoped to the logged-in patient's own Patient_ID.</summary>
    public class PatientPage : BasePage
    {
        protected int PatientId { get { var c = Auth.Current; return c == null ? 0 : c.PatientId; } }
        protected int UserId { get { var c = Auth.Current; return c == null ? 0 : c.AccountId; } }

        protected override void OnInit(EventArgs e)
        {
            // Defence in depth (Web.config already restricts /Patient to the Patient role)
            if (!Auth.IsPatient || PatientId <= 0) { Response.Redirect("~/Account/Login.aspx", true); }
            base.OnInit(e);
        }
    }
}
