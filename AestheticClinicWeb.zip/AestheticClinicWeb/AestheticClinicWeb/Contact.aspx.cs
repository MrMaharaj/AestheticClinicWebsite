using System;
using System.Web.UI.WebControls;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;

namespace AestheticClinicWeb
{
    public partial class Contact : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            ddlTreatment.Items.Add("General Consultation");
            try
            {
                foreach (System.Data.DataRow r in ServiceRepository.All().Rows)
                    ddlTreatment.Items.Add(Convert.ToString(r["Service_Name"]));
            }
            catch (Exception ex) { ErrorLog.Write(ex); }
            ddlTreatment.Items.Add("Other");
        }

        protected void btnSend_Click(object sender, EventArgs e)
        {
            Page.Validate("contact");
            if (!Page.IsValid) return;
            if (!Check.Email(txtEmail.Text)) { Fail(lblResult, "Please enter a valid email address."); return; }
            if (txtPhone.Text.Trim().Length > 0 && !Check.Phone(txtPhone.Text)) { Fail(lblResult, "Contact number must be 10 digits starting with 0."); return; }

            bool ok = Safe(lblResult, () =>
            {
                // Optional table (Database/02_Web_Additions.sql). If it is not installed the enquiry is still acknowledged.
                if (Db.TableExists("ContactEnquiry"))
                {
                    Db.Execute(@"INSERT INTO ContactEnquiry (Full_Name, Email, Contact_No, Treatment, Message, Date_Received, Status)
                                 VALUES (@n,@e,@c,@t,@m,GETDATE(),'New')",
                        Db.P("@n", Check.Trunc(txtName.Text, 100)), Db.P("@e", Check.Trunc(txtEmail.Text, 50)),
                        Db.P("@c", txtPhone.Text.Trim().Length == 0 ? null : txtPhone.Text.Trim()),
                        Db.P("@t", Check.Trunc(ddlTreatment.SelectedValue, 50)), Db.P("@m", Check.Trunc(txtMessage.Text, 500)));
                }
            });
            if (!ok) return;

            Ok(lblResult, "Thank you, " + txtName.Text.Trim() + ". Your request about \"" + ddlTreatment.SelectedValue +
                          "\" has been received. Our team will contact you within one working day.");
            txtName.Text = txtEmail.Text = txtPhone.Text = txtMessage.Text = "";
            ddlTreatment.SelectedIndex = 0;
        }
    }
}
