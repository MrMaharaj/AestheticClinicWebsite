using System;
using System.Collections.Generic;
using System.Web.UI;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Security;

namespace AestheticClinicWeb
{
    public partial class AppMaster : MasterPage
    {
        protected class MenuItem
        {
            public string Text, Url, Icon; public bool IsGroup; public int Badge;
            public static MenuItem Group(string t) { return new MenuItem { Text = t, IsGroup = true }; }
            public static MenuItem Link(string t, string u, string i) { return new MenuItem { Text = t, Url = u, Icon = i }; }
        }

        protected List<MenuItem> MenuItems = new List<MenuItem>();
        protected string RoleLabel = "", FullName = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            var id = Auth.Current;
            if (id == null) return;
            FullName = id.FullName;

            if (id.Kind == AccountKind.Patient)
            {
                RoleLabel = "Patient";
                MenuItems.Add(MenuItem.Group("My Account"));
                MenuItems.Add(MenuItem.Link("Dashboard", "~/Patient/Dashboard.aspx", "&#9632;"));
                MenuItems.Add(MenuItem.Link("Book Appointment", "~/Patient/Book.aspx", "&#10010;"));
                MenuItems.Add(MenuItem.Link("My Appointments", "~/Patient/Appointments.aspx", "&#128197;"));
                MenuItems.Add(MenuItem.Link("Invoices & Receipts", "~/Patient/Invoices.aspx", "&#129534;"));
                MenuItems.Add(MenuItem.Link("My Progress & Results", "~/Patient/Progress.aspx", "&#128200;"));
                MenuItems.Add(MenuItem.Link("My Profile", "~/Patient/Profile.aspx", "&#128100;"));
                return;
            }

            RoleLabel = id.DbRole + (id.IsAdmin ? " \u00b7 Manager" : "");
            MenuItems.Add(MenuItem.Group("Overview"));
            MenuItems.Add(MenuItem.Link("Dashboard", "~/Portal/Dashboard.aspx", "&#9632;"));
            MenuItems.Add(MenuItem.Group("Patients"));
            MenuItems.Add(MenuItem.Link("Patients", "~/Portal/Patients.aspx", "&#9679;"));
            MenuItems.Add(MenuItem.Link("Appointments", "~/Portal/Appointments.aspx", "&#9679;"));
            MenuItems.Add(MenuItem.Link("Clinical Metrics", "~/Portal/Metrics.aspx", "&#9679;"));
            MenuItems.Add(MenuItem.Link("Treatment Results", "~/Portal/Results.aspx", "&#9679;"));
            MenuItems.Add(MenuItem.Group("Finance"));
            MenuItems.Add(MenuItem.Link("Payments & Invoices", "~/Portal/Invoices.aspx", "&#9679;"));
            MenuItems.Add(MenuItem.Link("BI Reports", "~/Portal/Reports.aspx", "&#9679;"));
            if (id.IsAdmin)
            {
                int pending = 0;
                try { pending = AccountRepository.PendingAccountCount(); } catch { /* menu must still render if DB is down */ }
                MenuItems.Add(MenuItem.Group("Admin"));
                MenuItems.Add(MenuItem.Link("Treatments & Prices", "~/Portal/ManageServices.aspx", "&#9679;"));
                MenuItems.Add(new MenuItem { Text = "Manage Accounts", Url = "~/Portal/ManageAccounts.aspx", Icon = "&#9679;", Badge = pending });
            }
        }

        protected bool IsCurrent(string url)
        {
            return string.Equals(Request.AppRelativeCurrentExecutionFilePath, url, StringComparison.OrdinalIgnoreCase);
        }
    }
}
