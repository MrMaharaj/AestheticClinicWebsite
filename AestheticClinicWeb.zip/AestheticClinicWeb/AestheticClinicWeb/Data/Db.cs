using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace AestheticClinicWeb.Data
{
    /// <summary>
    /// Thin ADO.NET helper. Every query in the website goes through here, always with
    /// SqlParameters (never string concatenation) to prevent SQL injection.
    /// The same database is used by the Front-End System, so changes are shared instantly.
    /// </summary>
    public static class Db
    {
        public const string ConnectionName = "ClinicDb";

        public static string ConnectionString
        {
            get
            {
                var cs = ConfigurationManager.ConnectionStrings[ConnectionName];
                if (cs == null || string.IsNullOrWhiteSpace(cs.ConnectionString))
                    throw new ConfigurationErrorsException(
                        "Connection string 'ClinicDb' is missing. Create connections.config from connections.config.example.");
                return cs.ConnectionString;
            }
        }

        public static SqlConnection Open()
        {
            var con = new SqlConnection(ConnectionString);
            con.Open();
            return con;
        }

        public static SqlParameter P(string name, object value)
        {
            return new SqlParameter(name, value ?? DBNull.Value);
        }

        private static SqlCommand Cmd(SqlConnection con, SqlTransaction tx, string sql, SqlParameter[] ps)
        {
            var cmd = new SqlCommand(sql, con, tx) { CommandTimeout = 30 };
            if (ps != null) cmd.Parameters.AddRange(ps);
            return cmd;
        }

        public static DataTable Table(string sql, params SqlParameter[] ps)
        {
            using (var con = Open())
            using (var cmd = Cmd(con, null, sql, ps))
            using (var da = new SqlDataAdapter(cmd))
            {
                var dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public static DataRow Row(string sql, params SqlParameter[] ps)
        {
            var dt = Table(sql, ps);
            return dt.Rows.Count > 0 ? dt.Rows[0] : null;
        }

        public static object Scalar(string sql, params SqlParameter[] ps)
        {
            using (var con = Open())
            using (var cmd = Cmd(con, null, sql, ps))
            {
                var o = cmd.ExecuteScalar();
                return o == DBNull.Value ? null : o;
            }
        }

        public static int Execute(string sql, params SqlParameter[] ps)
        {
            using (var con = Open())
            using (var cmd = Cmd(con, null, sql, ps))
                return cmd.ExecuteNonQuery();
        }

        // ---- transaction-aware overloads (used for multi-table writes) ----
        public static object Scalar(SqlConnection con, SqlTransaction tx, string sql, params SqlParameter[] ps)
        {
            using (var cmd = Cmd(con, tx, sql, ps))
            {
                var o = cmd.ExecuteScalar();
                return o == DBNull.Value ? null : o;
            }
        }

        public static int Execute(SqlConnection con, SqlTransaction tx, string sql, params SqlParameter[] ps)
        {
            using (var cmd = Cmd(con, tx, sql, ps))
                return cmd.ExecuteNonQuery();
        }

        public static DataTable Table(SqlConnection con, SqlTransaction tx, string sql, params SqlParameter[] ps)
        {
            using (var cmd = Cmd(con, tx, sql, ps))
            using (var da = new SqlDataAdapter(cmd))
            {
                var dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        /// <summary>Runs work inside one transaction; rolls everything back on any error.</summary>
        public static T InTransaction<T>(Func<SqlConnection, SqlTransaction, T> work,
                                         IsolationLevel level = IsolationLevel.ReadCommitted)
        {
            using (var con = Open())
            using (var tx = con.BeginTransaction(level))
            {
                try
                {
                    T result = work(con, tx);
                    tx.Commit();
                    return result;
                }
                catch
                {
                    try { tx.Rollback(); } catch { /* connection already broken */ }
                    throw;
                }
            }
        }

        static readonly System.Collections.Concurrent.ConcurrentDictionary<string, bool> ColumnCache =
            new System.Collections.Concurrent.ConcurrentDictionary<string, bool>(StringComparer.OrdinalIgnoreCase);

        /// <summary>True if dbo.table has the column (cached; only successful lookups are cached).</summary>
        public static bool ColumnExists(string table, string column)
        {
            bool v;
            string key = table + "." + column;
            if (ColumnCache.TryGetValue(key, out v)) return v;
            v = Scalar("SELECT COL_LENGTH(@t, @c)", P("@t", "dbo." + table), P("@c", column)) != null;
            ColumnCache[key] = v;
            return v;
        }

        public static bool TableExists(string table)
        {
            try
            {
                return Scalar("SELECT OBJECT_ID(@t, 'U')", P("@t", "dbo." + table)) != null;
            }
            catch { return false; }
        }

        // ---- null-safe readers ----
        public static string S(DataRow r, string col) { return r == null || r.IsNull(col) ? "" : Convert.ToString(r[col]); }
        public static int I(DataRow r, string col) { return r == null || r.IsNull(col) ? 0 : Convert.ToInt32(r[col]); }
        public static decimal M(DataRow r, string col) { return r == null || r.IsNull(col) ? 0m : Convert.ToDecimal(r[col]); }
        public static bool B(DataRow r, string col) { return r != null && !r.IsNull(col) && Convert.ToBoolean(r[col]); }
        public static DateTime D(DataRow r, string col) { return r == null || r.IsNull(col) ? DateTime.MinValue : Convert.ToDateTime(r[col]); }
    }
}
