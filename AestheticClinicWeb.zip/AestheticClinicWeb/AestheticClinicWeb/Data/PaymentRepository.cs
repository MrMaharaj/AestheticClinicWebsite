using System;
using System.Data;
using AestheticClinicWeb.Helpers;
using static AestheticClinicWeb.Data.Db;

namespace AestheticClinicWeb.Data
{
    public static class PaymentRepository
    {
        public static DataTable Search(DateTime? from, DateTime? to, string term, int? patientId)
        {
            term = (term ?? "").Trim();
            return Table(@"SELECT Payment_ID, Appointment_ID, Patient_ID, Patient_FirstName + ' ' + Patient_LastName AS PatientName,
                                  Date, Service_ID, Service_Description, Amount
                           FROM Payment
                           WHERE (@from IS NULL OR Date >= @from) AND (@to IS NULL OR Date <= @to) AND (@pid IS NULL OR Patient_ID=@pid)
                             AND (@t = '' OR Patient_FirstName LIKE @like OR Patient_LastName LIKE @like
                                  OR (Patient_FirstName + ' ' + Patient_LastName) LIKE @like OR Service_Description LIKE @like
                                  OR CAST(Payment_ID AS varchar(12)) = @t)
                           ORDER BY Date DESC, Payment_ID DESC",
                P("@from", from), P("@to", to), P("@pid", patientId), P("@t", term), P("@like", "%" + term + "%"));
        }

        /// <summary>Appointments that are not cancelled and not yet paid (accounts receivable).</summary>
        public static DataTable Unpaid(int? patientId)
        {
            return Table(@"SELECT a.Appointment_ID, a.Patient_ID, a.Patient_FirstName + ' ' + a.Patient_LastName AS PatientName,
                                  a.Service_Name, a.Date, a.Start_Time, a.Status, ISNULL(s.Price,0) AS Price
                           FROM Appointment a LEFT JOIN Service s ON s.Service_ID=a.Service_ID
                           WHERE a.Is_Paid=0 AND a.Status<>@c AND (@p IS NULL OR a.Patient_ID=@p)
                           ORDER BY a.Date, a.Start_Time", P("@c", ClinicSettings.StatusCancelled), P("@p", patientId));
        }

        public static DataRow Get(int paymentId)
        {
            return Row(@"SELECT pay.*, a.Start_Time, a.Date AS Appointment_Date, p.Email, p.Contact_No, p.Address
                         FROM Payment pay LEFT JOIN Appointment a ON a.Appointment_ID=pay.Appointment_ID
                         LEFT JOIN Patient p ON p.Patient_ID=pay.Patient_ID WHERE pay.Payment_ID=@i", P("@i", paymentId));
        }

        /// <summary>Records a payment and flags the appointment as paid in ONE transaction.</summary>
        public static int Record(int appointmentId, decimal amount)
        {
            if (amount <= 0 || amount > 9999.99m) throw new InvalidOperationException("Amount must be between R0.01 and R9 999.99.");
            return InTransaction((con, tx) =>
            {
                var a = Table(con, tx, @"SELECT a.*, s.Service_Name AS SName FROM Appointment a WITH (UPDLOCK)
                                         LEFT JOIN Service s ON s.Service_ID=a.Service_ID WHERE a.Appointment_ID=@i", P("@i", appointmentId));
                if (a.Rows.Count == 0) throw new InvalidOperationException("Appointment not found.");
                var r = a.Rows[0];
                if (B(r, "Is_Paid")) throw new InvalidOperationException("This appointment has already been paid.");
                if (S(r, "Status") == ClinicSettings.StatusCancelled) throw new InvalidOperationException("Cancelled appointments cannot be paid.");

                string desc = S(r, "SName"); if (desc == "") desc = S(r, "Service_Name");
                int id = Convert.ToInt32(Scalar(con, tx, @"
                    INSERT INTO Payment (Appointment_ID, Patient_ID, Patient_FirstName, Patient_LastName, Date, Service_ID, Service_Description, Amount)
                    VALUES (@a,@p,@f,@l,CAST(GETDATE() AS date),@s,@d,@amt); SELECT CAST(SCOPE_IDENTITY() AS int);",
                    P("@a", appointmentId), P("@p", I(r, "Patient_ID")), P("@f", S(r, "Patient_FirstName")), P("@l", S(r, "Patient_LastName")),
                    P("@s", I(r, "Service_ID")), P("@d", Check.Trunc(desc, 50)), P("@amt", amount)));
                Execute(con, tx, "UPDATE Appointment SET Is_Paid=1 WHERE Appointment_ID=@a", P("@a", appointmentId));
                return id;
            });
        }

        /// <summary>Reverses a payment (admin) and re-opens the appointment balance.</summary>
        public static void Delete(int paymentId)
        {
            InTransaction((con, tx) =>
            {
                var apptId = Scalar(con, tx, "SELECT Appointment_ID FROM Payment WHERE Payment_ID=@i", P("@i", paymentId));
                if (apptId == null) throw new InvalidOperationException("Payment not found.");
                Execute(con, tx, "DELETE FROM Payment WHERE Payment_ID=@i", P("@i", paymentId));
                Execute(con, tx, @"UPDATE Appointment SET Is_Paid = CASE WHEN EXISTS (SELECT 1 FROM Payment WHERE Appointment_ID=@a) THEN 1 ELSE 0 END
                                   WHERE Appointment_ID=@a", P("@a", apptId));
                return 0;
            });
        }
    }
}
