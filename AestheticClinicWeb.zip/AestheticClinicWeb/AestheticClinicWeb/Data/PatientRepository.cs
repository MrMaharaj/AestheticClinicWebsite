using System;
using System.Data;
using System.Data.SqlClient;
using static AestheticClinicWeb.Data.Db;

namespace AestheticClinicWeb.Data
{
    public class PatientRecord
    {
        public int PatientId;
        public string FirstName, LastName, IdNumber, Address, Phone, Email, Allergies, ExtraNotes;
        public char Gender; public DateTime Dob; public bool IsActive = true;
    }

    public static class PatientRepository
    {
        static SqlParameter TextP(string name, string v)
        {
            return new SqlParameter(name, SqlDbType.Text) { Value = string.IsNullOrWhiteSpace(v) ? (object)DBNull.Value : v.Trim() };
        }

        public static DataTable Search(string term, bool includeInactive)
        {
            term = (term ?? "").Trim();
            return Table(@"SELECT Patient_ID, First_Name, Last_Name, ID_Number, Gender, Date_Of_Birth, Contact_No, Email, Is_Active,
                                  CAST(Allergies AS varchar(200)) AS Allergies
                           FROM Patient
                           WHERE (@all = 1 OR Is_Active = 1)
                             AND (@t = '' OR First_Name LIKE @like OR Last_Name LIKE @like OR (First_Name + ' ' + Last_Name) LIKE @like
                                  OR ID_Number LIKE @like OR Email LIKE @like OR Contact_No LIKE @like
                                  OR CAST(Patient_ID AS varchar(12)) = @t)
                           ORDER BY Last_Name, First_Name",
                P("@all", includeInactive ? 1 : 0), P("@t", term), P("@like", "%" + term + "%"));
        }

        public static PatientRecord Get(int id)
        {
            var r = Row("SELECT * FROM Patient WHERE Patient_ID=@i", P("@i", id));
            if (r == null) return null;
            string g = S(r, "Gender");
            return new PatientRecord
            {
                PatientId = I(r, "Patient_ID"), FirstName = S(r, "First_Name"), LastName = S(r, "Last_Name"),
                IdNumber = S(r, "ID_Number").Trim(), Gender = g.Length > 0 ? g[0] : 'U', Dob = D(r, "Date_Of_Birth"),
                Address = S(r, "Address"), Phone = S(r, "Contact_No").Trim(), Email = S(r, "Email"),
                Allergies = S(r, "Allergies"), ExtraNotes = S(r, "Extra_Notes"), IsActive = B(r, "Is_Active")
            };
        }

        public static PatientRecord GetByIdNumber(string idNumber)
        {
            var id = Scalar("SELECT TOP 1 Patient_ID FROM Patient WHERE ID_Number=@id", P("@id", (idNumber ?? "").Trim()));
            return id == null ? null : Get(Convert.ToInt32(id));
        }

        public static bool IdNumberExists(string idNumber, int exceptPatientId)
        {
            return Convert.ToInt32(Scalar("SELECT COUNT(*) FROM Patient WHERE ID_Number=@id AND Patient_ID<>@p",
                P("@id", idNumber), P("@p", exceptPatientId))) > 0;
        }

        public static int Insert(PatientRecord p)
        {
            return Convert.ToInt32(Scalar(@"
                INSERT INTO Patient (First_Name, Last_Name, ID_Number, Gender, Date_Of_Birth, Address, Contact_No, Email, Allergies, Extra_Notes, Is_Active)
                VALUES (@f,@l,@id,@g,@dob,@a,@c,@e,@al,@n,1); SELECT CAST(SCOPE_IDENTITY() AS int);",
                P("@f", p.FirstName), P("@l", p.LastName), P("@id", p.IdNumber), P("@g", p.Gender.ToString()), P("@dob", p.Dob),
                P("@a", p.Address), P("@c", p.Phone), P("@e", p.Email), TextP("@al", p.Allergies), TextP("@n", p.ExtraNotes)));
        }

        /// <summary>
        /// Full update (staff). Name changes are also written to the denormalised name columns in
        /// Appointment, Payment and Results so the FES and website show the same name everywhere.
        /// </summary>
        public static void Update(PatientRecord p)
        {
            InTransaction((con, tx) =>
            {
                Execute(con, tx, @"UPDATE Patient SET First_Name=@f, Last_Name=@l, ID_Number=@id, Gender=@g, Date_Of_Birth=@dob,
                                   Address=@a, Contact_No=@c, Email=@e, Allergies=@al, Extra_Notes=@n WHERE Patient_ID=@p",
                    P("@f", p.FirstName), P("@l", p.LastName), P("@id", p.IdNumber), P("@g", p.Gender.ToString()), P("@dob", p.Dob),
                    P("@a", p.Address), P("@c", p.Phone), P("@e", p.Email), TextP("@al", p.Allergies), TextP("@n", p.ExtraNotes), P("@p", p.PatientId));
                SyncNames(con, tx, p.PatientId, p.FirstName, p.LastName);
                return 0;
            });
        }

        /// <summary>Patient self-service edit: contact details and allergies only (identity fields are locked).
        /// Patient.Email is also the patient's login.</summary>
        public static void UpdateOwnDetails(int patientId, int userId, string address, string phone, string email, string allergies)
        {
            InTransaction((con, tx) =>
            {
                Execute(con, tx, "UPDATE Patient SET Address=@a, Contact_No=@c, Email=@e, Allergies=@al WHERE Patient_ID=@p",
                    P("@a", address), P("@c", phone), P("@e", email), TextP("@al", allergies), P("@p", patientId));
                return 0;
            });
        }

        static void SyncNames(SqlConnection con, SqlTransaction tx, int id, string f, string l)
        {
            Execute(con, tx, "UPDATE Appointment SET Patient_FirstName=@f, Patient_LastName=@l WHERE Patient_ID=@p", P("@f", f), P("@l", l), P("@p", id));
            Execute(con, tx, "UPDATE Payment SET Patient_FirstName=@f, Patient_LastName=@l WHERE Patient_ID=@p", P("@f", f), P("@l", l), P("@p", id));
            Execute(con, tx, "UPDATE Results SET Patient_FirstName=@f, Patient_LastName=@l WHERE Patient_ID=@p", P("@f", f), P("@l", l), P("@p", id));
            Execute(con, tx, "UPDATE UserAccount SET First_Name=@f, Last_Name=@l WHERE Patient_ID=@p", P("@f", f), P("@l", l), P("@p", id));
        }

        public static void SetActive(int id, bool active)
        {
            Execute("UPDATE Patient SET Is_Active=@a WHERE Patient_ID=@p", P("@a", active), P("@p", id));
        }

        /// <summary>Hard delete is only allowed when the patient has no history; otherwise deactivate.</summary>
        public static bool TryDelete(int id, out string reason)
        {
            int refs = Convert.ToInt32(Scalar(@"SELECT (SELECT COUNT(*) FROM Appointment WHERE Patient_ID=@p)
                                                   + (SELECT COUNT(*) FROM Payment WHERE Patient_ID=@p)
                                                   + (SELECT COUNT(*) FROM HealthMetrics WHERE Patient_ID=@p)
                                                   + (SELECT COUNT(*) FROM Results WHERE Patient_ID=@p)
                                                   + (SELECT COUNT(*) FROM UserAccount WHERE Patient_ID=@p)", P("@p", id)));
            if (refs > 0)
            {
                reason = "This patient has appointments, payments, clinical records or a web account, so the record cannot be deleted. Deactivate the patient instead to keep the history intact.";
                return false;
            }
            Execute("DELETE FROM Patient WHERE Patient_ID=@p", P("@p", id));
            reason = null;
            return true;
        }

        public static DataTable ActiveForDropdown()
        {
            return Table(@"SELECT Patient_ID, Last_Name + ', ' + First_Name + ' (' + RTRIM(ID_Number) + ')' AS Display
                           FROM Patient WHERE Is_Active=1 ORDER BY Last_Name, First_Name");
        }
    }

    public static class ServiceRepository
    {
        public static DataTable All(string category = "", string search = "")
        {
            search = (search ?? "").Trim();
            return Table(@"SELECT Service_ID, Service_Name, Category, Description, Duration, Price FROM Service
                           WHERE (@c = '' OR Category=@c) AND (@s = '' OR Service_Name LIKE @like OR Description LIKE @like OR Category LIKE @like)
                           ORDER BY Category, Service_Name",
                P("@c", category ?? ""), P("@s", search), P("@like", "%" + search + "%"));
        }

        public static DataTable Categories()
        {
            return Table("SELECT DISTINCT Category FROM Service ORDER BY Category");
        }

        public static DataRow Get(int id) { return Row("SELECT * FROM Service WHERE Service_ID=@i", P("@i", id)); }

        /// <summary>Most-booked services (falls back to cheapest when no bookings exist yet).</summary>
        public static DataTable Popular(int top)
        {
            return Table(@"SELECT TOP (@n) s.Service_ID, s.Service_Name, s.Category, s.Description, s.Duration, s.Price, COUNT(a.Appointment_ID) AS Bookings
                           FROM Service s LEFT JOIN Appointment a ON a.Service_ID = s.Service_ID
                           GROUP BY s.Service_ID, s.Service_Name, s.Category, s.Description, s.Duration, s.Price
                           ORDER BY COUNT(a.Appointment_ID) DESC, s.Price", P("@n", top));
        }

        public static int Insert(string name, string category, string description, int duration, decimal price)
        {
            return Convert.ToInt32(Scalar(@"INSERT INTO Service (Service_Name, Category, Description, Duration, Price)
                                            VALUES (@n,@c,@d,@du,@p); SELECT CAST(SCOPE_IDENTITY() AS int);",
                P("@n", name), P("@c", category), P("@d", description), P("@du", duration), P("@p", price)));
        }

        public static void Update(int id, string name, string category, string description, int duration, decimal price)
        {
            Execute("UPDATE Service SET Service_Name=@n, Category=@c, Description=@d, Duration=@du, Price=@p WHERE Service_ID=@i",
                P("@n", name), P("@c", category), P("@d", description), P("@du", duration), P("@p", price), P("@i", id));
        }

        public static bool NameExists(string name, int exceptId)
        {
            return Convert.ToInt32(Scalar("SELECT COUNT(*) FROM Service WHERE Service_Name=@n AND Service_ID<>@i", P("@n", name), P("@i", exceptId))) > 0;
        }

        public static bool TryDelete(int id, out string reason)
        {
            int used = Convert.ToInt32(Scalar("SELECT COUNT(*) FROM Appointment WHERE Service_ID=@i", P("@i", id)));
            if (used > 0) { reason = "This treatment has " + used + " appointment(s) linked to it and cannot be deleted. Edit it instead."; return false; }
            Execute("DELETE FROM Service WHERE Service_ID=@i", P("@i", id));
            reason = null; return true;
        }
    }
}
