using System;
using System.Collections.Generic;
using System.Data;
using AestheticClinicWeb.Helpers;
using static AestheticClinicWeb.Data.Db;

namespace AestheticClinicWeb.Data
{
    public class ReportDefinition
    {
        public string Key, Title, Category, BusinessQuestion;
        public string LabelColumn, ValueColumn;   // used to draw the chart
        public bool ValueIsMoney, Complex;
        public Func<DateTime, DateTime, DataTable> Run;
    }

    /// <summary>
    /// Business-intelligence reports. Each answers a management question and can be shown as a
    /// table, a bar chart, exported to Excel (CSV) or printed / saved as PDF.
    /// </summary>
    public static class ReportRepository
    {
        public static readonly List<ReportDefinition> All = new List<ReportDefinition>
        {
            new ReportDefinition {
                Key = "revenue-month", Title = "Monthly Revenue", Category = "Finance",
                BusinessQuestion = "Is income growing month on month, and what is the average value of a payment?",
                LabelColumn = "Month", ValueColumn = "Revenue (R)", ValueIsMoney = true,
                Run = (f, t) => Table(@"SELECT CONVERT(char(7), Date, 120) AS [Month], COUNT(*) AS [Payments],
                                               SUM(Amount) AS [Revenue (R)], CAST(AVG(Amount) AS decimal(8,2)) AS [Average Payment (R)]
                                        FROM Payment WHERE Date BETWEEN @f AND @t
                                        GROUP BY CONVERT(char(7), Date, 120) ORDER BY [Month]", P("@f", f), P("@t", t)) },

            new ReportDefinition {
                Key = "revenue-service", Title = "Revenue by Treatment", Category = "Finance",
                BusinessQuestion = "Which treatments generate the most income, and what share of revenue does each contribute?",
                LabelColumn = "Treatment", ValueColumn = "Revenue (R)", ValueIsMoney = true, Complex = true,
                Run = (f, t) => Table(@"SELECT ISNULL(s.Category,'(removed)') AS [Category], pay.Service_Description AS [Treatment],
                                               COUNT(*) AS [Payments], SUM(pay.Amount) AS [Revenue (R)],
                                               CAST(100.0 * SUM(pay.Amount) / NULLIF(SUM(SUM(pay.Amount)) OVER (), 0) AS decimal(5,1)) AS [Share %]
                                        FROM Payment pay LEFT JOIN Service s ON s.Service_ID = pay.Service_ID
                                        WHERE pay.Date BETWEEN @f AND @t
                                        GROUP BY s.Category, pay.Service_Description ORDER BY [Revenue (R)] DESC", P("@f", f), P("@t", t)) },

            new ReportDefinition {
                Key = "appointment-outcomes", Title = "Appointment Outcomes & Cancellation Rate", Category = "Operations",
                BusinessQuestion = "Which treatments suffer the most cancellations or no-shows (lost capacity)?",
                LabelColumn = "Treatment", ValueColumn = "Lost %", Complex = true,
                Run = (f, t) => Table(@"SELECT Service_Name AS [Treatment], COUNT(*) AS [Total Booked],
                                               SUM(CASE WHEN Status=@done THEN 1 ELSE 0 END) AS [Completed],
                                               SUM(CASE WHEN Status=@cx THEN 1 ELSE 0 END) AS [Cancelled],
                                               SUM(CASE WHEN Status=@ns THEN 1 ELSE 0 END) AS [No-Show],
                                               CAST(100.0 * SUM(CASE WHEN Status IN (@cx,@ns) THEN 1 ELSE 0 END) / COUNT(*) AS decimal(5,1)) AS [Lost %]
                                        FROM Appointment WHERE Date BETWEEN @f AND @t
                                        GROUP BY Service_Name ORDER BY [Lost %] DESC, [Total Booked] DESC",
                                        P("@f", f), P("@t", t), P("@done", ClinicSettings.StatusCompleted),
                                        P("@cx", ClinicSettings.StatusCancelled), P("@ns", ClinicSettings.StatusNoShow)) },

            new ReportDefinition {
                Key = "busiest-days", Title = "Busiest Days of the Week", Category = "Operations",
                BusinessQuestion = "On which days should we roster more staff?",
                LabelColumn = "Day", ValueColumn = "Bookings",
                Run = (f, t) => Table(@"SELECT DATENAME(weekday, Date) AS [Day], COUNT(*) AS [Bookings],
                                               CAST(SUM(DATEDIFF(minute, Start_Time, End_Time)) / 60.0 AS decimal(8,1)) AS [Booked Hours]
                                        FROM Appointment WHERE Date BETWEEN @f AND @t AND Status <> @cx
                                        GROUP BY DATENAME(weekday, Date), DATEDIFF(day, '19000101', Date) % 7
                                        ORDER BY DATEDIFF(day, '19000101', Date) % 7", P("@f", f), P("@t", t), P("@cx", ClinicSettings.StatusCancelled)) },

            new ReportDefinition {
                Key = "busiest-hours", Title = "Peak Booking Times", Category = "Operations",
                BusinessQuestion = "Which times of day are in highest demand (for pricing and rostering)?",
                LabelColumn = "Start Hour", ValueColumn = "Bookings",
                Run = (f, t) => Table(@"SELECT RIGHT('0' + CAST(DATEPART(hour, Start_Time) AS varchar(2)), 2) + ':00' AS [Start Hour], COUNT(*) AS [Bookings]
                                        FROM Appointment WHERE Date BETWEEN @f AND @t AND Status <> @cx
                                        GROUP BY DATEPART(hour, Start_Time) ORDER BY DATEPART(hour, Start_Time)",
                                        P("@f", f), P("@t", t), P("@cx", ClinicSettings.StatusCancelled)) },

            new ReportDefinition {
                Key = "top-patients", Title = "Top Patients by Spend (Customer Value)", Category = "Patients",
                BusinessQuestion = "Who are our most valuable patients (for loyalty rewards and follow-ups)?",
                LabelColumn = "Patient", ValueColumn = "Total Spent (R)", ValueIsMoney = true, Complex = true,
                Run = (f, t) => Table(@"SELECT TOP 15 pay.Patient_FirstName + ' ' + pay.Patient_LastName AS [Patient],
                                               COUNT(DISTINCT pay.Appointment_ID) AS [Paid Visits], SUM(pay.Amount) AS [Total Spent (R)],
                                               CAST(AVG(pay.Amount) AS decimal(8,2)) AS [Average Spend (R)], MAX(pay.Date) AS [Last Payment]
                                        FROM Payment pay WHERE pay.Date BETWEEN @f AND @t
                                        GROUP BY pay.Patient_ID, pay.Patient_FirstName, pay.Patient_LastName
                                        ORDER BY [Total Spent (R)] DESC", P("@f", f), P("@t", t)) },

            new ReportDefinition {
                Key = "new-vs-returning", Title = "New vs Returning Patients", Category = "Patients",
                BusinessQuestion = "Are we attracting new patients, and are existing patients coming back (retention)?",
                LabelColumn = "Month", ValueColumn = "New Patients", Complex = true,
                Run = (f, t) => Table(@"WITH firsts AS (SELECT Patient_ID, MIN(Date) AS FirstDate FROM Appointment WHERE Status <> @cx GROUP BY Patient_ID)
                                        SELECT CONVERT(char(7), a.Date, 120) AS [Month],
                                               COUNT(DISTINCT CASE WHEN CONVERT(char(7), fi.FirstDate, 120) = CONVERT(char(7), a.Date, 120) THEN a.Patient_ID END) AS [New Patients],
                                               COUNT(DISTINCT CASE WHEN fi.FirstDate < DATEFROMPARTS(YEAR(a.Date), MONTH(a.Date), 1) THEN a.Patient_ID END) AS [Returning Patients],
                                               COUNT(DISTINCT a.Patient_ID) AS [Unique Patients]
                                        FROM Appointment a JOIN firsts fi ON fi.Patient_ID = a.Patient_ID
                                        WHERE a.Date BETWEEN @f AND @t AND a.Status <> @cx
                                        GROUP BY CONVERT(char(7), a.Date, 120) ORDER BY [Month]",
                                        P("@f", f), P("@t", t), P("@cx", ClinicSettings.StatusCancelled)) },

            new ReportDefinition {
                Key = "outstanding", Title = "Outstanding Balances (Unpaid Appointments)", Category = "Finance",
                BusinessQuestion = "How much money is owed to the clinic and which accounts need follow-up?",
                LabelColumn = "Patient", ValueColumn = "Amount Due (R)", ValueIsMoney = true,
                Run = (f, t) => Table(@"SELECT a.Patient_FirstName + ' ' + a.Patient_LastName AS [Patient], a.Service_Name AS [Treatment],
                                               a.Date AS [Appointment Date], a.Status AS [Status], ISNULL(s.Price,0) AS [Amount Due (R)],
                                               DATEDIFF(day, a.Date, GETDATE()) AS [Days Outstanding]
                                        FROM Appointment a LEFT JOIN Service s ON s.Service_ID = a.Service_ID
                                        WHERE a.Is_Paid = 0 AND a.Status <> @cx AND a.Date BETWEEN @f AND @t AND a.Date <= CAST(GETDATE() AS date)
                                        ORDER BY [Days Outstanding] DESC", P("@f", f), P("@t", t), P("@cx", ClinicSettings.StatusCancelled)) },

            new ReportDefinition {
                Key = "weight-progress", Title = "Patient Progress (Weight & Abdominal Change)", Category = "Clinical",
                BusinessQuestion = "Are treatments producing measurable results for patients (evidence of treatment effectiveness)?",
                LabelColumn = "Patient", ValueColumn = "Weight Change (kg)", Complex = true,
                Run = (f, t) => Table(@"WITH m AS (
                                            SELECT Patient_ID, Date_Recorded, Weight_kg, Abdominal_Circumference_cm,
                                                   ROW_NUMBER() OVER (PARTITION BY Patient_ID ORDER BY Date_Recorded) AS rn_first,
                                                   ROW_NUMBER() OVER (PARTITION BY Patient_ID ORDER BY Date_Recorded DESC) AS rn_last,
                                                   COUNT(*) OVER (PARTITION BY Patient_ID) AS n
                                            FROM HealthMetrics WHERE Weight_kg IS NOT NULL AND Date_Recorded >= @f AND Date_Recorded < DATEADD(day, 1, @t))
                                        SELECT p.First_Name + ' ' + p.Last_Name AS [Patient], MAX(m.n) AS [Measurements],
                                               MAX(CASE WHEN rn_first=1 THEN Weight_kg END) AS [Start Weight (kg)],
                                               MAX(CASE WHEN rn_last=1 THEN Weight_kg END) AS [Latest Weight (kg)],
                                               MAX(CASE WHEN rn_last=1 THEN Weight_kg END) - MAX(CASE WHEN rn_first=1 THEN Weight_kg END) AS [Weight Change (kg)],
                                               MAX(CASE WHEN rn_last=1 THEN Abdominal_Circumference_cm END) - MAX(CASE WHEN rn_first=1 THEN Abdominal_Circumference_cm END) AS [Abdominal Change (cm)]
                                        FROM m JOIN Patient p ON p.Patient_ID = m.Patient_ID
                                        GROUP BY p.Patient_ID, p.First_Name, p.Last_Name HAVING MAX(m.n) >= 2
                                        ORDER BY [Weight Change (kg)]", P("@f", f), P("@t", t)) },
        };

        public static ReportDefinition Find(string key)
        {
            return All.Find(r => r.Key == key) ?? All[0];
        }

        // ---------------- dashboard KPIs ----------------
        public static DataRow DashboardKpis()
        {
            return Row(@"SELECT
                    (SELECT COUNT(*) FROM Appointment WHERE Date = CAST(GETDATE() AS date) AND Status <> @cx) AS TodayAppts,
                    (SELECT COUNT(*) FROM Patient WHERE Is_Active = 1) AS ActivePatients,
                    (SELECT ISNULL(SUM(s.Price),0) FROM Appointment a JOIN Service s ON s.Service_ID=a.Service_ID
                        WHERE a.Is_Paid=0 AND a.Status <> @cx AND a.Date <= CAST(GETDATE() AS date)) AS Outstanding,
                    (SELECT ISNULL(SUM(Amount),0) FROM Payment WHERE YEAR(Date)=YEAR(GETDATE()) AND MONTH(Date)=MONTH(GETDATE())) AS MonthRevenue,
                    (SELECT COUNT(*) FROM UserAccount WHERE AccountType='Patient' AND Is_Account_Active=0 AND Is_Active=1) AS PendingAccounts",
                P("@cx", ClinicSettings.StatusCancelled));
        }
    }
}
