using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using AestheticClinicWeb.Helpers;
using static AestheticClinicWeb.Data.Db;

namespace AestheticClinicWeb.Data
{
    public static class AppointmentRepository
    {
        public static DataTable Search(DateTime? from, DateTime? to, string status, string patientTerm, int? patientId)
        {
            patientTerm = (patientTerm ?? "").Trim();
            return Table(@"SELECT a.Appointment_ID, a.Patient_ID, a.Patient_FirstName, a.Patient_LastName,
                                  a.Patient_FirstName + ' ' + a.Patient_LastName AS PatientName,
                                  a.Service_ID, a.Service_Name, a.Date, a.Start_Time, a.End_Time, a.Status, a.Is_Paid,
                                  ISNULL(s.Price, 0) AS Price
                           FROM Appointment a LEFT JOIN Service s ON s.Service_ID = a.Service_ID
                           WHERE (@from IS NULL OR a.Date >= @from) AND (@to IS NULL OR a.Date <= @to)
                             AND (@st = '' OR a.Status = @st)
                             AND (@pid IS NULL OR a.Patient_ID = @pid)
                             AND (@t = '' OR a.Patient_FirstName LIKE @like OR a.Patient_LastName LIKE @like
                                  OR (a.Patient_FirstName + ' ' + a.Patient_LastName) LIKE @like OR a.Service_Name LIKE @like
                                  OR CAST(a.Appointment_ID AS varchar(12)) = @t)
                           ORDER BY a.Date DESC, a.Start_Time DESC",
                P("@from", from), P("@to", to), P("@st", status ?? ""), P("@pid", patientId), P("@t", patientTerm), P("@like", "%" + patientTerm + "%"));
        }

        public static DataTable Upcoming(int patientId)
        {
            return Table(@"SELECT Appointment_ID, Service_Name, Date, Start_Time, End_Time, Status, Is_Paid FROM Appointment
                           WHERE Patient_ID=@p AND Status=@b AND Date >= CAST(GETDATE() AS date)
                           ORDER BY Date, Start_Time", P("@p", patientId), P("@b", ClinicSettings.StatusBooked));
        }

        public static DataTable ForDay(DateTime day)
        {
            return Table(@"SELECT Appointment_ID, Patient_ID, Patient_FirstName + ' ' + Patient_LastName AS PatientName,
                                  Service_Name, Start_Time, End_Time, Status, Is_Paid
                           FROM Appointment WHERE Date=@d ORDER BY Start_Time", P("@d", day.Date));
        }

        public static DataRow Get(int id)
        {
            return Row(@"SELECT a.*, ISNULL(s.Price,0) AS Price, ISNULL(s.Duration,0) AS Duration, p.Email AS Patient_Email, p.Contact_No
                         FROM Appointment a LEFT JOIN Service s ON s.Service_ID=a.Service_ID
                         LEFT JOIN Patient p ON p.Patient_ID=a.Patient_ID WHERE a.Appointment_ID=@i", P("@i", id));
        }

        /// <summary>Free start times for a service on a date (respects hours, existing bookings and the past).</summary>
        /// <summary>
        /// The FES stores times with seconds (e.g. 14:00:02-14:30:02, from DateTime.Now). Seconds are ignored
        /// when checking overlaps so a 2-second tail does not block the next slot.
        /// </summary>
        static TimeSpan Minute(TimeSpan t) { return new TimeSpan(t.Hours, t.Minutes, 0); }
        const string OverlapSql = "DATEADD(SECOND, -DATEPART(SECOND, Start_Time), Start_Time) < @e AND DATEADD(SECOND, -DATEPART(SECOND, End_Time), End_Time) > @s";

        public static List<TimeSpan> AvailableSlots(DateTime date, int durationMinutes)
        {
            var result = new List<TimeSpan>();
            TimeSpan open, close;
            if (date.Date < DateTime.Today || !ClinicSettings.TryGetHours(date, out open, out close)) return result;
            if (durationMinutes <= 0) durationMinutes = ClinicSettings.SlotMinutes;

            var booked = Table(@"SELECT Start_Time, End_Time FROM Appointment WHERE Date=@d AND Status <> @c",
                P("@d", date.Date), P("@c", ClinicSettings.StatusCancelled)).AsEnumerable()
                .Select(r => new { S = Minute((TimeSpan)r["Start_Time"]), E = Minute((TimeSpan)r["End_Time"]) }).ToList();

            var dur = TimeSpan.FromMinutes(durationMinutes);
            var step = TimeSpan.FromMinutes(ClinicSettings.SlotMinutes);
            var earliest = date.Date == DateTime.Today ? DateTime.Now.TimeOfDay.Add(TimeSpan.FromMinutes(30)) : TimeSpan.Zero;

            for (var t = open; t + dur <= close; t += step)
            {
                if (t < earliest) continue;
                var end = t + dur;
                int overlaps = booked.Count(b => b.S < end && b.E > t);
                if (overlaps < ClinicSettings.MaxConcurrent) result.Add(t);
            }
            return result;
        }

        /// <summary>
        /// Books an appointment inside a SERIALIZABLE transaction with UPDLOCK/HOLDLOCK so two users
        /// (website + FES, or two browsers) can never take the same slot - prevents double booking.
        /// </summary>
        public static int Book(int patientId, int serviceId, DateTime date, TimeSpan start)
        {
            TimeSpan open, close;
            if (date.Date < DateTime.Today) throw new InvalidOperationException("Appointments cannot be booked in the past.");
            if (!ClinicSettings.TryGetHours(date, out open, out close)) throw new InvalidOperationException("The clinic is closed on " + date.ToString("dddd") + "s.");

            return InTransaction((con, tx) =>
            {
                var pt = Table(con, tx, "SELECT First_Name, Last_Name, Is_Active FROM Patient WHERE Patient_ID=@p", P("@p", patientId));
                if (pt.Rows.Count == 0 || !B(pt.Rows[0], "Is_Active")) throw new InvalidOperationException("The selected patient record is not active.");
                var sv = Table(con, tx, "SELECT Service_Name, Duration FROM Service WHERE Service_ID=@s", P("@s", serviceId));
                if (sv.Rows.Count == 0) throw new InvalidOperationException("The selected treatment no longer exists.");

                int duration = I(sv.Rows[0], "Duration");          // exact service duration, same as the FES
                if (duration < 5) duration = ClinicSettings.SlotMinutes;
                var end = start.Add(TimeSpan.FromMinutes(duration));
                if (start < open || end > close)
                    throw new InvalidOperationException(string.Format("That time is outside opening hours ({0:hh\\:mm}-{1:hh\\:mm}).", open, close));
                if (date.Date == DateTime.Today && start <= DateTime.Now.TimeOfDay)
                    throw new InvalidOperationException("That time has already passed today.");

                int clash = Convert.ToInt32(Scalar(con, tx, @"SELECT COUNT(*) FROM Appointment WITH (UPDLOCK, HOLDLOCK)
                                                              WHERE Date=@d AND Status<>@c AND " + OverlapSql,
                    P("@d", date.Date), P("@c", ClinicSettings.StatusCancelled), P("@s", start), P("@e", end)));
                if (clash >= ClinicSettings.MaxConcurrent)
                    throw new InvalidOperationException("Sorry - that time slot has just been taken. Please choose another time.");

                int own = Convert.ToInt32(Scalar(con, tx, @"SELECT COUNT(*) FROM Appointment
                                                            WHERE Patient_ID=@p AND Date=@d AND Status<>@c AND " + OverlapSql,
                    P("@p", patientId), P("@d", date.Date), P("@c", ClinicSettings.StatusCancelled), P("@s", start), P("@e", end)));
                if (own > 0) throw new InvalidOperationException("This patient already has an appointment that overlaps this time.");

                return Convert.ToInt32(Scalar(con, tx, @"
                    INSERT INTO Appointment (Patient_ID, Patient_FirstName, Patient_LastName, Service_ID, Service_Name, Date, Start_Time, End_Time, Status, Is_Paid)
                    VALUES (@p,@f,@l,@sid,@sn,@d,@s,@e,@st,0); SELECT CAST(SCOPE_IDENTITY() AS int);",
                    P("@p", patientId), P("@f", S(pt.Rows[0], "First_Name")), P("@l", S(pt.Rows[0], "Last_Name")),
                    P("@sid", serviceId), P("@sn", S(sv.Rows[0], "Service_Name")), P("@d", date.Date),
                    P("@s", start), P("@e", end), P("@st", ClinicSettings.StatusBooked)));
            }, IsolationLevel.Serializable);
        }

        public static void UpdateStatus(int id, string status)
        {
            if (!ClinicSettings.AllStatuses.Contains(status)) throw new InvalidOperationException("Unknown status.");
            Execute("UPDATE Appointment SET Status=@s WHERE Appointment_ID=@i", P("@s", status), P("@i", id));
        }

        /// <summary>Patient cancellation: own appointment, still booked, with enough notice.</summary>
        public static void CancelByPatient(int id, int patientId)
        {
            var a = Get(id);
            if (a == null || I(a, "Patient_ID") != patientId) throw new InvalidOperationException("Appointment not found.");
            if (S(a, "Status") != ClinicSettings.StatusBooked) throw new InvalidOperationException("Only booked appointments can be cancelled.");
            var startsAt = D(a, "Date").Date + (TimeSpan)a["Start_Time"];
            if (startsAt - DateTime.Now < TimeSpan.FromHours(ClinicSettings.MinHoursNoticeToCancel))
                throw new InvalidOperationException("Appointments can only be cancelled online at least " + ClinicSettings.MinHoursNoticeToCancel +
                                                    " hours in advance. Please phone the clinic.");
            UpdateStatus(id, ClinicSettings.StatusCancelled);
        }

        public static bool TryDelete(int id, out string reason)
        {
            int refs = Convert.ToInt32(Scalar(@"SELECT (SELECT COUNT(*) FROM Payment WHERE Appointment_ID=@i)
                                                   + (SELECT COUNT(*) FROM HealthMetrics WHERE Appointment_ID=@i)
                                                   + (SELECT COUNT(*) FROM Results WHERE Appointment_ID=@i)", P("@i", id)));
            if (refs > 0) { reason = "This appointment has payments or clinical records linked to it. Cancel it instead of deleting."; return false; }
            Execute("DELETE FROM Appointment WHERE Appointment_ID=@i", P("@i", id));
            reason = null; return true;
        }

        public static DataTable ForDropdown(int? patientId, bool onlyNotCancelled)
        {
            return Table(@"SELECT Appointment_ID, CONVERT(varchar(10), Date, 120) + ' ' + LEFT(CONVERT(varchar(8), Start_Time), 5)
                                  + ' - ' + Patient_FirstName + ' ' + Patient_LastName + ' - ' + Service_Name AS Display
                           FROM Appointment WHERE (@p IS NULL OR Patient_ID=@p) AND (@nc = 0 OR Status <> @c)
                           ORDER BY Date DESC, Start_Time DESC",
                P("@p", patientId), P("@nc", onlyNotCancelled ? 1 : 0), P("@c", ClinicSettings.StatusCancelled));
        }
    }
}
