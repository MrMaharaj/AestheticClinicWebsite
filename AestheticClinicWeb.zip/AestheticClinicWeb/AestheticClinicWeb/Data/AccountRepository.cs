using System;
using System.Data;
using System.Text.RegularExpressions;
using AestheticClinicWeb.Helpers;
using AestheticClinicWeb.Security;
using static AestheticClinicWeb.Data.Db;

namespace AestheticClinicWeb.Data
{
    /// <summary>
    /// SECURITY ARCHITECTURE - Unified Login Credentials
    ///
    /// All login credentials (Staff + Patient) are now stored in the UserAccount table for better security.
    ///
    /// UserAccount table structure:
    ///  * Email          : Unique login identifier
    ///  * Password       : PBKDF2 hash (for website) or plain text (for FES staff)
    ///  * Role           : 'Patient', 'Doctor', 'Receptionist', 'Admin', etc.
    ///  * AccountType    : 'Patient' or 'Staff'
    ///  * Patient_ID     : Reference to Patient table (for patients only)
    ///  * Staff_ID       : Reference to Staff table (for staff only)
    ///  * Is_Active      : Account status (separate from Patient.Is_Active or Staff.Is_Active)
    ///  * Is_First_Login : Must create own password at next login
    ///  * Is_Account_Active : May log in (staff can deactivate specific accounts)
    ///  * Security_Question / Security_Answer : For "Forgot password"
    ///
    /// Benefits:
    ///  1. Centralized credential management
    ///  2. Better audit trail (who logged in, when)
    ///  3. Easier to implement account lockouts, expiry, MFA
    ///  4. Separation of concerns (credentials != patient/staff data)
    ///  5. GDPR compliance - easier to purge old credentials
    /// </summary>
    public static class AccountRepository
    {
        public class LoginResult { public ClinicIdentity Identity; public string Error; }
        const string BadLogin = "Login Unsuccessful. Username and/or Password incorrect.";

        /// <summary>
        /// Unified login check for both staff and patients.
        /// Looks up credentials in the UserAccount table.
        /// </summary>
        public static LoginResult Login(string email, string password)
        {
            email = (email ?? "").Trim();

            // STEP 1: Check UserAccount table (new unified credentials for patients and migrated staff)
            var ua = Row(@"SELECT User_ID, Email, [Password], [Role], AccountType, Patient_ID, Staff_ID, 
                                   Is_Active, Is_First_Login, Is_Account_Active
                            FROM UserAccount WHERE Email = @e", P("@e", email));

            if (ua != null)
            {
                // Verify password in UserAccount
                if (!PasswordHasher.Verify(password, S(ua, "Password")))
                    return new LoginResult { Error = BadLogin };

                // Check if account is active
                if (!B(ua, "Is_Active"))
                    return new LoginResult { Error = "This account has been deactivated. Please contact the clinic administrator." };

                if (!B(ua, "Is_Account_Active"))
                    return new LoginResult { Error = "This account is not active yet (or has been deactivated). Please contact the clinic." };

                string accountType = S(ua, "AccountType").Trim();
                string role = S(ua, "Role").Trim();

                if (accountType == "Staff")
                {
                    int staffId = I(ua, "Staff_ID");
                    var staff = Row("SELECT First_Name, Last_Name FROM Staff WHERE Staff_ID=@id", P("@id", staffId));
                    if (staff == null)
                        return new LoginResult { Error = "Staff record not found. Please contact administration." };

                    return new LoginResult
                    {
                        Identity = new ClinicIdentity
                        {
                            Kind = AccountKind.Staff,
                            AccountId = staffId,
                            Email = S(ua, "Email").Trim(),
                            FullName = (S(staff, "First_Name") + " " + S(staff, "Last_Name")).Trim(),
                            DbRole = role,
                            IsAdmin = Auth.IsAdminRole(role),
                            MustChangePassword = B(ua, "Is_First_Login")
                        }
                    };
                }
                else if (accountType == "Patient")
                {
                    int patientId = I(ua, "Patient_ID");
                    var patient = Row("SELECT First_Name, Last_Name, Is_Active FROM Patient WHERE Patient_ID=@id", P("@id", patientId));
                    if (patient == null)
                        return new LoginResult { Error = "Patient record not found. Please contact the clinic." };

                    if (!B(patient, "Is_Active"))
                        return new LoginResult { Error = "Your patient record is no longer active. Please contact the clinic." };

                    return new LoginResult
                    {
                        Identity = new ClinicIdentity
                        {
                            Kind = AccountKind.Patient,
                            AccountId = patientId,
                            PatientId = patientId,
                            Email = S(ua, "Email").Trim(),
                            FullName = (S(patient, "First_Name") + " " + S(patient, "Last_Name")).Trim(),
                            DbRole = ClinicSettings.PatientRole,
                            MustChangePassword = B(ua, "Is_First_Login")
                        }
                    };
                }
            }

            // Not found in UserAccount
            return new LoginResult { Error = BadLogin };
        }

        /// <summary>Check if an email is already registered as a login (staff or patient with online account)</summary>
        public static bool EmailInUse(string email, int? exceptStaffId = null, int? exceptPatientId = null)
        {
            var n = Convert.ToInt32(Scalar(@"
                SELECT COUNT(*) FROM UserAccount 
                WHERE Email = @e 
                  AND (Staff_ID IS NULL OR Staff_ID <> ISNULL(@s, -1))
                  AND (Patient_ID IS NULL OR Patient_ID <> ISNULL(@p, -1))",
                P("@e", email.Trim()), P("@s", exceptStaffId), P("@p", exceptPatientId)));
            return n > 0;
        }

        // ============================================================================
        // PATIENT REGISTRATION - Creates credentials in UserAccount table
        // ============================================================================

        public class Registration
        {
            public string FirstName, LastName, IdNumber, Address, Phone, Email, Allergies, Password, Question, Answer;
            public char Gender; public DateTime Dob;
        }

        /// <summary>
        /// Registers a new patient with an online account, or links the account to an existing patient record.
        /// Creates credentials in the unified UserAccount table.
        /// Returns true if the account is active immediately (Accounts:AutoApprovePatients),
        /// false if staff must activate it in Manage Accounts.
        /// </summary>
        public static bool RegisterPatient(Registration r, out bool linkedExisting)
        {
            bool linked = false, active = ClinicSettings.AutoApprovePatients;
            InTransaction((con, tx) =>
            {
                // Find existing patient by ID number
                var existing = Table(con, tx, "SELECT Patient_ID, Email, Contact_No FROM Patient WHERE ID_Number = @id", P("@id", r.IdNumber));
                string pw = PasswordHasher.Hash(r.Password);
                string ans = PasswordHasher.Hash(NormaliseAnswer(r.Answer));

                if (existing.Rows.Count > 0)
                {
                    // Link to existing patient record
                    var e = existing.Rows[0];
                    int patientId = I(e, "Patient_ID");

                    // Check if this patient already has a login
                    int existingLogin = Convert.ToInt32(Scalar(con, tx, 
                        "SELECT COUNT(*) FROM UserAccount WHERE Patient_ID=@pid", P("@pid", patientId)));
                    if (existingLogin > 0)
                        throw new InvalidOperationException("You already have an online account. Log in with the temporary password the clinic emailed you, or use 'Forgot password'.");

                    // Verify email or phone matches
                    bool emailMatch = string.Equals(S(e, "Email").Trim(), r.Email.Trim(), StringComparison.OrdinalIgnoreCase);
                    bool phoneMatch = S(e, "Contact_No").Trim() == r.Phone.Trim();
                    if (!emailMatch && !phoneMatch)
                        throw new InvalidOperationException("We already have a patient record for this ID number, but the email and cell number don't match our records. Please contact reception to update your details.");

                    // Create login in UserAccount
                    Execute(con, tx, @"
                        INSERT INTO UserAccount (Email, [Password], [Role], AccountType, Patient_ID, Is_Active, 
                                                 Is_First_Login, Is_Account_Active, Security_Question, Security_Answer)
                        VALUES (@e, @pw, 'Patient', 'Patient', @pid, 1, 0, @a, @q, @ans)",
                        P("@e", r.Email), P("@pw", pw), P("@pid", patientId), 
                        P("@a", active), P("@q", r.Question), P("@ans", ans));

                    // Update patient email if different
                    if (!emailMatch)
                    {
                        Execute(con, tx, "UPDATE Patient SET Email=@e WHERE Patient_ID=@pid",
                            P("@e", r.Email), P("@pid", patientId));
                    }

                    linked = true;
                }
                else
                {
                    // Create new patient record
                    int newPatientId = Convert.ToInt32(Scalar(con, tx, @"
                        INSERT INTO Patient (First_Name, Last_Name, ID_Number, Gender, Date_Of_Birth, Address, Contact_No, Email, Allergies, Extra_Notes, Is_Active)
                        VALUES (@f, @l, @id, @g, @dob, @ad, @c, @e, @al, NULL, 1);
                        SELECT CAST(SCOPE_IDENTITY() AS int);",
                        P("@f", r.FirstName), P("@l", r.LastName), P("@id", r.IdNumber), P("@g", r.Gender.ToString()),
                        P("@dob", r.Dob), P("@ad", r.Address), P("@c", r.Phone), P("@e", r.Email),
                        new System.Data.SqlClient.SqlParameter("@al", SqlDbType.Text) { Value = string.IsNullOrWhiteSpace(r.Allergies) ? (object)DBNull.Value : r.Allergies }));

                    // Create login in UserAccount
                    Execute(con, tx, @"
                        INSERT INTO UserAccount (Email, [Password], [Role], AccountType, Patient_ID, Is_Active, 
                                                 Is_First_Login, Is_Account_Active, Security_Question, Security_Answer)
                        VALUES (@e, @pw, 'Patient', 'Patient', @pid, 1, 0, @a, @q, @ans)",
                        P("@e", r.Email), P("@pw", pw), P("@pid", newPatientId),
                        P("@a", active), P("@q", r.Question), P("@ans", ans));
                }
                return 0;
            });
            linkedExisting = linked;
            return active;
        }

        /// <summary>Same normalisation as the FES: trimmed, lower case, single spaces.</summary>
        static string NormaliseAnswer(string a) { return Regex.Replace((a ?? "").Trim().ToLowerInvariant(), @"\s+", " "); }

        // ============================================================================
        // FORGOT PASSWORD
        // ============================================================================

        public static string GetSecurityQuestion(string email, out AccountKind kind, out int id)
        {
            kind = AccountKind.Staff; id = 0;
            var ua = Row("SELECT User_ID, AccountType, Staff_ID, Patient_ID, Security_Question FROM UserAccount WHERE Email=@e AND Is_Active=1", P("@e", email.Trim()));
            if (ua == null) return null;

            string accountType = S(ua, "AccountType").Trim();
            if (accountType == "Staff")
            {
                kind = AccountKind.Staff;
                id = I(ua, "Staff_ID");
            }
            else
            {
                kind = AccountKind.Patient;
                id = I(ua, "Patient_ID");
            }
            return Usable(S(ua, "Security_Question"));
        }

        static string Usable(string q)
        {
            q = (q ?? "").Trim();
            return (q == "" || q.Equals("unknown", StringComparison.OrdinalIgnoreCase) || q.Equals("Not Set", StringComparison.OrdinalIgnoreCase)) ? "" : q;
        }

        public static bool CheckSecurityAnswer(AccountKind kind, int id, string answer)
        {
            string stored = Convert.ToString(kind == AccountKind.Staff
                ? Scalar("SELECT Security_Answer FROM UserAccount WHERE Staff_ID=@i", P("@i", id))
                : Scalar("SELECT Security_Answer FROM UserAccount WHERE Patient_ID=@i", P("@i", id)));
            if (PasswordHasher.IsHashed(stored)) return PasswordHasher.Verify(NormaliseAnswer(answer), stored);
            // Same rule as the FES: lower case, ALL whitespace removed, then compare.
            string a2 = Regex.Replace((answer ?? "").ToLowerInvariant(), @"\s+", "");
            string s2 = Regex.Replace((stored ?? "").ToLowerInvariant(), @"\s+", "");
            return a2.Length > 0 && a2 == s2;
        }

        /// <summary>
        /// Sets a new password for staff or patient.
        /// For patients, Is_First_Login is cleared only after the password is saved successfully.
        /// </summary>
        public static void SetPassword(AccountKind kind, int id, string newPassword)
        {
            if (kind == AccountKind.Staff)
                Execute("UPDATE UserAccount SET [Password]=@p, Is_First_Login=0 WHERE Staff_ID=@i", 
                    P("@p", PasswordHasher.ForStorage(newPassword)), P("@i", id));
            else
                Execute("UPDATE UserAccount SET [Password]=@p, Is_First_Login=0 WHERE Patient_ID=@i", 
                    P("@p", PasswordHasher.Hash(newPassword)), P("@i", id));
        }

        public static bool VerifyCurrentPassword(AccountKind kind, int id, string password)
        {
            string stored = Convert.ToString(kind == AccountKind.Staff
                ? Scalar("SELECT [Password] FROM UserAccount WHERE Staff_ID=@i", P("@i", id))
                : Scalar("SELECT [Password] FROM UserAccount WHERE Patient_ID=@i", P("@i", id)));
            return PasswordHasher.Verify(password, stored);
        }

        public static void SetSecurityQuestion(AccountKind kind, int id, string q, string a)
        {
            if (kind == AccountKind.Staff)
                Execute("UPDATE UserAccount SET Security_Question=@q, Security_Answer=@a WHERE Staff_ID=@i",
                    P("@q", Check.Trunc(q, 225)), P("@a", PasswordHasher.ForStorage(NormaliseAnswer(a))), P("@i", id));
            else
                Execute("UPDATE UserAccount SET Security_Question=@q, Security_Answer=@a WHERE Patient_ID=@i",
                    P("@q", Check.Trunc(q, 225)), P("@a", PasswordHasher.Hash(NormaliseAnswer(a))), P("@i", id));
        }

        // ============================================================================
        // ADMIN: STAFF ACCOUNTS (managed in UserAccount table)
        // ============================================================================

        public static DataTable Staff(string search)
        {
            return Table(@"SELECT ua.User_ID, s.Staff_ID, s.First_Name, s.Last_Name, ua.Email, ua.Role, ua.Is_Active, ua.Is_First_Login 
                           FROM UserAccount ua
                           JOIN Staff s ON ua.Staff_ID = s.Staff_ID
                           WHERE ua.AccountType = 'Staff'
                             AND (@s = '' OR s.First_Name LIKE @like OR s.Last_Name LIKE @like OR ua.Email LIKE @like OR ua.Role LIKE @like)
                           ORDER BY s.Last_Name, s.First_Name",
                P("@s", (search ?? "").Trim()), P("@like", "%" + (search ?? "").Trim() + "%"));
        }

        public static DataRow GetStaff(int id) 
        { 
            return Row("SELECT ua.*, s.First_Name, s.Last_Name FROM UserAccount ua JOIN Staff s ON ua.Staff_ID = s.Staff_ID WHERE s.Staff_ID=@i", P("@i", id)); 
        }

        public static int AddStaff(string first, string last, string email, string role, string tempPassword)
        {
            int staffId = 0;
            InTransaction((con, tx) =>
            {
                // Create Staff record (no credentials here - they go to UserAccount only)
                staffId = Convert.ToInt32(Scalar(con, tx, @"INSERT INTO Staff (First_Name, Last_Name, Email, Is_Active)
                                            VALUES (@f, @l, @e, 1); SELECT CAST(SCOPE_IDENTITY() AS int);",
                    P("@f", first), P("@l", last), P("@e", email)));

                // Create UserAccount record with all credentials
                Execute(con, tx, @"INSERT INTO UserAccount (Email, [Password], [Role], AccountType, Staff_ID, Is_Active, Is_First_Login, Is_Account_Active)
                                   VALUES (@e, @p, @r, 'Staff', @sid, 1, 1, 1)",
                    P("@e", email), P("@p", PasswordHasher.ForStorage(tempPassword)), P("@r", role), P("@sid", staffId));
                return 0;
            });
            return staffId;
        }




        public static void UpdateStaff(int id, string first, string last, string email, string role)
        {
            // Update Staff table: name and email only (no credentials)
            Execute("UPDATE Staff SET First_Name=@f, Last_Name=@l, Email=@e WHERE Staff_ID=@i",
                P("@f", first), P("@l", last), P("@e", email), P("@i", id));
            // Update UserAccount table: email and role (all credentials managed here)
            Execute("UPDATE UserAccount SET Email=@e, [Role]=@r WHERE Staff_ID=@i",
                P("@e", email), P("@r", role), P("@i", id));
        }

        public static void SetStaffActive(int id, bool active)
        {
            Execute("UPDATE UserAccount SET Is_Active=@a WHERE Staff_ID=@i", P("@a", active), P("@i", id));
        }

        public static void ResetStaffPassword(int id, string tempPassword)
        {
            Execute("UPDATE UserAccount SET [Password]=@p, Is_First_Login=1 WHERE Staff_ID=@i", 
                P("@p", PasswordHasher.ForStorage(tempPassword)), P("@i", id));
        }

        // ============================================================================
        // ADMIN: PATIENT ONLINE ACCOUNTS (in UserAccount table)
        // ============================================================================

        public const string StateActive = "Active", StateFirstLogin = "Awaiting first login", StateInactive = "Deactivated", StateNone = "No online account";

        const string StateSql = @"CASE WHEN ua.User_ID IS NULL THEN 'No online account'
                                       WHEN ua.Is_Account_Active = 0 THEN 'Deactivated'
                                       WHEN ua.Is_First_Login = 1 THEN 'Awaiting first login'
                                       ELSE 'Active' END";

        /// <summary>List patient accounts from the unified UserAccount table. Filter by state or search term.</summary>
        public static DataTable PatientAccounts(string filter, string search)
        {
            search = (search ?? "").Trim();
            return Table(@"SELECT * FROM (
                               SELECT p.Patient_ID, p.First_Name + ' ' + p.Last_Name AS FullName, ISNULL(ua.Email, p.Email) AS Email, 
                                      p.Contact_No, p.Is_Active, " + StateSql + @" AS AccountState
                               FROM Patient p
                               LEFT JOIN UserAccount ua ON ua.Patient_ID = p.Patient_ID AND ua.AccountType = 'Patient') x
                           WHERE (@f = '' OR AccountState = @f)
                             AND (@s = '' OR FullName LIKE @like OR Email LIKE @like OR CAST(Patient_ID AS varchar(12)) = @s)
                           ORDER BY CASE AccountState WHEN 'Deactivated' THEN 0 WHEN 'Awaiting first login' THEN 1 WHEN 'Active' THEN 2 ELSE 3 END, FullName",
                P("@f", filter ?? ""), P("@s", search), P("@like", "%" + search + "%"));
        }

        public static string PatientAccountState(int patientId)
        {
            return Convert.ToString(Scalar(@"SELECT " + StateSql + " FROM Patient p LEFT JOIN UserAccount ua ON ua.Patient_ID = p.Patient_ID AND ua.AccountType = 'Patient' WHERE p.Patient_ID=@p", P("@p", patientId)));
        }

        public static void SetPatientAccountActive(int patientId, bool active)
        {
            int n = Execute("UPDATE UserAccount SET Is_Account_Active=@a WHERE Patient_ID=@p AND AccountType='Patient'", 
                P("@a", active), P("@p", patientId));
            if (n == 0) throw new InvalidOperationException("This patient has no online account yet - issue a temporary password first.");
        }

        /// <summary>
        /// Creates or resets a patient's online account with a temporary password and forces a new password at next login.
        /// Returns the patient's email.
        /// </summary>
        public static string IssueTempPassword(int patientId, string tempPassword)
        {
            var p = Row("SELECT Email, Is_Active FROM Patient WHERE Patient_ID=@p", P("@p", patientId));
            if (p == null) throw new InvalidOperationException("Patient not found.");
            if (!B(p, "Is_Active")) throw new InvalidOperationException("This patient record is archived. Reactivate the patient first.");
            string email = S(p, "Email").Trim();
            if (!Check.Email(email)) throw new InvalidOperationException("This patient has no valid email address. Update their details first.");

            // Check if email is in use elsewhere
            int count = Convert.ToInt32(Scalar(@"
                SELECT COUNT(*) FROM UserAccount 
                WHERE Email = @e AND Patient_ID <> @pid", 
                P("@e", email), P("@pid", patientId)));
            if (count > 0) throw new InvalidOperationException("This email is already in use. Give this patient a unique email first.");

            // Check if patient already has a UserAccount; if so, update it; otherwise create it
            int existing = Convert.ToInt32(Scalar("SELECT COUNT(*) FROM UserAccount WHERE Patient_ID=@pid AND AccountType='Patient'", P("@pid", patientId)));

            if (existing > 0)
            {
                Execute(@"UPDATE UserAccount SET [Password]=@pw, Is_First_Login=1, Is_Account_Active=1, Email=@e WHERE Patient_ID=@pid AND AccountType='Patient'",
                    P("@pw", tempPassword), P("@e", email), P("@pid", patientId));
            }
            else
            {
                Execute(@"INSERT INTO UserAccount (Email, [Password], [Role], AccountType, Patient_ID, Is_Active, Is_First_Login, Is_Account_Active)
                         VALUES (@e, @pw, 'Patient', 'Patient', @pid, 1, 1, 1)",
                    P("@e", email), P("@pw", tempPassword), P("@pid", patientId));
            }
            return email;
        }

        /// <summary>Online accounts waiting for staff activation (self-registered on the website).</summary>
        public static int PendingAccountCount()
        {
            return Convert.ToInt32(Scalar("SELECT COUNT(*) FROM UserAccount WHERE AccountType='Patient' AND Is_Account_Active=0 AND Is_Active=1"));
        }
    }
}
