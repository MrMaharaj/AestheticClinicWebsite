using System;
using System.Data;
using System.Data.SqlClient;
using static AestheticClinicWeb.Data.Db;

namespace AestheticClinicWeb.Data
{
    /// <summary>HealthMetrics and Results (before/after images) - captured by staff, viewed by patients.</summary>
    public static class ClinicalRepository
    {
        static SqlParameter Img(string name, byte[] data)
        {
            return new SqlParameter(name, SqlDbType.VarBinary, -1) { Value = data == null || data.Length == 0 ? (object)DBNull.Value : data };
        }
        static object Dec(decimal? v) { return v.HasValue ? (object)v.Value : DBNull.Value; }

        // ---------------- HealthMetrics ----------------
        public static DataTable Metrics(int? patientId)
        {
            return Table(@"SELECT m.Metric_ID, m.Appointment_ID, m.Patient_ID, p.First_Name + ' ' + p.Last_Name AS PatientName,
                                  m.Date_Recorded, m.Weight_kg, m.Abdominal_Circumference_cm, m.Height_cm, m.Blood_Pressure, m.Notes,
                                  CASE WHEN m.Height_cm > 0 AND m.Weight_kg > 0
                                       THEN CAST(m.Weight_kg / ((m.Height_cm/100.0)*(m.Height_cm/100.0)) AS decimal(5,1)) END AS BMI,
                                  CASE WHEN m.Progress_Image IS NULL THEN 0 ELSE 1 END AS HasImage
                           FROM HealthMetrics m JOIN Patient p ON p.Patient_ID=m.Patient_ID
                           WHERE (@p IS NULL OR m.Patient_ID=@p) ORDER BY m.Date_Recorded DESC", P("@p", patientId));
        }

        public static int AddMetric(int appointmentId, decimal? weight, decimal? abdominal, decimal? height, string bp, string notes, byte[] image)
        {
            var appt = Row("SELECT Patient_ID FROM Appointment WHERE Appointment_ID=@a", P("@a", appointmentId));
            if (appt == null) throw new InvalidOperationException("Appointment not found.");
            return Convert.ToInt32(Scalar(@"INSERT INTO HealthMetrics (Appointment_ID, Patient_ID, Date_Recorded, Weight_kg, Abdominal_Circumference_cm, Height_cm, Blood_Pressure, Notes, Progress_Image)
                                            VALUES (@a,@p,GETDATE(),@w,@ab,@h,@bp,@n,@img); SELECT CAST(SCOPE_IDENTITY() AS int);",
                P("@a", appointmentId), P("@p", I(appt, "Patient_ID")), P("@w", Dec(weight)), P("@ab", Dec(abdominal)), P("@h", Dec(height)),
                P("@bp", string.IsNullOrWhiteSpace(bp) ? null : bp.Trim()), P("@n", string.IsNullOrWhiteSpace(notes) ? null : notes.Trim()), Img("@img", image)));
        }

        public static void DeleteMetric(int id) { Execute("DELETE FROM HealthMetrics WHERE Metric_ID=@i", P("@i", id)); }

        // ---------------- Results ----------------
        public static DataTable Results(int? patientId)
        {
            return Table(@"SELECT Result_ID, Appointment_ID, Patient_ID, Patient_FirstName + ' ' + Patient_LastName AS PatientName,
                                  Result_Date, Service, Result, Notes,
                                  CASE WHEN Before_Image IS NULL THEN 0 ELSE 1 END AS HasBefore,
                                  CASE WHEN After_Image IS NULL THEN 0 ELSE 1 END AS HasAfter
                           FROM Results WHERE (@p IS NULL OR Patient_ID=@p) ORDER BY Result_Date DESC, Result_ID DESC", P("@p", patientId));
        }

        public static int AddResult(int appointmentId, DateTime resultDate, string result, string notes, byte[] before, byte[] after)
        {
            var a = Row("SELECT Patient_ID, Patient_FirstName, Patient_LastName, Service_Name FROM Appointment WHERE Appointment_ID=@a", P("@a", appointmentId));
            if (a == null) throw new InvalidOperationException("Appointment not found.");
            return Convert.ToInt32(Scalar(@"INSERT INTO Results (Appointment_ID, Patient_ID, Patient_FirstName, Patient_LastName, Result_Date, Service, Result, Notes, Before_Image, After_Image)
                                            VALUES (@a,@p,@f,@l,@d,@s,@r,@n,@b,@af); SELECT CAST(SCOPE_IDENTITY() AS int);",
                P("@a", appointmentId), P("@p", I(a, "Patient_ID")), P("@f", S(a, "Patient_FirstName")), P("@l", S(a, "Patient_LastName")),
                P("@d", resultDate.Date), P("@s", S(a, "Service_Name")), P("@r", string.IsNullOrWhiteSpace(result) ? null : result.Trim()),
                P("@n", string.IsNullOrWhiteSpace(notes) ? null : notes.Trim()), Img("@b", before), Img("@af", after)));
        }

        public static void DeleteResult(int id) { Execute("DELETE FROM Results WHERE Result_ID=@i", P("@i", id)); }

        /// <summary>Returns image bytes and owning Patient_ID (for the authorisation check in Image.ashx).</summary>
        public static byte[] GetImage(string kind, int id, out int ownerPatientId)
        {
            ownerPatientId = 0;
            string sql;
            switch (kind)
            {
                case "before": sql = "SELECT Patient_ID, Before_Image AS Img FROM Results WHERE Result_ID=@i"; break;
                case "after": sql = "SELECT Patient_ID, After_Image AS Img FROM Results WHERE Result_ID=@i"; break;
                case "metric": sql = "SELECT Patient_ID, Progress_Image AS Img FROM HealthMetrics WHERE Metric_ID=@i"; break;
                default: return null;
            }
            var r = Row(sql, P("@i", id));
            if (r == null || r.IsNull("Img")) return null;
            ownerPatientId = I(r, "Patient_ID");
            return (byte[])r["Img"];
        }
    }
}
