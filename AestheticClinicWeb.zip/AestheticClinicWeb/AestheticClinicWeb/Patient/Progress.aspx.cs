using System;
using System.Data;
using System.Linq;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;

namespace AestheticClinicWeb.PatientArea
{
    public partial class Progress : PatientPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            Safe(lblMsg, () =>
            {
                var m = ClinicalRepository.Metrics(PatientId);
                gvMetrics.DataSource = m; gvMetrics.DataBind();

                var weights = m.AsEnumerable().Where(r => !r.IsNull("Weight_kg")).OrderBy(r => r.Field<DateTime>("Date_Recorded")).ToList();
                if (weights.Count > 0)
                {
                    var chart = new DataTable();
                    chart.Columns.Add("Date"); chart.Columns.Add("Weight (kg)", typeof(decimal));
                    foreach (var r in weights) chart.Rows.Add(Ui.Date(r["Date_Recorded"]), r["Weight_kg"]);
                    litChart.Text = Ui.BarChart(chart, "Date", "Weight (kg)", false);
                    if (weights.Count >= 2)
                    {
                        decimal diff = weights.Last().Field<decimal>("Weight_kg") - weights.First().Field<decimal>("Weight_kg");
                        litSummary.Text = "<p class=\"msg " + (diff <= 0 ? "msg-ok" : "msg-info") + "\">Change since your first measurement: <strong>" +
                                          (diff > 0 ? "+" : "") + diff.ToString("0.0", Inv) + " kg</strong> over " + weights.Count + " measurements.</p>";
                    }
                }
                else litChart.Text = "<div class=\"empty\">Your weight trend will appear here once measurements are recorded.</div>";

                var res = ClinicalRepository.Results(PatientId);
                rptResults.DataSource = res; rptResults.DataBind();
                phNoResults.Visible = res.Rows.Count == 0;
            });
        }
    }
}
