using System;
using System.Data;
using System.Web.UI.WebControls;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;

namespace AestheticClinicWeb.PatientArea
{
    public partial class Appointments : PatientPage
    {
        protected void Page_Load(object sender, EventArgs e) { if (!IsPostBack) Bind(); }

        protected void ddlShow_Changed(object sender, EventArgs e) { Bind(); }

        void Bind()
        {
            Safe(lblMsg, () =>
            {
                DateTime? from = null, to = null;
                if (ddlShow.SelectedValue == "upcoming") from = DateTime.Today;
                else if (ddlShow.SelectedValue == "past") to = DateTime.Today.AddDays(-1);
                DataTable dt = AppointmentRepository.Search(from, to, "", "", PatientId);
                if (ddlShow.SelectedValue == "upcoming") dt.DefaultView.Sort = "Date ASC, Start_Time ASC";
                gv.DataSource = dt.DefaultView; gv.DataBind();
            });
        }

        protected bool CanCancel(object status, object date, object start)
        {
            if (Convert.ToString(status) != ClinicSettings.StatusBooked) return false;
            var when = Convert.ToDateTime(date).Date + (TimeSpan)start;
            return when - DateTime.Now >= TimeSpan.FromHours(ClinicSettings.MinHoursNoticeToCancel);
        }

        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName != "CancelAppt") return;
            int id = Convert.ToInt32(e.CommandArgument);
            if (Safe(lblMsg, () => AppointmentRepository.CancelByPatient(id, PatientId)))
                Ok(lblMsg, "Your appointment has been cancelled. The time slot has been released and the clinic's system has been updated.");
            Bind();
        }
    }
}
