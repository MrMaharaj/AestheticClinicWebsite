using System;
using System.Data;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;

namespace AestheticClinicWeb.PatientArea
{
    public partial class Invoices : PatientPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            Safe(lblMsg, () =>
            {
                var unpaid = PaymentRepository.Unpaid(PatientId);
                var paid = PaymentRepository.Search(null, null, "", PatientId);
                gvUnpaid.DataSource = unpaid; gvUnpaid.DataBind();
                gvPaid.DataSource = paid; gvPaid.DataBind();

                decimal due = 0, future = 0, total = 0;
                foreach (DataRow r in unpaid.Rows)
                    if (Convert.ToDateTime(r["Date"]) <= DateTime.Today) due += Convert.ToDecimal(r["Price"]); else future += Convert.ToDecimal(r["Price"]);
                foreach (DataRow r in paid.Rows) total += Convert.ToDecimal(r["Amount"]);
                litDue.Text = Ui.Money(due); litFuture.Text = Ui.Money(future); litPaid.Text = Ui.Money(total);
            });
        }
    }
}
