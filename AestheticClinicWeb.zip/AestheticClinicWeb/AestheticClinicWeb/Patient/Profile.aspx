<%@ Page Title="My Profile" Language="C#" MasterPageFile="~/App.Master" AutoEventWireup="true" CodeBehind="Profile.aspx.cs" Inherits="AestheticClinicWeb.PatientArea.Profile" %>
<asp:Content ID="c1" ContentPlaceHolderID="WorkContent" runat="server">
    <h1>My Profile</h1>
    <div class="crumb">My Account &rsaquo; Profile</div>
    <asp:Label ID="lblMsg" runat="server" Visible="false" />

    <div class="grid grid-2">
        <div class="panel">
            <h3>Personal details</h3>
            <p class="hint">These are managed by reception. Contact the clinic to correct them.</p>
            <dl class="kv">
                <dt>Patient number</dt><dd><asp:Literal ID="litPid" runat="server" /></dd>
                <dt>Name</dt><dd><asp:Literal ID="litName" runat="server" /></dd>
                <dt>ID number</dt><dd><asp:Literal ID="litId" runat="server" /></dd>
                <dt>Date of birth</dt><dd><asp:Literal ID="litDob" runat="server" /></dd>
                <dt>Gender</dt><dd><asp:Literal ID="litGender" runat="server" /></dd>
            </dl>
        </div>

        <asp:Panel ID="pnlEdit" runat="server" CssClass="panel" DefaultButton="btnSave">
            <h3>Contact details &amp; allergies</h3>
            <asp:ValidationSummary ID="vs" runat="server" CssClass="msg msg-err" ValidationGroup="prof" />
            <div class="field">
                <label for="<%= txtAddress.ClientID %>">Address</label>
                <asp:TextBox ID="txtAddress" runat="server" MaxLength="100" />
                <asp:RequiredFieldValidator ID="rfvA" runat="server" ControlToValidate="txtAddress" ErrorMessage="Address is required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="prof" />
            </div>
            <div class="field">
                <label for="<%= txtPhone.ClientID %>">Cell number</label>
                <asp:TextBox ID="txtPhone" runat="server" MaxLength="10" inputmode="tel" />
                <asp:RequiredFieldValidator ID="rfvP" runat="server" ControlToValidate="txtPhone" ErrorMessage="Cell number is required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="prof" />
                <asp:RegularExpressionValidator ID="revP" runat="server" ControlToValidate="txtPhone" ValidationExpression="^\d{10}$" ErrorMessage="Cell number must be 10 digits starting with 0." Text="Must be 10 digits" Display="Dynamic" CssClass="val" ValidationGroup="prof" />
            </div>
            <div class="field">
                <label for="<%= txtEmail.ClientID %>">Email (also your login)</label>
                <asp:TextBox ID="txtEmail" runat="server" TextMode="Email" MaxLength="50" />
                <asp:RequiredFieldValidator ID="rfvE" runat="server" ControlToValidate="txtEmail" ErrorMessage="Email is required." Text="Required" Display="Dynamic" CssClass="val" ValidationGroup="prof" />
                <asp:RegularExpressionValidator ID="revE" runat="server" ControlToValidate="txtEmail" ValidationExpression="^[^@\s]+@[^@\s]+\.[^@\s]{2,}$" ErrorMessage="Enter a valid email address." Text="Invalid email" Display="Dynamic" CssClass="val" ValidationGroup="prof" />
            </div>
            <div class="field">
                <label for="<%= txtAllergies.ClientID %>">Allergies</label>
                <asp:TextBox ID="txtAllergies" runat="server" TextMode="MultiLine" Rows="3" MaxLength="500" />
                <div class="hint">Important for your safety - please keep this up to date.</div>
            </div>
            <asp:Button ID="btnSave" runat="server" Text="Save changes" CssClass="btn-sm" OnClick="btnSave_Click" ValidationGroup="prof" />
        </asp:Panel>
    </div>
</asp:Content>
