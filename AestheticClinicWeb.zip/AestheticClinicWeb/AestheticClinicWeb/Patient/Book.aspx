<%@ Page Title="Book Appointment" Language="C#" MasterPageFile="~/App.Master" AutoEventWireup="true" CodeBehind="Book.aspx.cs" Inherits="AestheticClinicWeb.PatientArea.Book" %>
<asp:Content ID="c1" ContentPlaceHolderID="WorkContent" runat="server">
    <h1>Book an Appointment</h1>
    <div class="crumb">My Account &rsaquo; Book appointment</div>
    <asp:Label ID="lblMsg" runat="server" Visible="false" />

    <div class="booking">
        <div class="panel">
            <h3><span class="step-n sm">1</span> Choose a treatment and date</h3>
            <div class="grid grid-2">
                <div class="field">
                    <label for="<%= ddlService.ClientID %>">Treatment</label>
                    <asp:DropDownList ID="ddlService" runat="server" AutoPostBack="true" OnSelectedIndexChanged="Criteria_Changed" />
                </div>
                <div class="field">
                    <label for="<%= txtDate.ClientID %>">Date</label>
                    <asp:TextBox ID="txtDate" runat="server" TextMode="Date" AutoPostBack="true" OnTextChanged="Criteria_Changed" />
                    <div class="hint">Mon&ndash;Fri 08:00&ndash;18:00, Sat 09:00&ndash;14:00. Bookings up to 90 days ahead.</div>
                </div>
            </div>
            <asp:Literal ID="litServiceInfo" runat="server" />
        </div>

        <div class="panel">
            <h3><span class="step-n sm">2</span> Pick a free time</h3>
            <asp:RadioButtonList ID="rblSlots" runat="server" RepeatLayout="Flow" RepeatDirection="Horizontal" CssClass="slots" />
            <asp:Literal ID="litNoSlots" runat="server" />
        </div>

        <div class="panel">
            <h3><span class="step-n sm">3</span> Confirm</h3>
            <p class="hint">Please arrive 10 minutes early. You can cancel online up to <%= CancelHours %> hours before your appointment.</p>
            <asp:Button ID="btnBook" runat="server" Text="Confirm booking" CssClass="btn btn-primary" OnClick="btnBook_Click"
                        OnClientClick="if(!document.querySelector('.slots input:checked')){alert('Please choose a time slot first.');return false;} this.value='Booking...';" UseSubmitBehavior="false" />
        </div>
    </div>
</asp:Content>
