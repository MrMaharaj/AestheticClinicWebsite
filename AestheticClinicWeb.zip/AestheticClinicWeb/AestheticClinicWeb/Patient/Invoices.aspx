<%@ Page Title="Invoices & Receipts" Language="C#" MasterPageFile="~/App.Master" AutoEventWireup="true" CodeBehind="Invoices.aspx.cs" Inherits="AestheticClinicWeb.PatientArea.Invoices" %>
<asp:Content ID="c1" ContentPlaceHolderID="WorkContent" runat="server">
    <h1>Invoices &amp; Receipts</h1>
    <div class="crumb">My Account &rsaquo; Invoices</div>
    <asp:Label ID="lblMsg" runat="server" Visible="false" />

    <div class="stat-row three">
        <div class="stat-box"><div class="k">Amount due now</div><div class="v"><asp:Literal ID="litDue" runat="server" Text="R 0.00" /></div></div>
        <div class="stat-box"><div class="k">Upcoming (not yet due)</div><div class="v"><asp:Literal ID="litFuture" runat="server" Text="R 0.00" /></div></div>
        <div class="stat-box"><div class="k">Total paid</div><div class="v"><asp:Literal ID="litPaid" runat="server" Text="R 0.00" /></div></div>
    </div>

    <div class="panel">
        <h3>Outstanding</h3>
        <p class="hint">Payments are made at the clinic (card, EFT or cash). Amounts are based on current treatment prices.</p>
        <asp:GridView ID="gvUnpaid" runat="server" AutoGenerateColumns="false" CssClass="data" GridLines="None" EmptyDataText="Nothing outstanding - thank you!">
            <Columns>
                <asp:TemplateField HeaderText="Date"><ItemTemplate><%# Ui.Date(Eval("Date")) %></ItemTemplate></asp:TemplateField>
                <asp:BoundField DataField="Service_Name" HeaderText="Treatment" />
                <asp:TemplateField HeaderText="Status"><ItemTemplate><%# Ui.StatusPill(Eval("Status")) %></ItemTemplate></asp:TemplateField>
                <asp:TemplateField HeaderText="Amount"><ItemTemplate><%# Ui.Money(Eval("Price")) %></ItemTemplate></asp:TemplateField>
            </Columns>
        </asp:GridView>
    </div>

    <div class="panel">
        <h3>Payment history</h3>
        <asp:GridView ID="gvPaid" runat="server" AutoGenerateColumns="false" CssClass="data" GridLines="None" EmptyDataText="No payments yet.">
            <Columns>
                <asp:BoundField DataField="Payment_ID" HeaderText="Receipt #" />
                <asp:TemplateField HeaderText="Date"><ItemTemplate><%# Ui.Date(Eval("Date")) %></ItemTemplate></asp:TemplateField>
                <asp:BoundField DataField="Service_Description" HeaderText="Treatment" />
                <asp:TemplateField HeaderText="Amount"><ItemTemplate><%# Ui.Money(Eval("Amount")) %></ItemTemplate></asp:TemplateField>
                <asp:TemplateField><ItemTemplate><a class="link" target="_blank" href="<%# ResolveUrl("~/Print/Receipt.aspx?id=" + Eval("Payment_ID")) %>">Receipt</a></ItemTemplate></asp:TemplateField>
            </Columns>
        </asp:GridView>
    </div>
</asp:Content>
