<%@ Page Title="My Progress & Results" Language="C#" MasterPageFile="~/App.Master" AutoEventWireup="true" CodeBehind="Progress.aspx.cs" Inherits="AestheticClinicWeb.PatientArea.Progress" %>
<asp:Content ID="c1" ContentPlaceHolderID="WorkContent" runat="server">
    <h1>My Progress &amp; Results</h1>
    <div class="crumb">My Account &rsaquo; Progress &amp; results</div>
    <asp:Label ID="lblMsg" runat="server" Visible="false" />

    <div class="panel">
        <h3>Weight trend</h3>
        <asp:Literal ID="litSummary" runat="server" />
        <asp:Literal ID="litChart" runat="server" />
    </div>

    <div class="panel">
        <h3>Measurements</h3>
        <div class="table-wrap">
        <asp:GridView ID="gvMetrics" runat="server" AutoGenerateColumns="false" CssClass="data" GridLines="None" EmptyDataText="No measurements have been recorded yet.">
            <Columns>
                <asp:TemplateField HeaderText="Date"><ItemTemplate><%# Ui.Date(Eval("Date_Recorded")) %></ItemTemplate></asp:TemplateField>
                <asp:BoundField DataField="Weight_kg" HeaderText="Weight (kg)" />
                <asp:BoundField DataField="Abdominal_Circumference_cm" HeaderText="Abdominal (cm)" />
                <asp:BoundField DataField="Height_cm" HeaderText="Height (cm)" />
                <asp:BoundField DataField="BMI" HeaderText="BMI" />
                <asp:BoundField DataField="Blood_Pressure" HeaderText="Blood pressure" />
                <asp:BoundField DataField="Notes" HeaderText="Notes" />
                <asp:TemplateField HeaderText="Photo"><ItemTemplate><%# Convert.ToInt32(Eval("HasImage")) == 1 ? "<a class=\"link\" target=\"_blank\" href=\"" + ResolveUrl("~/Handlers/Image.ashx?type=metric&id=" + Eval("Metric_ID")) + "\">View</a>" : "" %></ItemTemplate></asp:TemplateField>
            </Columns>
        </asp:GridView>
        </div>
    </div>

    <h3 class="h-sec">Treatment results</h3>
    <asp:Repeater ID="rptResults" runat="server">
        <ItemTemplate>
            <div class="panel result">
                <div class="result-head"><strong><%#: Eval("Service") %></strong> <span class="hint"><%# Ui.LongDate(Eval("Result_Date")) %></span></div>
                <p><strong>Result:</strong> <%#: Eval("Result") %></p>
                <p class="hint"><%#: Eval("Notes") %></p>
                <div class="ba">
                    <%# Convert.ToInt32(Eval("HasBefore")) == 1 ? "<figure><img loading=\"lazy\" alt=\"Before treatment\" src=\"" + ResolveUrl("~/Handlers/Image.ashx?type=before&id=" + Eval("Result_ID")) + "\" /><figcaption>Before</figcaption></figure>" : "" %>
                    <%# Convert.ToInt32(Eval("HasAfter")) == 1 ? "<figure><img loading=\"lazy\" alt=\"After treatment\" src=\"" + ResolveUrl("~/Handlers/Image.ashx?type=after&id=" + Eval("Result_ID")) + "\" /><figcaption>After</figcaption></figure>" : "" %>
                </div>
            </div>
        </ItemTemplate>
    </asp:Repeater>
    <asp:PlaceHolder ID="phNoResults" runat="server" Visible="false"><div class="empty">No treatment results have been recorded yet.</div></asp:PlaceHolder>
</asp:Content>
