<%@ Page Title="My Dashboard" Language="C#" MasterPageFile="~/App.Master" AutoEventWireup="true" CodeBehind="Dashboard.aspx.cs" Inherits="AestheticClinicWeb.PatientArea.Dashboard" %>
<asp:Content ID="c1" ContentPlaceHolderID="WorkContent" runat="server">
    <h1>Welcome back, <%: FirstName %></h1>
    <div class="crumb">My Account &rsaquo; Dashboard</div>
    <asp:Label ID="lblMsg" runat="server" Visible="false" />

    <div class="stat-row">
        <div class="stat-box"><div class="k">Next appointment</div><div class="v sm"><asp:Literal ID="litNext" runat="server" Text="None booked" /></div></div>
        <div class="stat-box"><div class="k">Upcoming bookings</div><div class="v"><asp:Literal ID="litUpcoming" runat="server" Text="0" /></div></div>
        <div class="stat-box"><div class="k">Outstanding balance</div><div class="v"><asp:Literal ID="litOwing" runat="server" Text="R 0.00" /></div></div>
        <div class="stat-box"><div class="k">Visits completed</div><div class="v"><asp:Literal ID="litVisits" runat="server" Text="0" /></div></div>
    </div>

    <div class="panel">
        <h3>Quick actions</h3>
        <div class="toolbar">
            <a class="btn-sm" href="<%= ResolveUrl("~/Patient/Book.aspx") %>">+ Book an appointment</a>
            <a class="btn-sm alt" href="<%= ResolveUrl("~/Patient/Appointments.aspx") %>">My appointments</a>
            <a class="btn-sm alt" href="<%= ResolveUrl("~/Patient/Progress.aspx") %>">My results</a>
            <a class="btn-sm alt" href="<%= ResolveUrl("~/Patient/Invoices.aspx") %>">Invoices</a>
        </div>
    </div>

    <div class="panel">
        <h3>Upcoming appointments</h3>
        <asp:GridView ID="gvUpcoming" runat="server" AutoGenerateColumns="false" CssClass="data" GridLines="None" EmptyDataText="You have no upcoming appointments.">
            <Columns>
                <asp:TemplateField HeaderText="Date"><ItemTemplate><%# Ui.LongDate(Eval("Date")) %></ItemTemplate></asp:TemplateField>
                <asp:TemplateField HeaderText="Time"><ItemTemplate><%# Ui.Time(Eval("Start_Time")) %> &ndash; <%# Ui.Time(Eval("End_Time")) %></ItemTemplate></asp:TemplateField>
                <asp:BoundField DataField="Service_Name" HeaderText="Treatment" />
                <asp:TemplateField HeaderText="Status"><ItemTemplate><%# Ui.StatusPill(Eval("Status")) %></ItemTemplate></asp:TemplateField>
            </Columns>
        </asp:GridView>
    </div>
</asp:Content>
