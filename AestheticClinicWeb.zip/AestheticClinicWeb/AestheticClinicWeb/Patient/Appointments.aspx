<%@ Page Title="My Appointments" Language="C#" MasterPageFile="~/App.Master" AutoEventWireup="true" CodeBehind="Appointments.aspx.cs" Inherits="AestheticClinicWeb.PatientArea.Appointments" %>
<asp:Content ID="c1" ContentPlaceHolderID="WorkContent" runat="server">
    <h1>My Appointments</h1>
    <div class="crumb">My Account &rsaquo; Appointments</div>
    <asp:Label ID="lblMsg" runat="server" Visible="false" />

    <div class="toolbar">
        <a class="btn-sm" href="<%= ResolveUrl("~/Patient/Book.aspx") %>">+ Book new appointment</a>
        <asp:DropDownList ID="ddlShow" runat="server" AutoPostBack="true" OnSelectedIndexChanged="ddlShow_Changed" CssClass="inline-select" aria-label="Filter appointments">
            <asp:ListItem Value="upcoming">Upcoming</asp:ListItem>
            <asp:ListItem Value="past">Past</asp:ListItem>
            <asp:ListItem Value="all">All</asp:ListItem>
        </asp:DropDownList>
    </div>

    <div class="table-wrap">
    <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="data" GridLines="None" DataKeyNames="Appointment_ID"
                  OnRowCommand="gv_RowCommand" EmptyDataText="No appointments to show.">
        <Columns>
            <asp:TemplateField HeaderText="Date"><ItemTemplate><%# Ui.Date(Eval("Date")) %></ItemTemplate></asp:TemplateField>
            <asp:TemplateField HeaderText="Time"><ItemTemplate><%# Ui.Time(Eval("Start_Time")) %>&ndash;<%# Ui.Time(Eval("End_Time")) %></ItemTemplate></asp:TemplateField>
            <asp:BoundField DataField="Service_Name" HeaderText="Treatment" />
            <asp:TemplateField HeaderText="Price"><ItemTemplate><%# Ui.Money(Eval("Price")) %></ItemTemplate></asp:TemplateField>
            <asp:TemplateField HeaderText="Status"><ItemTemplate><%# Ui.StatusPill(Eval("Status")) %></ItemTemplate></asp:TemplateField>
            <asp:TemplateField HeaderText="Payment"><ItemTemplate><%# Ui.PaidPill(Eval("Is_Paid")) %></ItemTemplate></asp:TemplateField>
            <asp:TemplateField HeaderText="">
                <ItemTemplate>
                    <a class="link" href="<%# ResolveUrl("~/Print/Appointment.aspx?id=" + Eval("Appointment_ID")) %>" target="_blank">Print</a>
                    <asp:LinkButton ID="lnkCancel" runat="server" CommandName="CancelAppt" CommandArgument='<%# Eval("Appointment_ID") %>'
                        CssClass="link danger" Visible='<%# CanCancel(Eval("Status"), Eval("Date"), Eval("Start_Time")) %>'
                        OnClientClick="return confirm('Cancel this appointment? This cannot be undone.');">Cancel</asp:LinkButton>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
    </asp:GridView>
    </div>
</asp:Content>
