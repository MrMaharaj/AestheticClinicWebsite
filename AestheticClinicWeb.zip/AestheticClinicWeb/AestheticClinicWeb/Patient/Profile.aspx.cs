using System;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;
using AestheticClinicWeb.Security;

namespace AestheticClinicWeb.PatientArea
{
    public partial class Profile : PatientPage
    {
        protected void Page_Load(object sender, EventArgs e) { if (!IsPostBack) LoadProfile(); }

        void LoadProfile()
        {
            Safe(lblMsg, () =>
            {
                var p = PatientRepository.Get(PatientId);
                if (p == null) { Fail(lblMsg, "Your patient record could not be found."); pnlEdit.Visible = false; return; }
                litPid.Text = p.PatientId.ToString();
                litName.Text = Server.HtmlEncode(p.FirstName + " " + p.LastName);
                litId.Text = Server.HtmlEncode(p.IdNumber.Length == 13 ? p.IdNumber.Substring(0, 6) + "*******" : p.IdNumber);
                litDob.Text = p.Dob.ToString("yyyy-MM-dd");
                litGender.Text = Ui.Gender(p.Gender.ToString());
                txtAddress.Text = p.Address; txtPhone.Text = p.Phone; ViewState["origPhone"] = p.Phone; txtEmail.Text = p.Email; txtAllergies.Text = p.Allergies;
            });
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            Page.Validate("prof"); if (!Page.IsValid) return;
            bool phoneUnchanged = txtPhone.Text.Trim() == (ViewState["origPhone"] as string ?? "");
            if (!phoneUnchanged && !Check.Phone(txtPhone.Text)) { Fail(lblMsg, "Cell number must be 10 digits starting with 0."); return; }
            if (!Check.Email(txtEmail.Text)) { Fail(lblMsg, "Please enter a valid email address (max 50 characters)."); return; }
            string email = txtEmail.Text.Trim();

            bool inUse = false;
            if (!Safe(lblMsg, () => inUse = AccountRepository.EmailInUse(email, null, UserId))) return;
            if (inUse) { Fail(lblMsg, "That email address is already used by another account."); return; }

            if (Safe(lblMsg, () => PatientRepository.UpdateOwnDetails(PatientId, UserId, Check.Trunc(txtAddress.Text, 100),
                                    txtPhone.Text.Trim(), email, txtAllergies.Text)))
            {
                var id = Auth.Current;
                if (!string.Equals(id.Email, email, StringComparison.OrdinalIgnoreCase)) { id.Email = email; Auth.SignIn(id); }
                Ok(lblMsg, "Your details have been saved. Clinic staff will see the update immediately.");
            }
        }
    }
}
