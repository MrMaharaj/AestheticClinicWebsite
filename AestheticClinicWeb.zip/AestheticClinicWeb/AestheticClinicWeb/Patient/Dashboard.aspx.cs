using System;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;
using AestheticClinicWeb.Security;

namespace AestheticClinicWeb.PatientArea
{
    public partial class Dashboard : PatientPage
    {
        protected string FirstName { get { return (Auth.Current.FullName ?? "").Split(' ')[0]; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            if (Request.QueryString["welcome"] == "1") Ok(lblMsg, "Your password and security question have been saved. Welcome to your AestheticFlow account!");
            Safe(lblMsg, () =>
            {
                var up = AppointmentRepository.Upcoming(PatientId);
                gvUpcoming.DataSource = up; gvUpcoming.DataBind();
                litUpcoming.Text = up.Rows.Count.ToString();
                if (up.Rows.Count > 0)
                    litNext.Text = Server.HtmlEncode(Ui.Date(up.Rows[0]["Date"]) + " " + Ui.Time(up.Rows[0]["Start_Time"])) +
                                   "<br><small>" + Server.HtmlEncode(Convert.ToString(up.Rows[0]["Service_Name"])) + "</small>";

                decimal owing = 0;
                foreach (System.Data.DataRow r in PaymentRepository.Unpaid(PatientId).Rows)
                    if (Convert.ToDateTime(r["Date"]) <= DateTime.Today) owing += Convert.ToDecimal(r["Price"]);
                litOwing.Text = Ui.Money(owing);

                litVisits.Text = Convert.ToString(Db.Scalar("SELECT COUNT(*) FROM Appointment WHERE Patient_ID=@p AND Status=@s",
                    Db.P("@p", PatientId), Db.P("@s", ClinicSettings.StatusCompleted)));
            });
        }
    }
}
