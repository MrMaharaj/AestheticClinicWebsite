using System;
using System.Data;
using System.Globalization;
using System.Web.UI.WebControls;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;

namespace AestheticClinicWeb.PatientArea
{
    public partial class Book : PatientPage
    {
        protected int CancelHours { get { return ClinicSettings.MinHoursNoticeToCancel; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            txtDate.Attributes["min"] = DateTime.Today.ToString("yyyy-MM-dd");
            txtDate.Attributes["max"] = DateTime.Today.AddDays(90).ToString("yyyy-MM-dd");
            if (IsPostBack) return;

            Safe(lblMsg, () =>
            {
                ddlService.Items.Add(new ListItem("-- Select a treatment --", ""));
                foreach (DataRow r in ServiceRepository.All().Rows)
                    ddlService.Items.Add(new ListItem(r["Service_Name"] + " (" + Ui.Money(r["Price"]) + ", " + r["Duration"] + " min)", r["Service_ID"].ToString()));
                string pre = Request.QueryString["service"];
                if (!string.IsNullOrEmpty(pre) && ddlService.Items.FindByValue(pre) != null) ddlService.SelectedValue = pre;
            });
            var start = DateTime.Today.AddDays(1);
            if (start.DayOfWeek == DayOfWeek.Sunday) start = start.AddDays(1);
            txtDate.Text = start.ToString("yyyy-MM-dd");
            LoadSlots();
        }

        protected void Criteria_Changed(object sender, EventArgs e) { LoadSlots(); }

        void LoadSlots()
        {
            rblSlots.Items.Clear(); litNoSlots.Text = ""; litServiceInfo.Text = "";
            int serviceId; DateTime? date = ParseDate(txtDate.Text);
            if (!int.TryParse(ddlService.SelectedValue, out serviceId)) { litNoSlots.Text = "<div class=\"empty\">Choose a treatment to see available times.</div>"; return; }
            if (date == null) { litNoSlots.Text = "<div class=\"empty\">Choose a valid date.</div>"; return; }
            if (date.Value < DateTime.Today || date.Value > DateTime.Today.AddDays(90)) { litNoSlots.Text = "<div class=\"empty\">Please choose a date between today and 90 days ahead.</div>"; return; }

            Safe(lblMsg, () =>
            {
                var s = ServiceRepository.Get(serviceId);
                if (s == null) return;
                litServiceInfo.Text = "<div class=\"svc-info\"><strong>" + Server.HtmlEncode(Db.S(s, "Service_Name")) + "</strong> &middot; " +
                    Server.HtmlEncode(Db.S(s, "Description")) + " &middot; <strong>" + Ui.Money(s["Price"]) + "</strong></div>";

                TimeSpan o, c;
                if (!ClinicSettings.TryGetHours(date.Value, out o, out c)) { litNoSlots.Text = "<div class=\"empty\">The clinic is closed on Sundays. Please pick another day.</div>"; return; }

                var slots = AppointmentRepository.AvailableSlots(date.Value, Db.I(s, "Duration"));
                foreach (var t in slots) rblSlots.Items.Add(new ListItem(t.ToString(@"hh\:mm"), t.ToString(@"hh\:mm")));
                if (slots.Count == 0) litNoSlots.Text = "<div class=\"empty\">No free times on " + date.Value.ToString("dddd d MMMM", CultureInfo.InvariantCulture) + ". Please try another date.</div>";
            });
        }

        protected void btnBook_Click(object sender, EventArgs e)
        {
            int serviceId; TimeSpan start; DateTime? date = ParseDate(txtDate.Text);
            if (!int.TryParse(ddlService.SelectedValue, out serviceId)) { Fail(lblMsg, "Please choose a treatment."); return; }
            if (date == null) { Fail(lblMsg, "Please choose a valid date."); return; }
            if (!TimeSpan.TryParse(rblSlots.SelectedValue, out start)) { Fail(lblMsg, "Please choose a time slot."); return; }
            if (date.Value > DateTime.Today.AddDays(90)) { Fail(lblMsg, "Bookings can be made up to 90 days ahead."); return; }

            int newId = 0;
            if (Safe(lblMsg, () => newId = AppointmentRepository.Book(PatientId, serviceId, date.Value, start)))
            {
                Response.Redirect("~/Print/Appointment.aspx?id=" + newId + "&new=1", false);
                Context.ApplicationInstance.CompleteRequest();
                return;
            }
            LoadSlots();   // slot may have just been taken - refresh the list
        }
    }
}
