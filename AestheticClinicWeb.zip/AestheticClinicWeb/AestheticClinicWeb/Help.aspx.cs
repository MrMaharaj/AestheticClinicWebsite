using System;
using AestheticClinicWeb.Helpers;

namespace AestheticClinicWeb
{
    public partial class Help : System.Web.UI.Page
    {
        protected int CancelHours { get { return ClinicSettings.MinHoursNoticeToCancel; } }
        protected void Page_Load(object sender, EventArgs e) { }
    }
}
