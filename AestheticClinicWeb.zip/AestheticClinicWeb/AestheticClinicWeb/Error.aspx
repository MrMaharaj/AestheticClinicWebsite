<%@ Page Title="Something went wrong" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="Error.aspx.cs" Inherits="AestheticClinicWeb.ErrorPage" %>
<asp:Content ID="c1" ContentPlaceHolderID="MainContent" runat="server">
    <section>
        <div class="container narrow" style="text-align:center;">
            <div class="icon-badge" style="margin:0 auto 12px;">&#9888;</div>
            <h1 style="color:var(--plum);"><%: Heading %></h1>
            <p><%: Detail %></p>
            <p>
                <a class="btn btn-primary" href="<%= ResolveUrl("~/Default.aspx") %>">Go to the home page</a>
                <a class="btn btn-outline" href="javascript:history.back()">Go back</a>
            </p>
            <p class="hint">If this keeps happening, please contact the clinic on +27 31 260 8124.</p>
        </div>
    </section>
</asp:Content>
