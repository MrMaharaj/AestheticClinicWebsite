<%@ WebHandler Language="C#" CodeBehind="HelpBot.ashx.cs" Class="AestheticClinicWeb.Handlers.HelpBot" %>
