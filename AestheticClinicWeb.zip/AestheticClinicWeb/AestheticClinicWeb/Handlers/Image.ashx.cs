using System;
using System.Web;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Security;

namespace AestheticClinicWeb.Handlers
{
    /// <summary>
    /// Streams before/after and progress images from the database.
    /// Authorisation: staff may view any image; a patient may only view their OWN images.
    /// </summary>
    public class ImageHandler : IHttpHandler
    {
        public void ProcessRequest(HttpContext context)
        {
            var who = Auth.Current;
            int id;
            string kind = (context.Request.QueryString["type"] ?? "").ToLowerInvariant();
            if (who == null || !int.TryParse(context.Request.QueryString["id"], out id)) { Deny(context, 403); return; }

            int owner;
            byte[] data;
            try { data = ClinicalRepository.GetImage(kind, id, out owner); }
            catch { Deny(context, 503); return; }
            if (data == null) { Deny(context, 404); return; }
            if (who.Kind == AccountKind.Patient && who.PatientId != owner) { Deny(context, 403); return; }

            context.Response.ContentType = Sniff(data);
            context.Response.Cache.SetCacheability(HttpCacheability.Private);
            context.Response.Cache.SetMaxAge(TimeSpan.FromHours(1));
            context.Response.BinaryWrite(data);
        }

        static void Deny(HttpContext c, int code) { c.Response.StatusCode = code; c.Response.SuppressContent = true; }

        static string Sniff(byte[] b)
        {
            if (b.Length > 3 && b[0] == 0x89 && b[1] == 0x50) return "image/png";
            if (b.Length > 3 && b[0] == 0x47 && b[1] == 0x49) return "image/gif";
            if (b.Length > 11 && b[8] == 0x57 && b[9] == 0x45) return "image/webp";
            return "image/jpeg";
        }

        public bool IsReusable { get { return true; } }
    }
}
