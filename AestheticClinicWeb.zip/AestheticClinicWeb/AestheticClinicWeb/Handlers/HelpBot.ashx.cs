using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.SessionState;
using AestheticClinicWeb.Data;
using AestheticClinicWeb.Helpers;
using AestheticClinicWeb.Security;

namespace AestheticClinicWeb.Handlers
{
    /// <summary>
    /// Help assistant (chatbot). Rule-based intent matching with keyword scoring, answering from
    /// live database data (treatment prices/durations) and the visitor's role (public / patient / staff).
    /// Returns JSON: { reply: "...", links: [ {text, url} ] }.
    /// </summary>
    public class HelpBot : IHttpHandler, IReadOnlySessionState
    {
        class Intent { public string Name; public string[] Words; public Func<HttpContext, string, Answer> Respond; }
        class Answer { public string reply; public List<Link> links = new List<Link>(); }
        class Link { public string text, url; }

        static Answer A(string reply, params string[] linkPairs)
        {
            var a = new Answer { reply = reply };
            for (int i = 0; i + 1 < linkPairs.Length; i += 2) a.links.Add(new Link { text = linkPairs[i], url = VirtualPathUtility.ToAbsolute(linkPairs[i + 1]) });
            return a;
        }

        static readonly List<Intent> Intents = new List<Intent>
        {
            new Intent { Name = "greet", Words = new[] { "hi", "hello", "hey", "morning", "afternoon", "sawubona", "howzit" },
                Respond = (c, q) => A("Hello! I can help with bookings, prices, opening hours, your account, results and invoices. What would you like to do?") },
            new Intent { Name = "book", Words = new[] { "book", "booking", "appointment", "schedule", "slot", "reserve", "consultation" },
                Respond = (c, q) => Auth.IsPatient
                    ? A("Go to Book Appointment, choose a treatment and a date - only free time slots are shown, so double bookings are impossible. You'll get a printable confirmation.", "Book now", "~/Patient/Book.aspx")
                    : Auth.IsStaff
                        ? A("Open Appointments, search for the patient, pick the treatment, date and a free slot, then click Book.", "Appointments", "~/Portal/Appointments.aspx")
                        : A("To book online, register as a patient (takes 2 minutes) and log in. You can also phone us on +27 31 260 8124.", "Register", "~/Account/Register.aspx", "Log in", "~/Account/Login.aspx") },
            new Intent { Name = "cancel", Words = new[] { "cancel", "cancellation", "reschedule", "change", "move", "postpone" },
                Respond = (c, q) => A("You can cancel a booked appointment online under My Appointments up to " + ClinicSettings.MinHoursNoticeToCancel +
                    " hours before it starts. To reschedule, cancel and book a new slot, or phone the clinic.", "My appointments", "~/Patient/Appointments.aspx") },
            new Intent { Name = "hours", Words = new[] { "hours", "open", "opening", "close", "closing", "time", "times", "saturday", "sunday", "weekend" },
                Respond = (c, q) => A("We are open Monday to Friday 08:00-18:00 and Saturday 09:00-14:00. Closed on Sundays and public holidays.") },
            new Intent { Name = "location", Words = new[] { "where", "address", "location", "directions", "find", "parking", "located" },
                Respond = (c, q) => A("We're at Newlands City Shopping Centre, Durban. Phone +27 31 260 8124.", "Contact page", "~/Contact.aspx") },
            new Intent { Name = "price", Words = new[] { "price", "prices", "cost", "costs", "how much", "fee", "fees", "pricing", "expensive", "cheap", "rand" },
                Respond = PriceAnswer },
            new Intent { Name = "treatments", Words = new[] { "treatment", "treatments", "service", "services", "offer", "menu", "do you do" },
                Respond = PriceAnswer },
            new Intent { Name = "register", Words = new[] { "register", "registration", "sign up", "signup", "create account", "new account", "join" },
                Respond = (c, q) => A("Click Register, enter your details exactly as on your ID, and choose a password and security question. If the clinic already has your record, your account is linked to it automatically. New accounts are activated by our team.", "Register", "~/Account/Register.aspx") },
            new Intent { Name = "password", Words = new[] { "password", "forgot", "reset", "locked", "login", "log in", "cant login", "can't log" },
                Respond = (c, q) => A("Use Forgot Password: enter your email, answer your security question and set a new password. After 5 failed attempts the login locks for 5 minutes.", "Forgot password", "~/Account/ForgotPassword.aspx") },
            new Intent { Name = "results", Words = new[] { "result", "results", "progress", "before", "after", "photo", "photos", "weight", "metrics", "bmi" },
                Respond = (c, q) => A("Your before/after photos, treatment results and measurements (weight, abdominal circumference, BMI) are under My Progress & Results once your practitioner has captured them.", "My progress", "~/Patient/Progress.aspx") },
            new Intent { Name = "invoice", Words = new[] { "invoice", "invoices", "receipt", "receipts", "paid", "pay", "payment", "balance", "owe", "statement" },
                Respond = (c, q) => Auth.IsStaff
                    ? A("Open Payments & Invoices: unpaid appointments are listed at the top - click Record Payment, then print the receipt.", "Payments", "~/Portal/Invoices.aspx")
                    : A("Payments are made at the clinic. Your invoices, outstanding balances and printable receipts are under Invoices & Receipts.", "Invoices", "~/Patient/Invoices.aspx") },
            new Intent { Name = "profile", Words = new[] { "profile", "details", "update", "edit", "phone number", "email address", "allergy", "allergies" },
                Respond = (c, q) => A("Update your address, phone, email and allergies under My Profile. For name or ID corrections please contact reception.", "My profile", "~/Patient/Profile.aspx") },
            new Intent { Name = "reports", Words = new[] { "report", "reports", "revenue", "income", "analytics", "statistics", "bi" },
                Respond = (c, q) => Auth.IsStaff
                    ? A("BI Reports has 9 reports (revenue, treatment mix, cancellations, peak times, top patients, retention, debtors, patient progress). Each can be viewed as a table or chart, exported to Excel or printed/saved as PDF.", "Open reports", "~/Portal/Reports.aspx")
                    : A("Reports are available to clinic staff only.") },
            new Intent { Name = "safety", Words = new[] { "safe", "safety", "side effect", "side effects", "pain", "hurt", "risk", "pregnant", "downtime" },
                Respond = (c, q) => A("All treatments are performed or supervised by registered doctors, and risks are discussed at your consultation. For medical questions please speak to your practitioner - I can't give medical advice.", "Contact us", "~/Contact.aspx") },
            new Intent { Name = "thanks", Words = new[] { "thanks", "thank you", "thank", "great", "awesome", "ngiyabonga" },
                Respond = (c, q) => A("You're welcome! Anything else I can help with?") },
        };

        static Answer PriceAnswer(HttpContext c, string q)
        {
            try
            {
                var services = ServiceRepository.All();
                // Specific treatment mentioned? e.g. "how much is a chemical peel"
                var match = services.AsEnumerable()
                    .Select(r => new { Row = r, Score = Overlap(q, Convert.ToString(r["Service_Name"])) })
                    .Where(x => x.Score > 0).OrderByDescending(x => x.Score).FirstOrDefault();
                if (match != null)
                {
                    var r = match.Row;
                    return A(string.Format("{0} ({1}) costs {2} and takes about {3} minutes. {4}",
                        r["Service_Name"], r["Category"], Ui.Money(r["Price"]), r["Duration"], r["Description"]), "All treatments", "~/Services.aspx");
                }
                var top = services.AsEnumerable().Take(6)
                    .Select(r => r["Service_Name"] + " " + Ui.Money(r["Price"]));
                return A("Some of our treatments: " + string.Join("; ", top) + ". Ask me about a specific treatment, or see the full list.", "Treatments & prices", "~/Services.aspx");
            }
            catch
            {
                return A("I couldn't load live prices right now - please see the Treatments page.", "Treatments", "~/Services.aspx");
            }
        }

        static readonly HashSet<string> Stop = new HashSet<string> { "the", "a", "an", "and", "of", "for", "is", "how", "much", "my", "to", "in", "on", "what", "do", "you" };

        static int Overlap(string question, string name)
        {
            var qw = new HashSet<string>(Words(question));
            return Words(name).Count(w => w.Length > 2 && !Stop.Contains(w) && (qw.Contains(w) || qw.Contains(w.TrimEnd('s')) || qw.Contains(w + "s")));
        }

        static IEnumerable<string> Words(string s)
        {
            return Regex.Split((s ?? "").ToLowerInvariant(), @"[^a-z0-9']+").Where(w => w.Length > 0);
        }

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "application/json";
            context.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            string q = (context.Request["q"] ?? "").Trim();
            if (q.Length > 200) q = q.Substring(0, 200);

            Answer answer;
            if (q.Length == 0) answer = A("Please type a question.");
            else
            {
                string lower = " " + q.ToLowerInvariant() + " ";
                var words = new HashSet<string>(Words(q));
                var best = Intents
                    .Select(i => new { i, Score = i.Words.Sum(w => w.Contains(" ") ? (lower.Contains(" " + w + " ") || lower.Contains(w) ? 3 : 0) : (words.Contains(w) ? 2 : 0)) })
                    .OrderByDescending(x => x.Score).First();

                // A treatment name alone ("botox?") should still return its price.
                if (best.Score == 0)
                {
                    var priced = PriceAnswer(context, q);
                    answer = priced.reply.Contains(" costs ")
                        ? priced
                        : A("Sorry, I didn't quite understand. Try asking about booking, prices, opening hours, cancelling, results, invoices or your password - or see the Help page.", "Help & FAQ", "~/Help.aspx", "Contact us", "~/Contact.aspx");
                }
                else answer = best.i.Respond(context, q);
            }
            context.Response.Write(new JavaScriptSerializer().Serialize(answer));
        }

        public bool IsReusable { get { return true; } }
    }
}
