<%@ WebHandler Language="C#" CodeBehind="Image.ashx.cs" Class="AestheticClinicWeb.Handlers.ImageHandler" %>
