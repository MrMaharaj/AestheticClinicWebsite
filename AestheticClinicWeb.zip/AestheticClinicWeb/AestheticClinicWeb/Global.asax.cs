using System;
using System.Web;
using AestheticClinicWeb.Helpers;
using AestheticClinicWeb.Security;

namespace AestheticClinicWeb
{
    public class Global : HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
        }

        /// <summary>Attach Staff / Admin / Patient roles from the auth ticket (used by Web.config rules).</summary>
        protected void Application_PostAuthenticateRequest(object sender, EventArgs e)
        {
            Auth.AttachPrincipal(Context);
        }

        /// <summary>Last-resort handler: log it; customErrors shows the friendly Error.aspx page.</summary>
        protected void Application_Error(object sender, EventArgs e)
        {
            var ex = Server.GetLastError();
            if (ex is HttpException && ((HttpException)ex).GetHttpCode() == 404) return;
            if (ex != null) ErrorLog.Write(ex.GetBaseException());
        }
    }
}
