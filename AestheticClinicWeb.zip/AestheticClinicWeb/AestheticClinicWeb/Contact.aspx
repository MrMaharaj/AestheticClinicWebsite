<%@ Page Title="Contact" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="Contact.aspx.cs" Inherits="AestheticClinicWeb.Contact" %>

<asp:Content ID="c1" ContentPlaceHolderID="MainContent" runat="server">

    <section class="hero" style="padding:60px 0;">
        <div class="container">
            <h1>Book a Consultation</h1>
            <p>Tell us a little about what you&rsquo;re looking for and our team will be in touch
               to arrange your appointment.</p>
        </div>
    </section>

    <section>
        <div class="container">
            <div class="grid grid-2">

                <div class="card">
                    <h3>Send us a message</h3>

                    <asp:Label ID="lblResult" runat="server" Visible="false" CssClass="msg msg-ok" />
                    <asp:ValidationSummary ID="vs" runat="server" CssClass="msg msg-err" ValidationGroup="contact" HeaderText="Please correct the following:" />

                    <div class="field">
                        <label for="<%= txtName.ClientID %>">Full name *</label>
                        <asp:TextBox ID="txtName" runat="server" MaxLength="100" />
                        <asp:RequiredFieldValidator ID="rfvName" runat="server" ControlToValidate="txtName" ErrorMessage="Name is required." Display="Dynamic" CssClass="val" Text="Required" ValidationGroup="contact" />
                    </div>
                    <div class="field">
                        <label for="<%= txtEmail.ClientID %>">Email address *</label>
                        <asp:TextBox ID="txtEmail" runat="server" TextMode="Email" MaxLength="50" />
                        <asp:RequiredFieldValidator ID="rfvEmail" runat="server" ControlToValidate="txtEmail" ErrorMessage="Email is required." Display="Dynamic" CssClass="val" Text="Required" ValidationGroup="contact" />
                        <asp:RegularExpressionValidator ID="revEmail" runat="server" ControlToValidate="txtEmail" ValidationExpression="^[^@\s]+@[^@\s]+\.[^@\s]{2,}$" ErrorMessage="Enter a valid email address." Display="Dynamic" CssClass="val" Text="Invalid email" ValidationGroup="contact" />
                    </div>
                    <div class="field">
                        <label for="<%= txtPhone.ClientID %>">Contact number</label>
                        <asp:TextBox ID="txtPhone" runat="server" MaxLength="10" placeholder="0821234567" />
                        <asp:RegularExpressionValidator ID="revPhone" runat="server" ControlToValidate="txtPhone" ValidationExpression="^0\d{9}$" ErrorMessage="Contact number must be 10 digits starting with 0." Display="Dynamic" CssClass="val" Text="10 digits, starting with 0" ValidationGroup="contact" />
                    </div>
                    <div class="field">
                        <label for="<%= ddlTreatment.ClientID %>">Treatment of interest</label>
                        <asp:DropDownList ID="ddlTreatment" runat="server" />
                    </div>
                    <div class="field">
                        <label for="<%= txtMessage.ClientID %>">Message *</label>
                        <asp:TextBox ID="txtMessage" runat="server" TextMode="MultiLine" Rows="4" MaxLength="500" />
                        <asp:RequiredFieldValidator ID="rfvMsg" runat="server" ControlToValidate="txtMessage" ErrorMessage="Please enter a message." Display="Dynamic" CssClass="val" Text="Required" ValidationGroup="contact" />
                    </div>
                    <asp:Button ID="btnSend" runat="server" CssClass="btn btn-primary btn-block"
                                Text="Send Request" OnClick="btnSend_Click" ValidationGroup="contact" />
                    <p class="hint">Want to book directly? <a href="<%= ResolveUrl("~/Account/Register.aspx") %>">Register</a> and choose a free slot online.</p>
                </div>

                <div>
                    <div class="card" style="margin-bottom:24px;">
                        <h3>Visit us</h3>
                        <p>Newlands City Shopping Centre<br />Durban, South Africa</p>
                    </div>
                    <div class="card" style="margin-bottom:24px;">
                        <h3>Opening hours</h3>
                        <p>Monday &ndash; Friday: 08:00 &ndash; 18:00<br />
                           Saturday: 09:00 &ndash; 14:00<br />
                           Sunday &amp; Public Holidays: Closed</p>
                    </div>
                    <div class="card">
                        <h3>Get in touch</h3>
                        <p>&#9742; +27 31 260 8124<br />
                           &#9993; hello@aestheticflow.co.za</p>
                    </div>
                </div>

            </div>
        </div>
    </section>

</asp:Content>
