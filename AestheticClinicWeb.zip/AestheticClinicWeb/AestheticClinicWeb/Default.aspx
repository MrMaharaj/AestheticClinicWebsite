<%@ Page Title="Home" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="AestheticClinicWeb.Default" %>

<asp:Content ID="c1" ContentPlaceHolderID="MainContent" runat="server">

    <section class="hero">
        <div class="container">
            <h1>Confidence, refined.</h1>
            <p>Doctor-led wellness and aesthetic care tailored to you &mdash; medical weight-loss programmes,
               PRP therapy, IV vitamin therapy and blood testing. Measurable results, delivered with care.</p>
            <div class="cta">
                <a class="btn btn-primary" href="<%= ResolveUrl("~/Account/Register.aspx") %>">Book Online</a>
                <a class="btn btn-ghost" href="<%= ResolveUrl("~/Services.aspx") %>">View Treatments</a>
            </div>
        </div>
    </section>

    <section>
        <div class="container">
            <div class="section-head">
                <div class="eyebrow">Why AestheticFlow</div>
                <h2>Care you can trust</h2>
                <p>Every treatment begins with a thorough consultation and a plan built around your goals.</p>
            </div>
            <div class="grid grid-3">
                <div class="card">
                    <div class="icon-badge">&#9877;</div>
                    <h3>Qualified Doctors</h3>
                    <p>All treatments are performed or supervised by registered medical practitioners.</p>
                </div>
                <div class="card">
                    <div class="icon-badge">&#10022;</div>
                    <h3>Personalised Plans</h3>
                    <p>No two faces are the same. We design treatment plans around your skin and goals.</p>
                </div>
                <div class="card">
                    <div class="icon-badge">&#9825;</div>
                    <h3>Comfort First</h3>
                    <p>A calm, private clinic environment with aftercare that continues beyond your visit.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="tint">
        <div class="container">
            <div class="stats">
                <div><div class="num">12k+</div><div class="lbl">Treatments</div></div>
                <div><div class="num">15</div><div class="lbl">Years Experience</div></div>
                <div><div class="num">98%</div><div class="lbl">Client Satisfaction</div></div>
                <div><div class="num">6</div><div class="lbl">Specialists</div></div>
            </div>
        </div>
    </section>

    <section>
        <div class="container">
            <div class="section-head">
                <div class="eyebrow">Popular</div>
                <h2>Signature treatments</h2>
                <p>Our most-requested services, with live prices. See the full menu on the Treatments page.</p>
            </div>
            <asp:Repeater ID="rptPopular" runat="server">
                <HeaderTemplate><div class="grid grid-3"></HeaderTemplate>
                <ItemTemplate>
                    <div class="card">
                        <div class="eyebrow-sm"><%#: Eval("Category") %></div>
                        <h3><%#: Eval("Service_Name") %></h3>
                        <p><%#: Eval("Description") %></p>
                        <div class="price"><%#: Ui.Money(Eval("Price")) %> <small>&middot; <%#: Eval("Duration") %> min</small></div>
                    </div>
                </ItemTemplate>
                <FooterTemplate></div></FooterTemplate>
            </asp:Repeater>
            <asp:PlaceHolder ID="phFallback" runat="server" Visible="false">
                <div class="grid grid-3">
                    <div class="card"><h3>Weight Loss Injections</h3><p>Doctor-supervised medical weight-loss programme with progress tracking.</p></div>
                    <div class="card"><h3>PRP Therapy</h3><p>Platelet-rich plasma treatment for skin and hair rejuvenation.</p></div>
                    <div class="card"><h3>IV Therapy</h3><p>Tailored vitamin infusions for energy, hydration and recovery.</p></div>
                </div>
            </asp:PlaceHolder>
        </div>
    </section>

    <section class="tint">
        <div class="container">
            <div class="section-head">
                <div class="eyebrow">Online</div>
                <h2>Your clinic, online</h2>
                <p>Registered patients can manage everything from their own secure account.</p>
            </div>
            <div class="grid grid-4">
                <div class="card step"><div class="step-n">1</div><h3>Register</h3><p>Create your secure patient account in two minutes.</p></div>
                <div class="card step"><div class="step-n">2</div><h3>Book</h3><p>Choose a treatment and a free time slot &mdash; instant confirmation.</p></div>
                <div class="card step"><div class="step-n">3</div><h3>Track</h3><p>See your before/after photos, measurements and progress.</p></div>
                <div class="card step"><div class="step-n">4</div><h3>Pay &amp; print</h3><p>View invoices and print receipts any time.</p></div>
            </div>
            <div style="text-align:center;margin-top:30px;">
                <a class="btn btn-primary" href="<%= ResolveUrl("~/Account/Register.aspx") %>">Register now</a>
                <a class="btn btn-outline" href="<%= ResolveUrl("~/Account/Login.aspx") %>">I already have an account</a>
            </div>
        </div>
    </section>

    <section>
        <div class="container">
            <div class="section-head">
                <div class="eyebrow">Kind Words</div>
                <h2>What our clients say</h2>
            </div>
            <div class="grid grid-3">
                <div class="card">
                    <p>&ldquo;The team made me feel at ease from the first consultation. Beautiful, subtle results.&rdquo;</p>
                    <strong>&mdash; Thandeka M.</strong>
                </div>
                <div class="card">
                    <p>&ldquo;Professional, honest and never pushy. I finally trust a clinic with my skin.&rdquo;</p>
                    <strong>&mdash; Rowan P.</strong>
                </div>
                <div class="card">
                    <p>&ldquo;Spotless clinic, friendly staff and the aftercare was excellent.&rdquo;</p>
                    <strong>&mdash; Aisha K.</strong>
                </div>
            </div>
            <div style="text-align:center;margin-top:36px;">
                <a class="btn btn-primary" href="<%= ResolveUrl("~/Contact.aspx") %>">Start Your Journey</a>
            </div>
        </div>
    </section>

</asp:Content>
